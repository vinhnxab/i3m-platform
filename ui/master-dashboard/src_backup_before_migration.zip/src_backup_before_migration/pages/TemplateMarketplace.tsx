import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, Tabs, TabsContent, TabsList, TabsTrigger, Button, Input, Badge } from '@/shared/components/ui';
import { 
  Search, 
  Filter, 
  Star, 
  Download, 
  Eye, 
  Clock,
  Layout,
  ShoppingCart,
  FileText,
  Palette,
  Smartphone,
  Monitor,
  Zap,
  Award
} from 'lucide-react';
import { ImageWithFallback } from '@/components/figma/ImageWithFallback';

export function TemplateMarketplace() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const templateCategories = [
    { id: 'all', label: 'All Templates', count: 1847 },
    { id: 'cms', label: 'CMS Themes', count: 342 },
    { id: 'ecommerce', label: 'E-commerce', count: 298 },
    { id: 'dashboard', label: 'Dashboard', count: 156 },
    { id: 'landing', label: 'Landing Page', count: 234 },
    { id: 'mobile', label: 'Mobile', count: 189 },
    { id: 'admin', label: 'Admin Panel', count: 142 },
    { id: 'portfolio', label: 'Portfolio', count: 198 }
  ];

  const featuredTemplates = [
    {
      id: 1,
      name: 'Corporate Pro Dashboard',
      description: 'Modern and professional dashboard template with advanced analytics',
      category: 'Dashboard',
      author: 'Design Studio Pro',
      price: '$149',
      originalPrice: '$299',
      rating: 4.9,
      reviews: 456,
      downloads: '23.5K',
      icon: Layout,
      color: 'text-chart-1',
      bgColor: 'bg-chart-1/10',
      tags: ['React', 'TypeScript', 'Charts'],
      featured: true,
      lastUpdated: '1 day ago',
      thumbnail: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?w=400&h=200&fit=crop'
    },
    {
      id: 2,
      name: 'E-commerce Excellence',
      description: 'Complete e-commerce solution with shopping cart and payment integration',
      category: 'E-commerce',
      author: 'Commerce Craft',
      price: '$199',
      originalPrice: '$399',
      rating: 4.8,
      reviews: 342,
      downloads: '18.7K',
      icon: ShoppingCart,
      color: 'text-chart-2',
      bgColor: 'bg-chart-2/10',
      tags: ['E-commerce', 'Payment', 'Responsive'],
      featured: true,
      lastUpdated: '2 days ago',
      thumbnail: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&h=200&fit=crop'
    },
    {
      id: 3,
      name: 'Creative Portfolio Hub',
      description: 'Stunning portfolio template for designers and creative professionals',
      category: 'Portfolio',
      author: 'Creative Labs',
      price: '$89',
      originalPrice: '$179',
      rating: 4.7,
      reviews: 278,
      downloads: '15.2K',
      icon: Palette,
      color: 'text-chart-5',
      bgColor: 'bg-chart-5/10',
      tags: ['Portfolio', 'Creative', 'Animation'],
      featured: true,
      lastUpdated: '4 days ago',
      thumbnail: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=200&fit=crop'
    },
    {
      id: 4,
      name: 'Mobile-First CMS',
      description: 'Responsive content management system optimized for mobile devices',
      category: 'CMS Themes',
      author: 'Mobile Masters',
      price: '$129',
      originalPrice: '$259',
      rating: 4.6,
      reviews: 189,
      downloads: '12.8K',
      icon: Smartphone,
      color: 'text-chart-3',
      bgColor: 'bg-chart-3/10',
      tags: ['CMS', 'Mobile', 'Responsive'],
      featured: false,
      lastUpdated: '1 week ago',
      thumbnail: 'https://images.unsplash.com/photo-1512758017271-d7b84c2113f1?w=400&h=200&fit=crop'
    }
  ];

  const allTemplates = [
    ...featuredTemplates,
    {
      id: 5,
      name: 'Landing Page Pro',
      description: 'High-converting landing page template with A/B testing features',
      category: 'Landing Page',
      author: 'Conversion Labs',
      price: '$79',
      originalPrice: '$159',
      rating: 4.5,
      reviews: 234,
      downloads: '9.8K',
      icon: Monitor,
      color: 'text-chart-4',
      bgColor: 'bg-chart-4/10',
      tags: ['Landing Page', 'Conversion', 'A/B Testing'],
      featured: false,
      lastUpdated: '3 days ago',
      thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=200&fit=crop'
    },
    {
      id: 6,
      name: 'Admin Control Center',
      description: 'Comprehensive admin panel with user management and analytics',
      category: 'Admin Panel',
      author: 'Control Systems',
      price: '$159',
      originalPrice: '$319',
      rating: 4.4,
      reviews: 156,
      downloads: '7.2K',
      icon: Zap,
      color: 'text-chart-1',
      bgColor: 'bg-chart-1/10',
      tags: ['Admin Panel', 'User Management', 'Analytics'],
      featured: false,
      lastUpdated: '5 days ago',
      thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=200&fit=crop'
    },
    {
      id: 7,
      name: 'Blog Content Master',
      description: 'Beautiful blog template with SEO optimization and social sharing',
      category: 'CMS Themes',
      author: 'Content Creators',
      price: '$69',
      originalPrice: '$139',
      rating: 4.6,
      reviews: 298,
      downloads: '11.3K',
      icon: FileText,
      color: 'text-chart-2',
      bgColor: 'bg-chart-2/10',
      tags: ['Blog', 'SEO', 'Social Sharing'],
      featured: false,
      lastUpdated: '1 week ago',
      thumbnail: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=400&h=200&fit=crop'
    },
    {
      id: 8,
      name: 'SaaS Application Starter',
      description: 'Complete SaaS application template with subscription management',
      category: 'Dashboard',
      author: 'SaaS Builders',
      price: '$249',
      originalPrice: '$499',
      rating: 4.8,
      reviews: 187,
      downloads: '6.5K',
      icon: Layout,
      color: 'text-chart-5',
      bgColor: 'bg-chart-5/10',
      tags: ['SaaS', 'Subscription', 'Billing'],
      featured: false,
      lastUpdated: '6 days ago',
      thumbnail: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=400&h=200&fit=crop'
    }
  ];

  const filteredTemplates = allTemplates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || 
                           template.category.toLowerCase().replace('/', '-').replace(' ', '-') === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Fixed Header */}
      <div className="flex-shrink-0 p-6 border-b border-border/30 bg-background/50 backdrop-blur-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-semibold text-foreground tracking-tight">Template Marketplace</h1>
            <p className="text-base lg:text-lg text-muted-foreground font-medium mt-1 lg:mt-2">Browse and install premium templates</p>
          </div>
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search templates..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64 rounded-xl border-0 bg-muted/50 backdrop-blur-sm"
              />
            </div>
            <Button variant="outline" size="sm" className="rounded-xl border-0 bg-muted/50 backdrop-blur-sm font-semibold">
              <Filter className="w-4 h-4 mr-2" />
              Filters
            </Button>
          </div>
        </div>
      </div>

      {/* Scrollable Main Content */}
      <div className="flex-1 overflow-hidden">
        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="h-full flex flex-col">
          {/* Fixed Tabs Navigation */}
          <div className="flex-shrink-0 p-6 pb-0">
            <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8 rounded-2xl bg-muted/30 p-1">
              {templateCategories.map((category) => (
                <TabsTrigger
                  key={category.id}
                  value={category.id}
                  className="rounded-xl data-[state=active]:bg-background data-[state=active]:shadow-sm font-semibold text-sm"
                >
                  <span className="hidden sm:inline">{category.label}</span>
                  <span className="sm:hidden">{category.label.split(' ')[0]}</span>
                  <Badge variant="secondary" className="ml-2 px-2 py-0.5 text-xs font-bold rounded-full">
                    {category.count}
                  </Badge>
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          {/* Scrollable Tab Content */}
          <div className="flex-1 overflow-y-auto p-6 pt-4">
            <div className="space-y-6">
              {/* Featured Templates */}
              {selectedCategory === 'all' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xl font-semibold text-foreground">Featured Templates</h2>
                    <Badge variant="outline" className="rounded-full px-3 py-1 font-semibold bg-primary/10 text-primary border-primary/30">
                      <Award className="w-3 h-3 mr-1" />
                      Premium Collection
                    </Badge>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {featuredTemplates.map((template) => (
                      <Card key={template.id} className="border-0 shadow-lg bg-card/90 backdrop-blur-xl rounded-2xl hover:shadow-xl transition-all duration-300 hover:scale-[1.02] group overflow-hidden">
                        <div className="relative h-32 overflow-hidden">
                          <ImageWithFallback
                            src={template.thumbnail}
                            alt={template.name}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                          <Badge variant="secondary" className="absolute top-3 right-3 rounded-full px-2 py-1 text-xs font-bold bg-chart-2/90 text-white backdrop-blur-sm">
                            Featured
                          </Badge>
                        </div>
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center space-x-3">
                              <div className={`w-10 h-10 rounded-xl ${template.bgColor} flex items-center justify-center`}>
                                <template.icon className={`w-5 h-5 ${template.color}`} />
                              </div>
                              <div className="flex-1 min-w-0">
                                <CardTitle className="text-base font-semibold text-foreground truncate">{template.name}</CardTitle>
                                <p className="text-xs text-muted-foreground font-medium">{template.author}</p>
                              </div>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <CardDescription className="text-sm text-muted-foreground leading-relaxed">
                            {template.description}
                          </CardDescription>
                          
                          <div className="flex flex-wrap gap-1">
                            {template.tags.map((tag, index) => (
                              <Badge key={index} variant="outline" className="text-xs px-2 py-0.5 rounded-full font-medium">
                                {tag}
                              </Badge>
                            ))}
                          </div>

                          <div className="flex items-center justify-between text-sm">
                            <div className="flex items-center space-x-4">
                              <div className="flex items-center">
                                <Star className="w-4 h-4 text-yellow-500 fill-current mr-1" />
                                <span className="font-semibold">{template.rating}</span>
                                <span className="text-muted-foreground ml-1">({template.reviews})</span>
                              </div>
                              <div className="flex items-center text-muted-foreground">
                                <Download className="w-4 h-4 mr-1" />
                                {template.downloads}
                              </div>
                            </div>
                            <div className="flex items-center text-muted-foreground">
                              <Clock className="w-4 h-4 mr-1" />
                              {template.lastUpdated}
                            </div>
                          </div>

                          <div className="flex items-center justify-between pt-2">
                            <div className="flex items-center space-x-2">
                              <div className="text-lg font-bold text-foreground">{template.price}</div>
                              {template.originalPrice && (
                                <div className="text-sm text-muted-foreground line-through">{template.originalPrice}</div>
                              )}
                            </div>
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline" className="rounded-xl font-semibold">
                                <Eye className="w-4 h-4 mr-2" />
                                Preview
                              </Button>
                              <Button size="sm" className="rounded-xl font-semibold bg-primary hover:bg-primary/90">
                                Buy Now
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* All Templates Grid */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold text-foreground">
                    {selectedCategory === 'all' ? 'All Templates' : templateCategories.find(cat => cat.id === selectedCategory)?.label}
                  </h2>
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <span>{filteredTemplates.length} templates found</span>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-6">
                  {filteredTemplates.map((template) => (
                    <Card key={template.id} className="border-0 shadow-lg bg-card/90 backdrop-blur-xl rounded-2xl hover:shadow-xl transition-all duration-300 hover:scale-[1.02] group overflow-hidden">
                      <div className="relative h-24 overflow-hidden">
                        <ImageWithFallback
                          src={template.thumbnail}
                          alt={template.name}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                        {template.featured && (
                          <Badge variant="secondary" className="absolute top-2 right-2 rounded-full px-2 py-0.5 text-xs font-bold bg-chart-2/90 text-white backdrop-blur-sm">
                            Featured
                          </Badge>
                        )}
                      </div>
                      <CardHeader className="pb-2">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-2">
                            <div className={`w-8 h-8 rounded-lg ${template.bgColor} flex items-center justify-center`}>
                              <template.icon className={`w-4 h-4 ${template.color}`} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <CardTitle className="text-sm font-semibold text-foreground truncate">{template.name}</CardTitle>
                              <p className="text-xs text-muted-foreground font-medium">{template.author}</p>
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <CardDescription className="text-sm text-muted-foreground leading-relaxed line-clamp-2">
                          {template.description}
                        </CardDescription>
                        
                        <div className="flex items-center justify-between text-xs">
                          <div className="flex items-center space-x-3">
                            <div className="flex items-center">
                              <Star className="w-3 h-3 text-yellow-500 fill-current mr-1" />
                              <span className="font-semibold">{template.rating}</span>
                            </div>
                            <div className="flex items-center text-muted-foreground">
                              <Download className="w-3 h-3 mr-1" />
                              {template.downloads}
                            </div>
                          </div>
                          <div className="flex items-center space-x-1">
                            <div className="text-sm font-bold text-foreground">{template.price}</div>
                            {template.originalPrice && (
                              <div className="text-xs text-muted-foreground line-through">{template.originalPrice}</div>
                            )}
                          </div>
                        </div>

                        <div className="flex space-x-2 pt-1">
                          <Button size="sm" variant="outline" className="flex-1 rounded-xl font-semibold text-xs">
                            <Eye className="w-3 h-3 mr-1" />
                            Preview
                          </Button>
                          <Button size="sm" className="flex-1 rounded-xl font-semibold text-xs bg-primary hover:bg-primary/90">
                            Buy
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {filteredTemplates.length === 0 && (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-muted/50 flex items-center justify-center">
                      <Search className="w-8 h-8 text-muted-foreground" />
                    </div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">No templates found</h3>
                    <p className="text-muted-foreground">Try adjusting your search or filter criteria</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </Tabs>
      </div>
    </div>
  );
}