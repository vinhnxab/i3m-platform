import { motion } from "motion/react";
import { LoadingLogo } from "./LoadingLogo";

interface SplashScreenProps {
  onComplete?: () => void;
  colorEffect?: "rainbow" | "colorshift";
  theme?: "auto" | "dark" | "light";
}

export function SplashScreen({ 
  onComplete, 
  colorEffect = "rainbow",
  theme = "auto"
}: SplashScreenProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.5 }}
      className="fixed inset-0 z-50 bg-background/95 backdrop-blur-xl flex items-center justify-center"
    >
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.6 }}
        className="text-center"
      >
        <LoadingLogo 
          size="lg" 
          colorEffect={colorEffect}
          theme={theme}
          showText={true}
        />
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.4 }}
          className="mt-8 space-y-2"
        >
          <h1 className="text-2xl font-semibold text-foreground">I3M Platform</h1>
          <p className="text-muted-foreground">Initializing your dashboard...</p>
        </motion.div>

        {/* Progress Indicator */}
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: "100%" }}
          transition={{ delay: 1, duration: 2, ease: "easeInOut" }}
          className="w-48 h-1 bg-gradient-to-r from-primary/0 via-primary to-primary/0 rounded-full mx-auto mt-6"
          onAnimationComplete={onComplete}
        />
      </motion.div>
    </motion.div>
  );
}