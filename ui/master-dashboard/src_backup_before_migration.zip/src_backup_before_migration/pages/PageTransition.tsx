import React from 'react';
import { motion, AnimatePresence, useSpring, useTransform } from 'motion/react';

interface PageTransitionProps {
  children: React.ReactNode;
  pageKey: string;
  direction?: 'fluid' | 'slide' | 'scale' | 'lift';
  duration?: number;
}

export const PageTransition: React.FC<PageTransitionProps> = ({ 
  children, 
  pageKey, 
  direction = 'fluid',
  duration = 0.45 
}) => {
  // Apple's signature spring configuration for smooth, natural motion
  const springConfig = {
    type: "spring",
    damping: 25,
    stiffness: 200,
    mass: 0.8,
    restDelta: 0.0001
  };

  // Enhanced easing curves that match iPhone's fluidity
  const fluidEasing = [0.25, 0.46, 0.45, 0.94]; // Custom Apple-inspired curve
  const snapEasing = [0.16, 1, 0.3, 1]; // For quick, snappy animations

  const variants = {
    fluid: {
      initial: { 
        opacity: 0, 
        y: 24,
        scale: 0.96,
        filter: "blur(4px)",
        rotateX: 2
      },
      animate: { 
        opacity: 1, 
        y: 0,
        scale: 1,
        filter: "blur(0px)",
        rotateX: 0,
        transition: {
          ...springConfig,
          duration: duration * 1.2,
          opacity: { duration: duration * 0.6, ease: fluidEasing },
          filter: { duration: duration * 0.8, ease: snapEasing },
          scale: { duration: duration, ease: fluidEasing },
          y: { duration: duration, ease: fluidEasing },
          rotateX: { duration: duration * 0.7, ease: snapEasing }
        }
      },
      exit: { 
        opacity: 0, 
        y: -16,
        scale: 1.02,
        filter: "blur(2px)",
        rotateX: -1,
        transition: {
          duration: duration * 0.6,
          ease: snapEasing,
          opacity: { duration: duration * 0.4 },
          scale: { duration: duration * 0.5 },
          filter: { duration: duration * 0.3 }
        }
      }
    },
    slide: {
      initial: { 
        opacity: 0, 
        x: 32,
        scale: 0.98,
        filter: "blur(2px)"
      },
      animate: { 
        opacity: 1, 
        x: 0,
        scale: 1,
        filter: "blur(0px)",
        transition: {
          ...springConfig,
          duration: duration,
          filter: { duration: duration * 0.7, ease: snapEasing }
        }
      },
      exit: { 
        opacity: 0, 
        x: -24,
        scale: 1.01,
        filter: "blur(1px)",
        transition: {
          duration: duration * 0.7,
          ease: snapEasing
        }
      }
    },
    scale: {
      initial: { 
        opacity: 0, 
        scale: 0.92,
        filter: "blur(3px)",
        rotateY: 2
      },
      animate: { 
        opacity: 1, 
        scale: 1,
        filter: "blur(0px)",
        rotateY: 0,
        transition: {
          ...springConfig,
          duration: duration,
          scale: { duration: duration * 0.8 },
          filter: { duration: duration * 0.9, ease: snapEasing },
          rotateY: { duration: duration * 0.6, ease: fluidEasing }
        }
      },
      exit: { 
        opacity: 0, 
        scale: 1.08,
        filter: "blur(2px)",
        rotateY: -1,
        transition: {
          duration: duration * 0.5,
          ease: snapEasing
        }
      }
    },
    lift: {
      initial: { 
        opacity: 0, 
        y: 40,
        z: -20,
        scale: 0.94,
        filter: "blur(4px) brightness(0.95)",
        rotateX: 4,
        rotateY: 1
      },
      animate: { 
        opacity: 1, 
        y: 0,
        z: 0,
        scale: 1,
        filter: "blur(0px) brightness(1)",
        rotateX: 0,
        rotateY: 0,
        transition: {
          ...springConfig,
          duration: duration * 1.1,
          staggerChildren: 0.05,
          delayChildren: 0.1
        }
      },
      exit: { 
        opacity: 0, 
        y: -24,
        z: 15,
        scale: 1.03,
        filter: "blur(3px) brightness(1.05)",
        rotateX: -2,
        transition: {
          duration: duration * 0.6,
          ease: snapEasing
        }
      }
    }
  };

  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.div
        key={pageKey}
        initial="initial"
        animate="animate"
        exit="exit"
        variants={variants[direction]}
        className="w-full h-full"
        style={{
          transformStyle: "preserve-3d",
          perspective: "1000px",
          transformOrigin: "center center",
          willChange: "transform, opacity, filter"
        }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
};

export const FadeInSection: React.FC<{ 
  children: React.ReactNode; 
  delay?: number;
  className?: string;
  direction?: 'up' | 'down' | 'left' | 'right';
}> = ({ children, delay = 0, className = "", direction = 'up' }) => {
  const directionVariants = {
    up: { y: 24 },
    down: { y: -24 },
    left: { x: 24 },
    right: { x: -24 }
  };

  return (
    <motion.div
      initial={{ 
        opacity: 0, 
        ...directionVariants[direction],
        scale: 0.96,
        filter: "blur(2px)"
      }}
      animate={{ 
        opacity: 1, 
        y: 0, 
        x: 0,
        scale: 1,
        filter: "blur(0px)"
      }}
      transition={{
        type: "spring",
        damping: 20,
        stiffness: 180,
        mass: 0.6,
        delay,
        duration: 0.6,
        opacity: { duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] },
        filter: { duration: 0.5, ease: [0.16, 1, 0.3, 1] }
      }}
      className={className}
      style={{ 
        willChange: "transform, opacity, filter"
      }}
    >
      {children}
    </motion.div>
  );
};

export const StaggerContainer: React.FC<{ 
  children: React.ReactNode;
  staggerDelay?: number;
  className?: string;
  direction?: 'cascade' | 'wave' | 'spiral';
}> = ({ children, staggerDelay = 0.08, className = "", direction = 'cascade' }) => {
  const containerVariants = {
    cascade: {
      hidden: { opacity: 0 },
      show: {
        opacity: 1,
        transition: {
          staggerChildren: staggerDelay,
          delayChildren: 0.1,
          type: "spring",
          damping: 25,
          stiffness: 200
        }
      }
    },
    wave: {
      hidden: { opacity: 0, scale: 0.98 },
      show: {
        opacity: 1,
        scale: 1,
        transition: {
          staggerChildren: staggerDelay * 0.7,
          delayChildren: 0.05,
          type: "spring",
          damping: 20,
          stiffness: 150
        }
      }
    },
    spiral: {
      hidden: { opacity: 0, rotateY: -10 },
      show: {
        opacity: 1,
        rotateY: 0,
        transition: {
          staggerChildren: staggerDelay * 1.2,
          delayChildren: 0.15,
          type: "spring",
          damping: 30,
          stiffness: 180
        }
      }
    }
  };

  return (
    <motion.div
      initial="hidden"
      animate="show"
      variants={containerVariants[direction]}
      className={className}
      style={{ 
        transformStyle: "preserve-3d",
        willChange: "transform, opacity"
      }}
    >
      {children}
    </motion.div>
  );
};

export const StaggerItem: React.FC<{ 
  children: React.ReactNode;
  className?: string;
  index?: number;
}> = ({ children, className = "", index = 0 }) => {
  // Create subtle variation based on index for more natural feel
  const yOffset = 16 + (index % 3) * 4;
  const scaleOffset = 0.95 + (index % 4) * 0.01;
  
  return (
    <motion.div
      variants={{
        hidden: { 
          opacity: 0, 
          y: yOffset,
          scale: scaleOffset,
          filter: "blur(2px)",
          rotateX: 2
        },
        show: { 
          opacity: 1, 
          y: 0,
          scale: 1,
          filter: "blur(0px)",
          rotateX: 0,
          transition: {
            type: "spring",
            damping: 22,
            stiffness: 170,
            mass: 0.7,
            duration: 0.5,
            opacity: { duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] },
            filter: { duration: 0.4, ease: [0.16, 1, 0.3, 1] }
          }
        }
      }}
      className={className}
      style={{ 
        willChange: "transform, opacity, filter"
      }}
    >
      {children}
    </motion.div>
  );
};

// Enhanced loading skeleton with iPhone-like shimmer effect
export const SkeletonLoader: React.FC<{ 
  className?: string;
  variant?: 'pulse' | 'shimmer' | 'wave';
}> = ({ className = "", variant = 'shimmer' }) => {
  const variants = {
    pulse: {
      opacity: [0.4, 0.8, 0.4],
      scale: [1, 1.01, 1]
    },
    shimmer: {
      backgroundPosition: ['-200% 0', '200% 0'],
      opacity: [0.5, 0.7, 0.5]
    },
    wave: {
      opacity: [0.3, 0.7, 0.3],
      y: [0, -2, 0]
    }
  };

  const transitions = {
    pulse: {
      duration: 1.8,
      repeat: Infinity,
      ease: [0.4, 0, 0.6, 1]
    },
    shimmer: {
      duration: 2.5,
      repeat: Infinity,
      ease: "easeInOut"
    },
    wave: {
      duration: 2,
      repeat: Infinity,
      ease: [0.45, 0, 0.55, 1]
    }
  };

  const shimmerBg = variant === 'shimmer' 
    ? 'linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)'
    : undefined;

  return (
    <motion.div
      className={`bg-muted/40 rounded-xl ${className}`}
      animate={variants[variant]}
      transition={transitions[variant]}
      style={{
        background: variant === 'shimmer' 
          ? `linear-gradient(90deg, 
              hsl(var(--muted)) 0%, 
              hsl(var(--muted)/0.8) 40%, 
              hsl(var(--muted)) 60%, 
              hsl(var(--muted)/0.8) 100%)`
          : undefined,
        backgroundSize: variant === 'shimmer' ? '200% 100%' : undefined,
        willChange: "transform, opacity, background-position"
      }}
    />
  );
};

// Smooth micro-interaction for buttons and interactive elements
export const InteractiveElement: React.FC<{
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  disabled?: boolean;
}> = ({ children, className = "", onClick, disabled = false }) => {
  return (
    <motion.div
      className={`cursor-pointer ${disabled ? 'opacity-50 cursor-not-allowed' : ''} ${className}`}
      onClick={disabled ? undefined : onClick}
      whileHover={disabled ? {} : { 
        scale: 1.02,
        y: -1,
        transition: { 
          type: "spring", 
          damping: 25, 
          stiffness: 400,
          mass: 0.5
        }
      }}
      whileTap={disabled ? {} : { 
        scale: 0.98,
        y: 0,
        transition: { 
          type: "spring", 
          damping: 30, 
          stiffness: 500,
          mass: 0.3
        }
      }}
      style={{ 
        willChange: "transform"
      }}
    >
      {children}
    </motion.div>
  );
};