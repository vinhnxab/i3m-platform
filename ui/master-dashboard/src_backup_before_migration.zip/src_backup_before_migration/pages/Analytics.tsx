import { Card, CardContent, CardDescription, CardHeader, CardTitle, Badge, Button, Tabs, TabsContent, TabsList, TabsTrigger } from '@/shared/components/ui';
import { 
  Users, 
  DollarSign,
  Globe,
  Download,
  Filter,
  RefreshCw,
  ArrowUpRight,
  ArrowDownRight,
  Eye,
  MousePointer,
  CheckCircle
} from 'lucide-react';
import { useState } from 'react';

export function Analytics() {
  const [activeTab, setActiveTab] = useState('overview');

  const kpiStats = [
    { title: 'Total Revenue', value: '$1.2M', change: '+23%', icon: DollarSign, color: 'text-chart-2', trend: 'up' },
    { title: 'Active Users', value: '45.2K', change: '+12%', icon: Users, color: 'text-chart-1', trend: 'up' },
    { title: 'Page Views', value: '2.8M', change: '+18%', icon: Eye, color: 'text-chart-5', trend: 'up' },
    { title: 'Conversion Rate', value: '3.4%', change: '-0.2%', icon: MousePointer, color: 'text-chart-3', trend: 'down' },
  ];

  const customerMetrics = [
    { segment: 'Enterprise', customers: 847, revenue: '$845K', growth: '+28%', retention: '94%' },
    { segment: 'Medium Business', customers: 2156, revenue: '$432K', growth: '+15%', retention: '89%' },
    { segment: 'Small Business', customers: 5234, revenue: '$234K', growth: '+22%', retention: '76%' },
    { segment: 'Startups', customers: 3421, revenue: '$156K', growth: '+31%', retention: '68%' },
  ];

  const platformMetrics = [
    { module: 'ERP System', users: 8234, sessions: 45678, avgDuration: '24m', engagement: '87%' },
    { module: 'CMS Management', users: 6789, sessions: 34567, avgDuration: '18m', engagement: '82%' },
    { module: 'E-commerce', users: 12456, sessions: 67890, avgDuration: '31m', engagement: '91%' },
    { module: 'Support System', users: 4567, sessions: 23456, avgDuration: '12m', engagement: '78%' },
  ];

  const regionalData = [
    { region: 'North America', users: 18234, revenue: '$567K', growth: '+25%', share: '42%' },
    { region: 'Europe', users: 14567, revenue: '$423K', growth: '+18%', share: '31%' },
    { region: 'Asia Pacific', users: 8923, revenue: '$234K', growth: '+35%', share: '18%' },
    { region: 'Others', users: 3456, revenue: '$123K', growth: '+12%', share: '9%' },
  ];

  const performanceMetrics = [
    { metric: 'API Response Time', value: '142ms', target: '<200ms', status: 'good' },
    { metric: 'Database Query Time', value: '89ms', target: '<100ms', status: 'good' },
    { metric: 'Page Load Time', value: '1.2s', target: '<2s', status: 'good' },
    { metric: 'Error Rate', value: '0.08%', target: '<0.1%', status: 'good' },
    { metric: 'Uptime', value: '99.9%', target: '>99.5%', status: 'excellent' },
  ];

  const conversionFunnel = [
    { stage: 'Visitors', count: 125000, percentage: 100 },
    { stage: 'Signups', count: 12500, percentage: 10 },
    { stage: 'Trial Users', count: 8750, percentage: 7 },
    { stage: 'Paid Customers', count: 3125, percentage: 2.5 },
    { stage: 'Enterprise', count: 625, percentage: 0.5 },
  ];

  return (
    <div className="w-full px-4 lg:px-6 py-4 lg:py-6 space-y-4 lg:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 gap-2">
        <div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-semibold text-foreground tracking-tight">Analytics & Reports</h1>
          <p className="text-base lg:text-lg text-muted-foreground font-medium mt-1 lg:mt-2">Comprehensive platform analytics and insights</p>
        </div>
        <div className="flex items-center space-x-3">
          <Badge variant="outline" className="text-chart-2 border-current bg-chart-2/10 backdrop-blur-sm px-3 lg:px-4 py-1.5 lg:py-2 rounded-full font-semibold text-sm">
            <CheckCircle className="w-3 lg:w-4 h-3 lg:h-4 mr-1 lg:mr-2" />
            All Systems Operational
          </Badge>
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* KPI Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3">
        {kpiStats.map((stat, index) => {
          const Icon = stat.icon;
          const TrendIcon = stat.trend === 'up' ? ArrowUpRight : ArrowDownRight;
          return (
            <Card key={index} className="border-0 shadow-lg bg-card/90 backdrop-blur-xl rounded-2xl">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
                <CardTitle className="text-sm font-semibold text-muted-foreground">{stat.title}</CardTitle>
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center">
                  <Icon className={`w-5 h-5 ${stat.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground tracking-tight mb-1">{stat.value}</div>
                <div className="flex items-center text-sm text-muted-foreground font-medium">
                  <TrendIcon className={`w-3 h-3 mr-1 ${stat.trend === 'up' ? 'text-chart-2' : 'text-chart-4'}`} />
                  <span className={`font-semibold ${stat.trend === 'up' ? 'text-chart-2' : 'text-chart-4'}`}>
                    {stat.change}
                  </span>
                  <span className="ml-1">from last month</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Analytics Modules */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="customers">Customers</TabsTrigger>
          <TabsTrigger value="platform">Platform</TabsTrigger>
          <TabsTrigger value="regional">Regional</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Conversion Funnel */}
            <Card>
              <CardHeader>
                <CardTitle>Conversion Funnel</CardTitle>
                <CardDescription>User journey from visitor to customer</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {conversionFunnel.map((stage, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">{stage.stage}</span>
                        <div className="text-right">
                          <span className="font-medium">{stage.count.toLocaleString()}</span>
                          <span className="text-xs text-muted-foreground ml-2">({stage.percentage}%)</span>
                        </div>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full transition-all duration-300" 
                          style={{ width: `${stage.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Revenue Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle>Revenue Breakdown</CardTitle>
                <CardDescription>Revenue distribution by source</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { source: 'Subscription Revenue', amount: '$845K', percentage: 68, color: 'bg-blue-500' },
                    { source: 'Template Marketplace', amount: '$234K', percentage: 19, color: 'bg-green-500' },
                    { source: 'Professional Services', amount: '$123K', percentage: 10, color: 'bg-purple-500' },
                    { source: 'Support & Training', amount: '$43K', percentage: 3, color: 'bg-orange-500' },
                  ].map((item, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">{item.source}</span>
                        <span className="font-medium">{item.amount}</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div 
                          className={`${item.color} h-2 rounded-full transition-all duration-300`} 
                          style={{ width: `${item.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>User Engagement</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">Daily Active Users</span>
                    <span className="font-medium">23.4K</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Session Duration</span>
                    <span className="font-medium">24m 32s</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Pages per Session</span>
                    <span className="font-medium">4.7</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Bounce Rate</span>
                    <Badge variant="outline">12.3%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Growth Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">MRR Growth</span>
                    <Badge variant="default" className="text-green-600">+18%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Customer Growth</span>
                    <Badge variant="default" className="text-green-600">+23%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Churn Rate</span>
                    <Badge variant="outline">2.1%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">LTV/CAC Ratio</span>
                    <Badge variant="default">4.2:1</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

        <Card>
              <CardHeader>
                <CardTitle>Platform Health</CardTitle>
          </CardHeader>
          <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">System Uptime</span>
                    <Badge variant="default">99.9%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Avg Response Time</span>
                    <span className="font-medium">142ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Error Rate</span>
                    <Badge variant="outline">0.08%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Security Score</span>
                    <Badge variant="default">A+</Badge>
                  </div>
                </div>
          </CardContent>
        </Card>
          </div>
        </TabsContent>

        {/* Customer Analytics Tab */}
        <TabsContent value="customers" className="space-y-6">
        <Card>
            <CardHeader>
              <CardTitle>Customer Segmentation</CardTitle>
              <CardDescription>Analysis by customer segment and behavior</CardDescription>
          </CardHeader>
          <CardContent>
              <div className="space-y-6">
                {customerMetrics.map((segment, index) => (
                  <div key={index} className="space-y-3">
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">{segment.segment}</h4>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-muted-foreground">{segment.customers} customers</span>
                        <span className="font-medium">{segment.revenue}</span>
                        <Badge variant="outline" className="text-green-600">{segment.growth}</Badge>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Customers: </span>
                        <span className="font-medium">{segment.customers.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Revenue: </span>
                        <span className="font-medium">{segment.revenue}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Retention: </span>
                        <Badge variant="outline">{segment.retention}</Badge>
                      </div>
                    </div>
                    <div className="w-full bg-secondary rounded-full h-2">
                      <div 
                        className="bg-primary h-2 rounded-full" 
                        style={{ width: `${(index + 1) * 20}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
          </CardContent>
        </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
              <CardHeader>
                <CardTitle>Customer Lifecycle</CardTitle>
          </CardHeader>
          <CardContent>
                <div className="space-y-4">
                  {[
                    { stage: 'Trial Users', count: 1247, conversion: '68%' },
                    { stage: 'New Customers', count: 847, conversion: '89%' },
                    { stage: 'Active Customers', count: 5234, conversion: '94%' },
                    { stage: 'Enterprise Customers', count: 423, conversion: '97%' },
                  ].map((stage, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="text-sm">{stage.stage}</span>
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{stage.count.toLocaleString()}</span>
                        <Badge variant="outline">{stage.conversion}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
          </CardContent>
        </Card>

        <Card>
              <CardHeader>
                <CardTitle>Churn Analysis</CardTitle>
          </CardHeader>
          <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Monthly Churn Rate</span>
                    <Badge variant="outline">2.1%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Annual Churn Rate</span>
                    <Badge variant="outline">25.2%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Average LTV</span>
                    <span className="font-medium">$4,250</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Churn Prevention</span>
                    <Badge variant="default">78% success</Badge>
                  </div>
                </div>
          </CardContent>
        </Card>
      </div>
        </TabsContent>

        {/* Platform Analytics Tab */}
        <TabsContent value="platform" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Platform Module Usage</CardTitle>
              <CardDescription>Usage analytics for each platform module</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {platformMetrics.map((module, index) => (
                  <div key={index} className="space-y-3">
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">{module.module}</h4>
                      <Badge variant="outline">{module.engagement} engagement</Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Active Users: </span>
                        <span className="font-medium">{module.users.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Sessions: </span>
                        <span className="font-medium">{module.sessions.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Avg Duration: </span>
                        <span className="font-medium">{module.avgDuration}</span>
                      </div>
                    </div>
                    <div className="w-full bg-secondary rounded-full h-2">
                      <div 
                        className="bg-primary h-2 rounded-full" 
                        style={{ width: `${parseInt(module.engagement)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Regional Analytics Tab */}
        <TabsContent value="regional" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Regional Performance</CardTitle>
              <CardDescription>Geographic distribution and performance metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {regionalData.map((region, index) => (
                  <div key={index} className="space-y-3">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-2">
                        <Globe className="w-4 h-4 text-muted-foreground" />
                        <h4 className="font-medium">{region.region}</h4>
                      </div>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-muted-foreground">Share: {region.share}</span>
                        <Badge variant="outline" className="text-green-600">{region.growth}</Badge>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Users: </span>
                        <span className="font-medium">{region.users.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Revenue: </span>
                        <span className="font-medium">{region.revenue}</span>
                      </div>
                    </div>
                    <div className="w-full bg-secondary rounded-full h-2">
                      <div 
                        className="bg-primary h-2 rounded-full" 
                        style={{ width: `${parseInt(region.share)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Performance Analytics Tab */}
        <TabsContent value="performance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>System Performance Metrics</CardTitle>
              <CardDescription>Technical performance and reliability metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {performanceMetrics.map((metric, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-medium">{metric.metric}</h4>
                      <p className="text-sm text-muted-foreground">Target: {metric.target}</p>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className="font-medium">{metric.value}</span>
                      <Badge variant={
                        metric.status === 'excellent' ? 'default' :
                        metric.status === 'good' ? 'secondary' : 'destructive'
                      }>
                        {metric.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
                <CardTitle>Infrastructure Health</CardTitle>
        </CardHeader>
        <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">CPU Usage</span>
                    <span className="font-medium">68%</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: '68%' }} />
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Memory Usage</span>
                    <span className="font-medium">74%</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-2">
                    <div className="bg-yellow-500 h-2 rounded-full" style={{ width: '74%' }} />
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Storage Usage</span>
                    <span className="font-medium">45%</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: '45%' }} />
              </div>
            </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>API Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Requests/min</span>
                    <span className="font-medium">12,456</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Success Rate</span>
                    <Badge variant="default">99.92%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">P95 Response Time</span>
                    <span className="font-medium">245ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Rate Limit Hits</span>
                    <Badge variant="outline">0.03%</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}