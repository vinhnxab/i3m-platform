import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { 
  MessageSquare, 
  X, 
  Send, 
  Minimize2, 
  Maximize2,
  Users,
  Settings,
  Paperclip,
  Smile
} from 'lucide-react';

interface QuickMessage {
  id: number;
  content: string;
  sender: string;
  timestamp: string;
  isAgent: boolean;
}

export function FloatingChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [message, setMessage] = useState('');
  const [unreadCount, setUnreadCount] = useState(3);

  const quickMessages: QuickMessage[] = [
    {
      id: 1,
      content: 'Hi! How can I help you today?',
      sender: 'Sarah Wilson',
      timestamp: '14:20',
      isAgent: true
    },
    {
      id: 2,
      content: 'I need help with API integration',
      sender: 'You',
      timestamp: '14:22',
      isAgent: false
    },
    {
      id: 3,
      content: 'I\'d be happy to help! What specific issue are you facing?',
      sender: 'Sarah Wilson',
      timestamp: '14:23',
      isAgent: true
    }
  ];

  const handleSendMessage = () => {
    if (message.trim()) {
      console.log('Sending message:', message);
      setMessage('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!isOpen) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => {
            setIsOpen(true);
            setUnreadCount(0);
          }}
          className="h-14 w-14 rounded-full shadow-lg hover:scale-110 transition-transform"
          size="lg"
        >
          <div className="relative">
            <MessageSquare className="w-6 h-6" />
            {unreadCount > 0 && (
              <Badge 
                variant="destructive" 
                className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center text-xs p-0"
              >
                {unreadCount}
              </Badge>
            )}
          </div>
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Card className={`w-96 shadow-2xl transition-all duration-300 ${
        isMinimized ? 'h-16' : 'h-96'
      }`}>
        {/* Header */}
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 bg-primary text-primary-foreground rounded-t-lg">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Avatar className="w-8 h-8">
                <AvatarImage src="" />
                <AvatarFallback className="bg-primary-foreground text-primary text-xs">SW</AvatarFallback>
              </Avatar>
              <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-primary" />
            </div>
            <div>
              <CardTitle className="text-sm">Support Chat</CardTitle>
              <p className="text-xs opacity-90">Sarah Wilson • Online</p>
            </div>
          </div>
          <div className="flex items-center space-x-1">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setIsMinimized(!isMinimized)}
              className="h-8 w-8 p-0 text-primary-foreground hover:bg-primary-foreground/20"
            >
              {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setIsOpen(false)}
              className="h-8 w-8 p-0 text-primary-foreground hover:bg-primary-foreground/20"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>

        {!isMinimized && (
          <>
            {/* Messages */}
            <CardContent className="p-0 flex-1">
              <ScrollArea className="h-64 p-4">
                <div className="space-y-4">
                  {quickMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.isAgent ? 'justify-start' : 'justify-end'}`}
                    >
                      <div className={`flex items-start space-x-2 max-w-[80%] ${
                        msg.isAgent ? '' : 'flex-row-reverse space-x-reverse'
                      }`}>
                        <Avatar className="w-6 h-6">
                          <AvatarFallback className="text-xs">
                            {msg.isAgent ? 'SW' : 'YU'}
                          </AvatarFallback>
                        </Avatar>
                        
                        <div>
                          <div className={`rounded-lg px-3 py-2 text-sm ${
                            msg.isAgent
                              ? 'bg-muted'
                              : 'bg-primary text-primary-foreground'
                          }`}>
                            {msg.content}
                          </div>
                          <div className={`text-xs text-muted-foreground mt-1 ${
                            msg.isAgent ? 'text-left' : 'text-right'
                          }`}>
                            {msg.timestamp}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>

            {/* Message Input */}
            <div className="p-4 border-t">
              <div className="flex items-center space-x-2">
                <div className="flex-1">
                  <Input
                    placeholder="Type your message..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="border-0 bg-muted focus-visible:ring-1"
                  />
                </div>
                <div className="flex space-x-1">
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <Paperclip className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <Smile className="w-4 h-4" />
                  </Button>
                  <Button
                    onClick={handleSendMessage}
                    disabled={!message.trim()}
                    size="sm"
                    className="h-8 w-8 p-0"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              <div className="flex items-center justify-between mt-2">
                <div className="flex items-center space-x-2">
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full" />
                    <span className="text-xs text-muted-foreground">3 agents online</span>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-xs h-6 px-2"
                  onClick={() => {
                    // Navigate to full support chat
                    console.log('Opening full support chat');
                  }}
                >
                  Open Full Chat
                </Button>
              </div>
            </div>
          </>
        )}
      </Card>
    </div>
  );
}