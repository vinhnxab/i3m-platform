import { Card, CardContent, CardDescription, CardHeader, CardTitle, Badge } from '@/shared/components/ui';
import { I3MLogo } from './I3MLogo';
import { LoadingLogo } from './LoadingLogo';
import { 
  TrendingUp, 
  Users, 
  ShoppingCart, 
  MessageSquare, 
  DollarSign,
  Zap,
  CheckCircle,
  Palette,
  Play
} from 'lucide-react';

export function Overview() {
  const stats = [
    { title: 'Total Customers', value: '2,847', change: '+12%', icon: Users, color: 'text-primary' },
    { title: 'Monthly Revenue', value: '$847K', change: '+23%', icon: DollarSign, color: 'text-chart-2' },
    { title: 'Active Orders', value: '1,429', change: '+8%', icon: ShoppingCart, color: 'text-chart-3' },
    { title: 'Support Tickets', value: '142', change: '-15%', icon: MessageSquare, color: 'text-chart-4' },
  ];

  const systemStatus = [
    { service: 'Authentication Service', status: 'operational', uptime: '99.9%' },
    { service: 'Customer Management', status: 'operational', uptime: '99.8%' },
    { service: 'E-commerce Engine', status: 'operational', uptime: '99.5%' },
    { service: 'CMS Service', status: 'maintenance', uptime: '98.2%' },
  ];

  const recentActivity = [
    { type: 'customer', action: 'New customer registered', time: '2 minutes ago', customer: 'TechStart Inc.' },
    { type: 'order', action: 'Large order processed', time: '8 minutes ago', customer: 'Enterprise Solutions' },
    { type: 'support', action: 'Ticket resolved', time: '20 minutes ago', customer: 'StartupCo' },
    { type: 'payment', action: 'Payment processed', time: '25 minutes ago', customer: 'Enterprise Corp' },
  ];

  return (
    <div className="w-full px-4 lg:px-6 py-4 lg:py-6 space-y-4 lg:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 gap-2">
        <div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-semibold text-foreground tracking-tight">I3M Platform Overview</h1>
          <p className="text-base lg:text-lg text-muted-foreground font-medium mt-1 lg:mt-2">Comprehensive enterprise management dashboard</p>
        </div>
        <div className="flex items-center space-x-3">
          <Badge variant="outline" className="text-chart-2 border-current bg-chart-2/10 backdrop-blur-sm px-3 lg:px-4 py-1.5 lg:py-2 rounded-full font-semibold text-sm">
            <CheckCircle className="w-3 lg:w-4 h-3 lg:h-4 mr-1 lg:mr-2" />
            All Systems Operational
          </Badge>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="border-0 shadow-lg bg-card/90 backdrop-blur-xl rounded-2xl">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
                <CardTitle className="text-sm font-semibold text-muted-foreground">{stat.title}</CardTitle>
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center">
                  <Icon className={`w-5 h-5 ${stat.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground tracking-tight mb-1">{stat.value}</div>
                <p className="text-sm text-muted-foreground font-medium">
                  <span className={`font-semibold ${stat.change.startsWith('+') ? 'text-chart-2' : 'text-chart-4'}`}>
                    {stat.change}
                  </span>
                  {' '}from last month
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* System Status & Recent Activity */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-3 lg:gap-4">
        {/* System Status */}
        <Card className="border-0 shadow-lg bg-card/90 backdrop-blur-xl rounded-2xl">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center text-xl font-semibold text-foreground">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center mr-3">
                <Zap className="w-5 h-5 text-primary" />
              </div>
              System Status
            </CardTitle>
            <CardDescription className="text-base font-medium text-muted-foreground">Real-time status of all microservices</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {systemStatus.map((service, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors duration-200">
                  <div className="flex items-center space-x-4">
                    <div className={`w-2 h-2 rounded-full ${
                      service.status === 'operational' ? 'bg-chart-2' : 'bg-chart-3'
                    }`} />
                    <span className="text-sm font-medium text-foreground">{service.service}</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className="text-sm text-muted-foreground font-medium">{service.uptime}</span>
                    <Badge 
                      variant="outline"
                      className={`rounded-full font-semibold px-3 py-1 ${
                        service.status === 'operational' 
                          ? 'bg-chart-2/10 text-chart-2 border-chart-2/30' 
                          : 'bg-chart-3/10 text-chart-3 border-chart-3/30'
                      }`}
                    >
                      {service.status === 'operational' ? 'Operational' : 'Maintenance'}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Logo Effects Demo */}
        <Card className="border-0 shadow-lg bg-card/90 backdrop-blur-xl rounded-2xl">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center text-xl font-semibold text-foreground">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center mr-3">
                <Palette className="w-5 h-5 text-primary" />
              </div>
              Logo Color Effects
            </CardTitle>
            <CardDescription className="text-base font-medium text-muted-foreground">Beautiful animated logo variations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Default Effect */}
              <div className="flex flex-col items-center space-y-3 p-4 rounded-xl bg-muted/30 border border-border/30">
                <div className="h-16 flex items-center justify-center">
                  <I3MLogo size="lg" animated={true} colorEffect="default" />
                </div>
                <div className="text-center">
                  <p className="font-semibold text-sm">Default</p>
                  <p className="text-xs text-muted-foreground">Gentle glow effect</p>
                </div>
              </div>

              {/* Rainbow Effect */}
              <div className="flex flex-col items-center space-y-3 p-4 rounded-xl bg-muted/30 border border-border/30">
                <div className="h-16 flex items-center justify-center">
                  <I3MLogo size="lg" animated={true} colorEffect="rainbow" />
                </div>
                <div className="text-center">
                  <p className="font-semibold text-sm">Rainbow</p>
                  <p className="text-xs text-muted-foreground">Full spectrum flow</p>
                </div>
              </div>

              {/* Color Shift Effect */}
              <div className="flex flex-col items-center space-y-3 p-4 rounded-xl bg-muted/30 border border-border/30">
                <div className="h-16 flex items-center justify-center">
                  <I3MLogo size="lg" animated={true} colorEffect="colorshift" />
                </div>
                <div className="text-center">
                  <p className="font-semibold text-sm">Color Shift</p>
                  <p className="text-xs text-muted-foreground">Elegant transitions</p>
                </div>
              </div>

              {/* Loading Demo */}
              <div className="flex flex-col items-center space-y-3 p-4 rounded-xl bg-muted/30 border border-border/30">
                <div className="h-16 flex items-center justify-center">
                  <LoadingLogo size="md" colorEffect="rainbow" />
                </div>
                <div className="text-center">
                  <p className="font-semibold text-sm">Loading</p>
                  <p className="text-xs text-muted-foreground">With motion effects</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="border-0 shadow-lg bg-card/90 backdrop-blur-xl rounded-2xl">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center text-xl font-semibold text-foreground">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center mr-3">
                <TrendingUp className="w-5 h-5 text-primary" />
              </div>
              Recent Activity
            </CardTitle>
            <CardDescription className="text-base font-medium text-muted-foreground">Latest platform activities and events</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-center space-x-4 p-3 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors duration-200">
                  <div className={`w-3 h-3 rounded-full ${
                    activity.type === 'customer' ? 'bg-chart-1' :
                    activity.type === 'order' ? 'bg-chart-2' :
                    activity.type === 'support' ? 'bg-chart-3' :
                    'bg-chart-5'
                  }`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground">{activity.action}</p>
                    <p className="text-sm text-muted-foreground">{activity.customer}</p>
                  </div>
                  <span className="text-sm text-muted-foreground font-medium">{activity.time}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}