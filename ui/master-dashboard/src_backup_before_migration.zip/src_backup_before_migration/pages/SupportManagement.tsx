import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, Button, Badge, Tabs, TabsContent, TabsList, TabsTrigger } from '@/shared/components/ui';
import { LiveChat } from './LiveChat';
import { 
  MessageSquare, 
  Users, 
  BookOpen, 
  Phone,
  Clock,
  CheckCircle,
  AlertTriangle,
  Plus,
  Search,
  Filter,
  Send,
  Star,
  TrendingUp,
  UserCheck,
  Headphones
} from 'lucide-react';
import { Input } from './ui/input';

export function SupportManagement() {
  const [activeTab, setActiveTab] = useState('tickets');

  const supportStats = [
    { title: 'Open Tickets', value: '142', change: '-15', icon: MessageSquare, color: 'text-orange-500' },
    { title: 'Active Agents', value: '24', change: '+2', icon: Users, color: 'text-blue-500' },
    { title: 'Live Chats', value: '18', change: '+5', icon: MessageSquare, color: 'text-green-500' },
    { title: 'Satisfaction Rate', value: '94%', change: '+3%', icon: Star, color: 'text-purple-500' },
  ];

  const tickets = [
    {
      id: 'TKT-001',
      subject: 'Unable to access ERP module',
      customer: 'TechCorp Inc.',
      agent: 'Sarah Johnson',
      priority: 'high',
      status: 'open',
      category: 'Technical',
      created: '2024-01-15 09:30',
      updated: '2024-01-15 14:20'
    },
    {
      id: 'TKT-002',
      subject: 'Payment processing issue',
      customer: 'StartupCo',
      agent: 'Mike Chen',
      priority: 'urgent',
      status: 'in-progress',
      category: 'Billing',
      created: '2024-01-15 11:45',
      updated: '2024-01-15 15:10'
    },
    {
      id: 'TKT-003',
      subject: 'Feature request: Dark mode',
      customer: 'Global Solutions',
      agent: 'Emily Davis',
      priority: 'low',
      status: 'resolved',
      category: 'Feature Request',
      created: '2024-01-14 16:20',
      updated: '2024-01-15 10:30'
    },
    {
      id: 'TKT-004',
      subject: 'Template installation error',
      customer: 'Enterprise Ltd',
      agent: 'John Smith',
      priority: 'medium',
      status: 'pending',
      category: 'Technical',
      created: '2024-01-15 08:15',
      updated: '2024-01-15 12:45'
    },
  ];

  const agents = [
    {
      id: 1,
      name: 'Sarah Johnson',
      email: 'sarah@i3m.com',
      status: 'online',
      activeTickets: 8,
      resolvedToday: 12,
      avgRating: 4.8,
      department: 'Technical Support'
    },
    {
      id: 2,
      name: 'Mike Chen',
      email: 'mike@i3m.com',
      status: 'busy',
      activeTickets: 15,
      resolvedToday: 9,
      avgRating: 4.6,
      department: 'Billing Support'
    },
    {
      id: 3,
      name: 'Emily Davis',
      email: 'emily@i3m.com',
      status: 'online',
      activeTickets: 6,
      resolvedToday: 18,
      avgRating: 4.9,
      department: 'General Support'
    },
    {
      id: 4,
      name: 'John Smith',
      email: 'john@i3m.com',
      status: 'away',
      activeTickets: 11,
      resolvedToday: 7,
      avgRating: 4.7,
      department: 'Technical Support'
    },
  ];

  const chatRooms = [
    {
      id: 1,
      name: 'General Support',
      participants: 45,
      activeMessages: 128,
      lastActivity: '2 mins ago',
      status: 'active'
    },
    {
      id: 2,
      name: 'Technical Issues',
      participants: 23,
      activeMessages: 67,
      lastActivity: '5 mins ago',
      status: 'active'
    },
    {
      id: 3,
      name: 'Billing Questions',
      participants: 12,
      activeMessages: 34,
      lastActivity: '15 mins ago',
      status: 'active'
    },
    {
      id: 4,
      name: 'Feature Requests',
      participants: 18,
      activeMessages: 89,
      lastActivity: '1 hour ago',
      status: 'active'
    },
  ];

  const knowledgeBaseArticles = [
    {
      id: 1,
      title: 'Getting Started with I3M Platform',
      category: 'Onboarding',
      views: 2847,
      helpful: 245,
      lastUpdated: '2024-01-10',
      status: 'published'
    },
    {
      id: 2,
      title: 'How to Set Up ERP Modules',
      category: 'ERP',
      views: 1523,
      helpful: 189,
      lastUpdated: '2024-01-08',
      status: 'published'
    },
    {
      id: 3,
      title: 'Payment Configuration Guide',
      category: 'E-commerce',
      views: 967,
      helpful: 87,
      lastUpdated: '2024-01-12',
      status: 'draft'
    },
    {
      id: 4,
      title: 'Template Installation Tutorial',
      category: 'CMS',
      views: 1234,
      helpful: 156,
      lastUpdated: '2024-01-05',
      status: 'published'
    },
  ];

  return (
    <div className="w-full px-4 lg:px-6 py-4 lg:py-6 space-y-4 lg:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 gap-2">
        <div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-semibold text-foreground tracking-tight">Customer Support</h1>
          <p className="text-base lg:text-lg text-muted-foreground font-medium mt-1 lg:mt-2">Comprehensive support management system</p>
        </div>
        <div className="flex items-center space-x-3">
                    <Badge variant="outline" className="text-chart-2 border-current bg-chart-2/10 backdrop-blur-sm px-3 lg:px-4 py-1.5 lg:py-2 rounded-full font-semibold text-sm">
            <CheckCircle className="w-3 lg:w-4 h-3 lg:h-4 mr-1 lg:mr-2" />
            All Systems Operational
          </Badge>
          <Button variant="outline">
            <Plus className="w-4 h-4 mr-2" />
            New Ticket
          </Button>
          <Button>
            <MessageSquare className="w-4 h-4 mr-2" />
            Live Chat
          </Button>
        </div>
      </div>

      {/* Support Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3">
        {supportStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="border-0 shadow-lg bg-card/90 backdrop-blur-xl rounded-2xl">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
                <CardTitle className="text-sm font-semibold text-muted-foreground">{stat.title}</CardTitle>
                <Icon className={`w-4 h-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground tracking-tight mb-1">{stat.value}</div>
                <p className="text-sm text-muted-foreground font-medium">
                  <span className={stat.change.startsWith('+') ? 'text-green-600' : 'text-red-600'}>
                    {stat.change}
                  </span> from yesterday
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Support Modules */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="tickets">Support Tickets</TabsTrigger>
          <TabsTrigger value="agents">Agents</TabsTrigger>
          <TabsTrigger value="chat">Live Chat</TabsTrigger>
          <TabsTrigger value="knowledge">Knowledge Base</TabsTrigger>
        </TabsList>

        {/* Support Tickets Tab */}
        <TabsContent value="tickets" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Support Tickets</CardTitle>
                  <CardDescription>Manage customer support requests</CardDescription>
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    <Search className="w-4 h-4 mr-2" />
                    Search
                  </Button>
                  <Button variant="outline" size="sm">
                    <Filter className="w-4 h-4 mr-2" />
                    Filter
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {tickets.map((ticket) => (
                  <div key={ticket.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <MessageSquare className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <h4 className="font-medium">{ticket.id}</h4>
                          <Badge variant={
                            ticket.priority === 'urgent' ? 'destructive' :
                            ticket.priority === 'high' ? 'default' :
                            ticket.priority === 'medium' ? 'secondary' : 'outline'
                          }>
                            {ticket.priority}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">{ticket.subject}</p>
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                          <span>{ticket.customer}</span>
                          <span>Agent: {ticket.agent}</span>
                          <span>Created: {ticket.created}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Badge className={ticket.category}>{ticket.category}</Badge>
                      <Badge variant={
                        ticket.status === 'resolved' ? 'default' :
                        ticket.status === 'in-progress' ? 'secondary' :
                        ticket.status === 'open' ? 'outline' : 'secondary'
                      }>
                        {ticket.status === 'resolved' && <CheckCircle className="w-3 h-3 mr-1" />}
                        {ticket.status === 'in-progress' && <Clock className="w-3 h-3 mr-1" />}
                        {ticket.status === 'open' && <AlertTriangle className="w-3 h-3 mr-1" />}
                        {ticket.status}
                      </Badge>
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Ticket Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { category: 'Technical', count: 89, color: 'bg-blue-500' },
                    { category: 'Billing', count: 34, color: 'bg-green-500' },
                    { category: 'General', count: 19, color: 'bg-purple-500' },
                  ].map((item, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${item.color}`} />
                      <span className="text-sm flex-1">{item.category}</span>
                      <Badge variant="outline">{item.count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Priority Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { priority: 'Urgent', count: 12, color: 'bg-red-500' },
                    { priority: 'High', count: 45, color: 'bg-orange-500' },
                    { priority: 'Medium', count: 67, color: 'bg-yellow-500' },
                    { priority: 'Low', count: 18, color: 'bg-green-500' },
                  ].map((item, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${item.color}`} />
                      <span className="text-sm flex-1">{item.priority}</span>
                      <Badge variant="outline">{item.count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Resolution Time</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">Average</span>
                    <span className="font-medium">4.2 hours</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Fastest</span>
                    <span className="font-medium">15 minutes</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">SLA Target</span>
                    <span className="font-medium">6 hours</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Compliance</span>
                    <Badge variant="default">96%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Agents Tab */}
        <TabsContent value="agents" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Support Agents</CardTitle>
              <CardDescription>Manage support team and performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {agents.map((agent) => (
                  <div key={agent.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="relative">
                        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                          <Users className="w-5 h-5 text-primary" />
                        </div>
                        <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-white ${
                          agent.status === 'online' ? 'bg-green-500' :
                          agent.status === 'busy' ? 'bg-red-500' :
                          agent.status === 'away' ? 'bg-yellow-500' : 'bg-gray-500'
                        }`} />
                      </div>
                      <div>
                        <h4 className="font-medium">{agent.name}</h4>
                        <p className="text-sm text-muted-foreground">{agent.department}</p>
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                          <span>Active: {agent.activeTickets}</span>
                          <span>Resolved: {agent.resolvedToday}</span>
                          <div className="flex items-center">
                            <Star className="w-3 h-3 mr-1 fill-yellow-400 text-yellow-400" />
                            <span>{agent.avgRating}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Badge variant={
                        agent.status === 'online' ? 'default' :
                        agent.status === 'busy' ? 'destructive' :
                        agent.status === 'away' ? 'secondary' : 'outline'
                      }>
                        {agent.status}
                      </Badge>
                      <Button variant="outline" size="sm">
                        <MessageSquare className="w-4 h-4 mr-1" />
                        Chat
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Team Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Total Tickets Resolved Today</span>
                    <span className="font-medium">46</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Average Response Time</span>
                    <span className="font-medium">2.4 hours</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Customer Satisfaction</span>
                    <div className="flex items-center">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 mr-1" />
                      <span className="font-medium">4.7/5</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Active Agents</span>
                    <Badge variant="outline">24/30</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Department Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { dept: 'Technical Support', agents: 12, load: '78%' },
                    { dept: 'Billing Support', agents: 6, load: '65%' },
                    { dept: 'General Support', agents: 8, load: '45%' },
                    { dept: 'Sales Support', agents: 4, load: '82%' },
                  ].map((dept, index) => (
                    <div key={index} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>{dept.dept}</span>
                        <span>{dept.agents} agents • {dept.load}</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full" 
                          style={{ width: dept.load }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Live Chat Tab */}
        <TabsContent value="chat" className="space-y-6">
          <LiveChat />
        </TabsContent>

        {/* Knowledge Base Tab */}
        <TabsContent value="knowledge" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Knowledge Base</CardTitle>
                  <CardDescription>Self-service documentation and FAQs</CardDescription>
                </div>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Article
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {knowledgeBaseArticles.map((article) => (
                  <div key={article.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <BookOpen className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium">{article.title}</h4>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span>Category: {article.category}</span>
                          <span>{article.views} views</span>
                          <span>{article.helpful} helpful votes</span>
                          <span>Updated: {article.lastUpdated}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Badge variant={article.status === 'published' ? 'default' : 'secondary'}>
                        {article.status}
                      </Badge>
                      <Button variant="outline" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Article Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { name: 'Onboarding', count: 12 },
                    { name: 'ERP', count: 23 },
                    { name: 'E-commerce', count: 18 },
                    { name: 'CMS', count: 15 },
                    { name: 'Support', count: 9 },
                  ].map((category, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm">{category.name}</span>
                      <Badge variant="outline">{category.count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Popular Articles</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { title: 'Getting Started Guide', views: 2847 },
                    { title: 'ERP Setup Tutorial', views: 1523 },
                    { title: 'Payment Configuration', views: 1234 },
                  ].map((article, index) => (
                    <div key={index} className="space-y-1">
                      <div className="flex justify-between">
                        <span className="text-sm">{article.title}</span>
                        <span className="text-xs text-muted-foreground">{article.views}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Knowledge Base Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Total Articles</span>
                    <span className="font-medium">127</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Monthly Views</span>
                    <span className="font-medium">15,847</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Helpful Rate</span>
                    <Badge variant="default">87%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Self-Service Rate</span>
                    <Badge variant="default">64%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}