import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/shared/components/ui';
import { cn } from './ui/utils';

interface StandardTabsProps {
  tabs: {
    value: string;
    label: string;
    content: React.ReactNode;
  }[];
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
  className?: string;
  tabsListClassName?: string;
  tabsContentClassName?: string;
}

export function StandardTabs({
  tabs,
  defaultValue,
  value,
  onValueChange,
  className = "",
  tabsListClassName = "",
  tabsContentClassName = "space-y-6"
}: StandardTabsProps) {
  return (
    <Tabs 
      defaultValue={defaultValue || tabs[0]?.value} 
      value={value}
      onValueChange={onValueChange}
      className={cn("space-y-6", className)}
    >
      <TabsList className={cn(`grid w-full grid-cols-${tabs.length}`, tabsListClassName)}>
        {tabs.map((tab) => (
          <TabsTrigger key={tab.value} value={tab.value}>
            {tab.label}
          </TabsTrigger>
        ))}
      </TabsList>

      {tabs.map((tab) => (
        <TabsContent 
          key={tab.value} 
          value={tab.value} 
          className={tabsContentClassName}
        >
          {tab.content}
        </TabsContent>
      ))}
    </Tabs>
  );
}

// Standard tab styling utilities
export const standardTabClasses = {
  container: "space-y-6",
  tabsList: "grid w-full",
  tabsContent: "space-y-6",
  
  // Grid classes for different tab counts
  gridCols: {
    2: "grid-cols-2",
    3: "grid-cols-3", 
    4: "grid-cols-4",
    5: "grid-cols-5",
    6: "grid-cols-6"
  }
};

// Apple-style tabs with enhanced styling
interface AppleTabsProps extends StandardTabsProps {
  variant?: 'default' | 'apple' | 'premium';
}

export function AppleTabs({
  tabs,
  defaultValue,
  value,
  onValueChange,
  className = "",
  variant = 'apple',
  ...props
}: AppleTabsProps) {
  const variantClasses = {
    default: "",
    apple: "bg-background/50 backdrop-blur-xl rounded-2xl",
    premium: "bg-gradient-to-r from-background/80 via-background to-background/80 backdrop-blur-xl rounded-2xl shadow-lg border border-border/50"
  };

  return (
    <div className={cn(variantClasses[variant], variant !== 'default' && "p-1")}>
      <StandardTabs
        tabs={tabs}
        defaultValue={defaultValue}
        value={value}
        onValueChange={onValueChange}
        className={className}
        tabsListClassName={cn(
          variant === 'apple' && "bg-muted/30 backdrop-blur-sm",
          variant === 'premium' && "bg-gradient-to-r from-muted/30 to-muted/20 backdrop-blur-sm border border-border/30"
        )}
        {...props}
      />
    </div>
  );
}