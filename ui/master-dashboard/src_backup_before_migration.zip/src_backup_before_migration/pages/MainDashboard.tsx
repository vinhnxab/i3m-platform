import { useState } from 'react';
import { Menu } from 'lucide-react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { ThemeToggle } from './ThemeToggle';
import { DesignSystemToggle } from './DesignSystemToggle';
import { LanguageSelector } from './LanguageSelector';
import { EmailPopover, MessagePopover, NotificationPopover, UserMenuPopover } from './HeaderPopovers';
import { useMobile } from './hooks/use-mobile';
import { Sidebar } from './Sidebar';
import { PageTransition } from './PageTransition';
import { I3MLogo } from './I3MLogo';
import { Overview } from './Overview';
import { ERPManagement } from './ERPManagement';
import { CMSManagement } from './CMSManagement';
import { EcommerceManagement } from './EcommerceManagement';
import { SupportManagement } from './SupportManagement';
import { TemplateMarketplace } from './TemplateMarketplace';
import { ServiceMarketplace } from './ServiceMarketplace';
import { Analytics } from './Analytics';
import { CustomerManagement } from './CustomerManagement';
import { AIMLDashboard } from './AIMLDashboard';
import { WorkflowManagement } from './WorkflowManagement';
import { SecurityCenter } from './SecurityCenter';
import { PerformanceMonitoring } from './PerformanceMonitoring';
import { BackupManagement } from './BackupManagement';
import { APIManagement } from './APIManagement';

import { SettingsPanel } from './SettingsPanel';
import { ScrumManagement } from './ScrumManagement';

type ActiveSection = 'overview' | 'erp' | 'cms' | 'ecommerce' | 'support' | 'templates' | 'services' | 'analytics' | 'customers' | 'aiml' | 'workflow' | 'security' | 'performance' | 'backup' | 'api' | 'scrum' | 'settings';

export function MainDashboard() {
  const [activeSection, setActiveSection] = useState<ActiveSection>('overview');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const isMobile = useMobile(1024);

  const getSectionTitle = (section: ActiveSection): string => {
    const titles = {
      overview: 'Dashboard Overview',
      erp: 'ERP Management',
      cms: 'CMS Management',
      ecommerce: 'E-commerce',
      support: 'Support Center',
      templates: 'Template Marketplace',
      services: 'Service Marketplace',
      analytics: 'Analytics',
      customers: 'Customer Management',
      aiml: 'AI/ML Dashboard',
      workflow: 'Workflow Management',
      security: 'Security Center',
      performance: 'Performance Monitor',
      backup: 'Backup Management',
      api: 'API Management',
      scrum: 'Scrum Management',
      settings: 'Settings'
    };
    return titles[section] || 'Dashboard';
  };

  const getSectionDescription = (section: ActiveSection): string => {
    const descriptions = {
      overview: 'System overview and key metrics',
      erp: 'Manage enterprise resources and operations',
      cms: 'Content management and publishing',
      ecommerce: 'Online store and product management',
      support: 'Customer support and ticketing',
      templates: 'Browse and install templates',
      services: 'Discover and integrate services',
      analytics: 'Data insights and reporting',
      customers: 'Customer relationship management',
      aiml: 'Artificial intelligence and machine learning',
      workflow: 'Process automation and workflows',
      security: 'Security settings and monitoring',
      performance: 'System performance analytics',
      backup: 'Data backup and recovery',
      api: 'API configuration and monitoring',
      scrum: 'Agile project management',
      settings: 'System configuration and preferences'
    };
    return descriptions[section] || 'Dashboard';
  };

  const handleSectionChange = (section: ActiveSection) => {
    if (section === activeSection) return;
    
    setIsTransitioning(true);
    // Optimized timing for smooth iPhone-like transitions
    setTimeout(() => {
      setActiveSection(section);
      // Allow the new content to start rendering before removing overlay
      setTimeout(() => {
        setIsTransitioning(false);
      }, 150);
    }, 80);
  };

  const renderContent = () => {
    switch (activeSection) {
      case 'overview':
        return <Overview />;
      case 'erp':
        return <ERPManagement />;
      case 'cms':
        return <CMSManagement />;
      case 'ecommerce':
        return <EcommerceManagement />;
      case 'support':
        return <SupportManagement />;
      case 'templates':
        return <TemplateMarketplace />;
      case 'services':
        return <ServiceMarketplace />;
      case 'analytics':
        return <Analytics />;
      case 'customers':
        return <CustomerManagement />;
      case 'aiml':
        return <AIMLDashboard />;
      case 'workflow':
        return <WorkflowManagement />;
      case 'security':
        return <SecurityCenter />;
      case 'performance':
        return <PerformanceMonitoring />;
      case 'backup':
        return <BackupManagement />;
      case 'api':
        return <APIManagement />;
      case 'scrum':
        return <ScrumManagement />;
      case 'settings':
        return <SettingsPanel />;
      default:
        return <Overview />;
    }
  };

  return (
    <div className="flex h-full w-full bg-gradient-to-br from-background via-background to-background/95">
      {/* Mobile Header */}
      {isMobile && (
        <div className="fixed top-0 left-0 right-0 z-30 bg-background/95 backdrop-blur-xl border-b border-border/30 p-4 lg:hidden">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setMobileOpen(true)}
                className="rounded-xl p-2 bg-muted/50 hover:bg-muted w-10 h-10 min-w-[2.5rem] min-h-[2.5rem] aspect-square flex items-center justify-center"
              >
                <Menu className="w-5 h-5 flex-shrink-0" />
              </Button>
              <div className="flex items-center space-x-3">
                <I3MLogo size="sm" animated={false} theme="auto" />
                <div>
                  <h1 className="text-lg font-semibold">{getSectionTitle(activeSection)}</h1>
                  <p className="text-sm text-muted-foreground">{getSectionDescription(activeSection)}</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {/* Mobile Design System Toggle */}
              <DesignSystemToggle />
              
              {/* Mobile Theme Toggle */}
              <ThemeToggle />
              
              {/* Mobile Language Selector */}
              <LanguageSelector />
              
              {/* Mobile Email Popover */}
              <EmailPopover isMobile={true} />
              
              {/* Mobile Message Popover */}
              <MessagePopover isMobile={true} />
              
              {/* Mobile Notification Popover */}
              <NotificationPopover isMobile={true} />
              
              {/* Mobile User Menu Popover */}
              <UserMenuPopover isMobile={true} />
            </div>
          </div>
        </div>
      )}

      <Sidebar 
        activeSection={activeSection} 
        onSectionChange={handleSectionChange}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        isMobile={isMobile}
        mobileOpen={mobileOpen}
        onMobileToggle={() => setMobileOpen(!mobileOpen)}
      />
      
      <main className="flex-1 h-full overflow-hidden relative flex flex-col">
        {/* Desktop Header */}
        {!isMobile && (
          <div className="w-full bg-background/95 backdrop-blur-xl border-b border-border/30 px-4 lg:px-3 py-4 flex-shrink-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <I3MLogo size="md" animated={false} theme="auto" />
                <div>
                  <h1 className="text-xl font-semibold text-foreground">{getSectionTitle(activeSection)}</h1>
                  <div className="text-sm text-muted-foreground">{getSectionDescription(activeSection)}</div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                {/* Design System Toggle */}
                <DesignSystemToggle />
                
                {/* Theme Toggle */}
                <ThemeToggle />
                
                {/* Desktop Email Popover */}
                <EmailPopover />
                
                {/* Desktop Message Popover */}
                <MessagePopover />
                
                {/* Desktop Notification Popover */}
                <NotificationPopover />
                
                {/* Desktop User Menu Popover */}
                <UserMenuPopover />
              </div>
            </div>
          </div>
        )}
        
        {/* Content Area with responsive padding */}
        <div className={`flex-1 overflow-y-auto bg-gradient-to-br from-background/50 via-background to-muted/20 ${
          isMobile ? 'pt-20' : ''
        }`}>
          <div className="w-full relative">
            {/* Enhanced loading overlay with iPhone-style blur */}
            {isTransitioning && (
              <motion.div
                initial={{ opacity: 0, scale: 1.02 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{
                  type: "spring",
                  damping: 25,
                  stiffness: 300,
                  mass: 0.6,
                  duration: 0.3
                }}
                className="absolute inset-0 bg-background/80 backdrop-blur-xl z-10 flex items-center justify-center"
                style={{ willChange: "transform, opacity" }}
              >
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="flex items-center space-x-3"
                >
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ 
                      duration: 1.2, 
                      repeat: Infinity, 
                      ease: [0.4, 0, 0.6, 1]
                    }}
                    className="w-7 h-7 border-2 border-primary/20 border-t-primary rounded-full"
                    style={{ willChange: "transform" }}
                  />
                  <motion.span
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1, duration: 0.3 }}
                    className="text-sm text-muted-foreground font-medium"
                  >
                    Loading...
                  </motion.span>
                </motion.div>
              </motion.div>
            )}
            
            {renderContent()}
          </div>
        </div>
        
        {/* Subtle overlay for depth */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background/5 pointer-events-none" />
      </main>

    </div>
  );
}