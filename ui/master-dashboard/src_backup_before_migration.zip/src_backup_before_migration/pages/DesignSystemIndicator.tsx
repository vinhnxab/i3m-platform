import { motion } from 'motion/react';
import { useDesignSystem } from './DesignSystemProvider';
import { Badge } from './ui/badge';
import { 
  Smartphone, 
  Layers, 
  Grid, 
  Target, 
  Zap, 
  Sparkles 
} from 'lucide-react';

export function DesignSystemIndicator() {
  const { designSystem, colorMode } = useDesignSystem();

  const getSystemInfo = () => {
    switch (designSystem) {
      case 'apple':
        return {
          name: 'Apple Design',
          icon: Smartphone,
          color: 'bg-blue-500',
          description: 'iOS-inspired design language'
        };
      case 'material':
        return {
          name: 'Material Design',
          icon: Layers,
          color: 'bg-purple-500',
          description: 'Google\'s Material Design 3'
        };
      case 'fluent':
        return {
          name: 'Fluent Design',
          icon: Grid,
          color: 'bg-blue-600',
          description: 'Microsoft\'s Fluent UI'
        };
      case 'ant':
        return {
          name: 'Ant Design',
          icon: Target,
          color: 'bg-blue-400',
          description: 'Enterprise UI framework'
        };
      case 'chakra':
        return {
          name: 'Chakra UI',
          icon: Zap,
          color: 'bg-teal-500',
          description: 'Modular component library'
        };
      case 'custom':
        return {
          name: 'Custom Theme',
          icon: Sparkles,
          color: 'bg-violet-500',
          description: 'Unique design system'
        };
      default:
        return {
          name: 'Apple Design',
          icon: Smartphone,
          color: 'bg-blue-500',
          description: 'iOS-inspired design language'
        };
    }
  };

  const systemInfo = getSystemInfo();
  const Icon = systemInfo.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="fixed bottom-3 left-3 sm:bottom-4 sm:left-4 z-20"
    >
      <motion.div
        className="flex items-center space-x-1.5 sm:space-x-2 px-2 py-1.5 sm:px-3 sm:py-2 bg-card/95 backdrop-blur-xl border border-border/50 rounded-lg sm:rounded-xl shadow-lg max-w-[200px] sm:max-w-none"
        whileHover={{ scale: 1.02 }}
        transition={{ type: "spring", damping: 20, stiffness: 300 }}
      >
        <div className={`p-1 sm:p-1.5 rounded-md sm:rounded-lg ${systemInfo.color} flex-shrink-0`}>
          <Icon className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-white" />
        </div>
        
        <div className="flex flex-col min-w-0 flex-1">
          <div className="flex items-center space-x-1 sm:space-x-2">
            <span className="text-xs font-semibold text-foreground truncate">
              {systemInfo.name}
            </span>
            <Badge 
              variant="secondary" 
              className="text-xs px-1 py-0.5 sm:px-1.5 sm:py-0.5 rounded-full flex-shrink-0"
            >
              {colorMode}
            </Badge>
          </div>
          <span className="text-xs text-muted-foreground hidden lg:block truncate">
            {systemInfo.description}
          </span>
        </div>
      </motion.div>
    </motion.div>
  );
}