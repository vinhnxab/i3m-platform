import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { 
  MessageSquare, 
  X, 
  Bell,
  CheckCircle,
  Clock,
  AlertCircle
} from 'lucide-react';

interface ChatNotification {
  id: number;
  type: 'new_message' | 'new_chat' | 'agent_join' | 'chat_resolved' | 'urgent_message';
  title: string;
  message: string;
  customer?: {
    name: string;
    avatar?: string;
    company: string;
  };
  agent?: {
    name: string;
    avatar?: string;
  };
  chatId: number;
  timestamp: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  isRead: boolean;
}

export function ChatNotificationSystem() {
  const [notifications, setNotifications] = useState<ChatNotification[]>([
    {
      id: 1,
      type: 'new_message',
      title: 'New Message',
      message: 'I need urgent help with API integration',
      customer: {
        name: 'John Doe',
        avatar: '',
        company: 'TechCorp Inc.'
      },
      chatId: 1,
      timestamp: '2 minutes ago',
      priority: 'urgent',
      isRead: false
    },
    {
      id: 2,
      type: 'new_chat',
      title: 'New Chat Request',
      message: 'Customer requesting support for billing issues',
      customer: {
        name: 'Emily Chen',
        avatar: '',
        company: 'Global Solutions'
      },
      chatId: 2,
      timestamp: '5 minutes ago',
      priority: 'medium',
      isRead: false
    },
    {
      id: 3,
      type: 'agent_join',
      title: 'Agent Joined Chat',
      message: 'Sarah Wilson joined the conversation',
      agent: {
        name: 'Sarah Wilson',
        avatar: ''
      },
      chatId: 1,
      timestamp: '8 minutes ago',
      priority: 'low',
      isRead: true
    },
    {
      id: 4,
      type: 'urgent_message',
      title: 'Urgent Message',
      message: 'Payment processing is completely down!',
      customer: {
        name: 'Mike Johnson',
        avatar: '',
        company: 'Enterprise Corp'
      },
      chatId: 3,
      timestamp: '1 minute ago',
      priority: 'urgent',
      isRead: false
    }
  ]);

  const [isOpen, setIsOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  // Simulate new notifications
  useEffect(() => {
    const interval = setInterval(() => {
      // Randomly add new notifications for demo
      if (Math.random() > 0.8) {
        const newNotification: ChatNotification = {
          id: Date.now(),
          type: 'new_message',
          title: 'New Message',
          message: 'Hello, I need help with my account',
          customer: {
            name: 'New Customer',
            avatar: '',
            company: 'Demo Company'
          },
          chatId: Math.floor(Math.random() * 100),
          timestamp: 'Just now',
          priority: 'medium',
          isRead: false
        };
        
        setNotifications(prev => [newNotification, ...prev.slice(0, 9)]);
        
        // Play notification sound
        if (soundEnabled) {
          // In a real app, you would play a sound here
          console.log('🔔 New chat notification');
        }
      }
    }, 10000); // Check every 10 seconds

    return () => clearInterval(interval);
  }, [soundEnabled]);

  const markAsRead = (notificationId: number) => {
    setNotifications(prev =>
      prev.map(n =>
        n.id === notificationId ? { ...n, isRead: true } : n
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev =>
      prev.map(n => ({ ...n, isRead: true }))
    );
  };

  const removeNotification = (notificationId: number) => {
    setNotifications(prev =>
      prev.filter(n => n.id !== notificationId)
    );
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'new_message':
      case 'urgent_message':
        return <MessageSquare className="w-4 h-4" />;
      case 'new_chat':
        return <MessageSquare className="w-4 h-4" />;
      case 'agent_join':
        return <CheckCircle className="w-4 h-4" />;
      case 'chat_resolved':
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <Bell className="w-4 h-4" />;
    }
  };

  return (
    <div className="fixed top-4 right-4 z-50">
      {/* Notification Bell */}
      <div className="relative">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsOpen(!isOpen)}
          className="relative"
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center text-xs p-0"
            >
              {unreadCount > 9 ? '9+' : unreadCount}
            </Badge>
          )}
        </Button>

        {/* Notifications Panel */}
        {isOpen && (
          <Card className="absolute top-12 right-0 w-96 max-h-96 overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="font-semibold">Chat Notifications</h3>
              <div className="flex items-center space-x-2">
                {unreadCount > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={markAllAsRead}
                    className="text-xs"
                  >
                    Mark all read
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsOpen(false)}
                  className="h-6 w-6 p-0"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="max-h-80 overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="p-8 text-center text-muted-foreground">
                  <Bell className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No notifications</p>
                </div>
              ) : (
                <div className="divide-y">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 hover:bg-muted/50 cursor-pointer transition-colors ${
                        !notification.isRead ? 'bg-blue-50/50 border-l-4 border-l-blue-500' : ''
                      }`}
                      onClick={() => {
                        markAsRead(notification.id);
                        // In a real app, you would navigate to the chat
                        console.log('Navigate to chat:', notification.chatId);
                      }}
                    >
                      <div className="flex items-start space-x-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          notification.type === 'urgent_message' ? 'bg-red-100 text-red-600' :
                          notification.type === 'new_chat' ? 'bg-blue-100 text-blue-600' :
                          notification.type === 'agent_join' ? 'bg-green-100 text-green-600' :
                          'bg-gray-100 text-gray-600'
                        }`}>
                          {getTypeIcon(notification.type)}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium text-sm">{notification.title}</h4>
                            <div className="flex items-center space-x-2">
                              <div className={`w-2 h-2 rounded-full ${getPriorityColor(notification.priority)}`} />
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  removeNotification(notification.id);
                                }}
                                className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100"
                              >
                                <X className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>

                          <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                            {notification.message}
                          </p>

                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              {notification.customer && (
                                <div className="flex items-center space-x-2">
                                  <Avatar className="w-4 h-4">
                                    <AvatarImage src={notification.customer.avatar} />
                                    <AvatarFallback className="text-xs">
                                      {notification.customer.name.charAt(0)}
                                    </AvatarFallback>
                                  </Avatar>
                                  <span className="text-xs text-muted-foreground">
                                    {notification.customer.name} • {notification.customer.company}
                                  </span>
                                </div>
                              )}
                              {notification.agent && (
                                <div className="flex items-center space-x-2">
                                  <Avatar className="w-4 h-4">
                                    <AvatarImage src={notification.agent.avatar} />
                                    <AvatarFallback className="text-xs">
                                      {notification.agent.name.charAt(0)}
                                    </AvatarFallback>
                                  </Avatar>
                                  <span className="text-xs text-muted-foreground">
                                    {notification.agent.name}
                                  </span>
                                </div>
                              )}
                            </div>
                            <span className="text-xs text-muted-foreground">
                              {notification.timestamp}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {notifications.length > 0 && (
              <div className="p-4 border-t bg-muted/20">
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full text-xs"
                  onClick={() => {
                    // Navigate to full chat management
                    console.log('Open full chat management');
                    setIsOpen(false);
                  }}
                >
                  View All Chats
                </Button>
              </div>
            )}
          </Card>
        )}
      </div>
    </div>
  );
}