import React, { useState } from 'react';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { 
  Play, 
  Pause, 
  Plus, 
  Search,
  Filter,
  AlertCircle,
  CheckCircle,
  Circle,
  Flag,
  Clock,
  User,
  Edit
} from 'lucide-react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  Button, 
  Badge, 
  Progress, 
  Input, 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger, 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  Label, 
  Textarea, 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/shared/components/ui';

interface Task {
  id: string;
  title: string;
  description: string;
  assignee: {
    id: string;
    name: string;
    avatar: string;
  };
  storyPoints: number;
  priority: 'low' | 'medium' | 'high' | 'critical';
  labels: string[];
  type: 'story' | 'bug' | 'task' | 'epic';
  status: 'backlog' | 'todo' | 'in-progress' | 'review' | 'testing' | 'done' | 'deployed';
  createdAt: string;
  dueDate?: string;
}

interface Sprint {
  id: string;
  name: string;
  goal: string;
  startDate: string;
  endDate: string;
  status: 'planning' | 'active' | 'completed';
  capacity: number;
  completedPoints: number;
}

interface TaskCardProps {
  task: Task;
  onEdit: (task: Task) => void;
}

const TaskCard: React.FC<TaskCardProps> = ({ task, onEdit }) => {
  const [{ isDragging }, drag] = useDrag({
    type: 'task',
    item: { id: task.id },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-500/10 text-red-600 border-red-500/20';
      case 'high': return 'bg-orange-500/10 text-orange-600 border-orange-500/20';
      case 'medium': return 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20';
      case 'low': return 'bg-green-500/10 text-green-600 border-green-500/20';
      default: return 'bg-gray-500/10 text-gray-600 border-gray-500/20';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'story': return <Circle className="w-3 h-3" />;
      case 'bug': return <AlertCircle className="w-3 h-3" />;
      case 'task': return <CheckCircle className="w-3 h-3" />;
      case 'epic': return <Flag className="w-3 h-3" />;
      default: return <Circle className="w-3 h-3" />;
    }
  };

  return (
    <div
      ref={drag as any}
      className={`
        bg-card/90 backdrop-blur-xl border-0 rounded-xl p-3 sm:p-4 mb-3 sm:mb-4 
        shadow-lg cursor-pointer transition-all duration-200
        hover:scale-[1.02] hover:shadow-xl group min-h-[120px] sm:min-h-[140px] max-w-full
        ${isDragging ? 'opacity-50 rotate-2 scale-105' : ''}
        border border-border/20 hover:border-border/40
      `}
      onClick={() => onEdit(task)}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <div className="flex-shrink-0">
            {getTypeIcon(task.type)}
          </div>
          <h4 className="text-sm font-semibold text-foreground line-clamp-2 flex-1">{task.title}</h4>
        </div>
        <Badge variant="outline" className={`text-xs px-2 py-1 rounded-full border flex-shrink-0 ml-2 ${getPriorityColor(task.priority)}`}>
          {task.priority}
        </Badge>
      </div>
      
      <p className="text-xs text-muted-foreground mb-4 line-clamp-2 leading-relaxed">{task.description}</p>
      
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <div className="w-7 h-7 bg-gradient-to-br from-primary/10 to-primary/5 rounded-full flex items-center justify-center flex-shrink-0">
            <User className="w-3.5 h-3.5 text-primary" />
          </div>
          <span className="text-xs font-medium text-muted-foreground truncate">{task.assignee.name}</span>
        </div>
        
        <div className="flex items-center gap-2 flex-shrink-0">
          <Badge variant="secondary" className="text-xs px-2.5 py-1 rounded-full bg-primary/10 text-primary border-primary/20 font-semibold">
            {task.storyPoints} SP
          </Badge>
        </div>
      </div>
      
      {task.dueDate && (
        <div className="flex items-center gap-1 text-xs text-muted-foreground mt-2 pt-2 border-t border-border/30">
          <Clock className="w-3 h-3 flex-shrink-0" />
          <span>Due: {new Date(task.dueDate).toLocaleDateString('vi-VN')}</span>
        </div>
      )}
      
      {task.labels.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mt-3">
          {task.labels.slice(0, 2).map((label) => (
            <Badge key={label} variant="outline" className="text-xs px-2 py-0.5 rounded-md border-border/30 bg-muted/20 font-medium">
              {label}
            </Badge>
          ))}
          {task.labels.length > 2 && (
            <Badge variant="outline" className="text-xs px-2 py-0.5 rounded-md border-border/30 bg-muted/20 font-medium">
              +{task.labels.length - 2}
            </Badge>
          )}
        </div>
      )}
    </div>
  );
};

interface ColumnProps {
  title: string;
  status: string;
  tasks: Task[];
  onDrop: (taskId: string, newStatus: string) => void;
  onEdit: (task: Task) => void;
}

const Column: React.FC<ColumnProps> = ({ title, status, tasks, onDrop, onEdit }) => {
  const [{ isOver }, drop] = useDrop({
    accept: 'task',
    drop: (item: { id: string }) => {
      onDrop(item.id, status);
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
  });

  const getColumnColor = (status: string) => {
    switch (status) {
      case 'backlog': return 'border-l-gray-400';
      case 'todo': return 'border-l-blue-400';
      case 'in-progress': return 'border-l-yellow-400';
      case 'review': return 'border-l-orange-400';
      case 'testing': return 'border-l-purple-400';
      case 'done': return 'border-l-green-400';
      case 'deployed': return 'border-l-emerald-400';
      default: return 'border-l-gray-400';
    }
  };

  return (
    <div 
      ref={drop as any}
      className={`
        flex flex-col h-full w-[280px] sm:w-[320px] lg:w-[360px] min-w-[280px] sm:min-w-[320px] lg:min-w-[360px] 
        bg-card/60 backdrop-blur-xl rounded-2xl p-3 sm:p-4 lg:p-5 border-0 shadow-lg
        transition-all duration-200 ${isOver ? 'scale-[1.02] shadow-xl' : ''}
        border-l-4 ${getColumnColor(status)}
      `}
    >
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <h3 className="font-semibold text-foreground text-base">{title}</h3>
          <Badge variant="secondary" className="text-xs px-2.5 py-1 rounded-full bg-muted/30 text-muted-foreground font-medium">
            {tasks.length}
          </Badge>
        </div>
        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-accent/50 rounded-xl">
          <Plus className="w-4 h-4" />
        </Button>
      </div>
      
      <div className="flex-1 overflow-y-auto scrollbar-hide">
        {tasks.map((task) => (
          <TaskCard key={task.id} task={task} onEdit={onEdit} />
        ))}
        
        {tasks.length === 0 && (
          <div className="flex items-center justify-center h-32 sm:h-36 lg:h-40 text-muted-foreground text-sm border-2 border-dashed border-border/30 rounded-xl bg-muted/10">
            <div className="text-center">
              <div className="text-muted-foreground/50 mb-2">
                <Plus className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 mx-auto" />
              </div>
              <div className="text-xs sm:text-sm">Thêm task mới</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

interface TaskDialogProps {
  task: Task | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (task: Task) => void;
}

const TaskDialog: React.FC<TaskDialogProps> = ({ task, isOpen, onClose, onSave }) => {
  const [formData, setFormData] = useState<Partial<Task>>(
    task || {
      title: '',
      description: '',
      storyPoints: 1,
      priority: 'medium',
      type: 'story',
      status: 'backlog',
      labels: [],
      assignee: { id: '1', name: 'Unassigned', avatar: '' }
    }
  );

  const handleSave = () => {
    if (formData.title && formData.description) {
      onSave({
        ...formData,
        id: task?.id || Date.now().toString(),
        createdAt: task?.createdAt || new Date().toISOString().split('T')[0]
      } as Task);
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-card/95 backdrop-blur-xl border-0 rounded-2xl shadow-2xl">
        <DialogHeader>
          <DialogTitle className="text-foreground">
            {task ? 'Chỉnh sửa Task' : 'Tạo Task mới'}
          </DialogTitle>
        </DialogHeader>
        
        <div className="w-full px-4 lg:px-6 py-4 lg:py-6 space-y-4 lg:space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-foreground">Tiêu đề</Label>
            <Input
              id="title"
              value={formData.title || ''}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="rounded-xl border-border/50 bg-input/50"
              placeholder="Nhập tiêu đề task..."
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description" className="text-foreground">Mô tả</Label>
            <Textarea
              id="description"
              value={formData.description || ''}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="rounded-xl border-border/50 bg-input/50"
              placeholder="Mô tả chi tiết task..."
              rows={3}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-foreground">Loại</Label>
              <Select value={formData.type || 'story'} onValueChange={(value: string) => setFormData({ ...formData, type: value as any })}>
                <SelectTrigger className="rounded-xl border-border/50 bg-input/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-card/95 backdrop-blur-xl border-0 rounded-xl shadow-xl">
                  <SelectItem value="story">Story</SelectItem>
                  <SelectItem value="task">Task</SelectItem>
                  <SelectItem value="bug">Bug</SelectItem>
                  <SelectItem value="epic">Epic</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label className="text-foreground">Ưu tiên</Label>
              <Select value={formData.priority || 'medium'} onValueChange={(value: string) => setFormData({ ...formData, priority: value as any })}>
                <SelectTrigger className="rounded-xl border-border/50 bg-input/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-card/95 backdrop-blur-xl border-0 rounded-xl shadow-xl">
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-foreground">Story Points</Label>
              <Input
                type="number"
                min="1"
                max="21"
                value={formData.storyPoints || 1}
                onChange={(e) => setFormData({ ...formData, storyPoints: parseInt(e.target.value) || 1 })}
                className="rounded-xl border-border/50 bg-input/50"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-foreground">Trạng thái</Label>
              <Select value={formData.status || 'backlog'} onValueChange={(value: string) => setFormData({ ...formData, status: value as any })}>
                <SelectTrigger className="rounded-xl border-border/50 bg-input/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-card/95 backdrop-blur-xl border-0 rounded-xl shadow-xl">
                  <SelectItem value="backlog">Backlog</SelectItem>
                  <SelectItem value="todo">To Do</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="review">Review</SelectItem>
                  <SelectItem value="testing">Testing</SelectItem>
                  <SelectItem value="done">Done</SelectItem>
                  <SelectItem value="deployed">Deployed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <Button 
              variant="outline" 
              onClick={onClose}
              className="rounded-xl border-border/50 hover:bg-accent/50"
            >
              Hủy
            </Button>
            <Button 
              onClick={handleSave}
              className="rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              {task ? 'Cập nhật' : 'Tạo mới'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export const ScrumManagement: React.FC = () => {
  const [currentSprint] = useState<Sprint>({
    id: '1',
    name: 'Sprint 24 - Q1 2024',
    goal: 'Hoàn thiện tính năng user management và dashboard analytics',
    startDate: '2024-01-15',
    endDate: '2024-01-29',
    status: 'active',
    capacity: 84,
    completedPoints: 52
  });

  const [hasScrolled, setHasScrolled] = useState(false);

  const [tasks, setTasks] = useState<Task[]>([
    // Backlog
    {
      id: '1',
      title: 'Setup automated testing pipeline',
      description: 'Thiết lập CI/CD pipeline và viết unit tests cho các modules chính của hệ thống',
      assignee: { id: '4', name: 'Phạm Thị D', avatar: '' },
      storyPoints: 13,
      priority: 'low',
      labels: ['DevOps', 'Testing'],
      type: 'task',
      status: 'backlog',
      createdAt: '2024-01-18'
    },
    {
      id: '2',
      title: 'API Rate Limiting Implementation',
      description: 'Implement rate limiting cho các API endpoints để tránh DDoS và abuse',
      assignee: { id: '3', name: 'Lê Văn C', avatar: '' },
      storyPoints: 8,
      priority: 'medium',
      labels: ['Backend', 'Security'],
      type: 'story',
      status: 'backlog',
      createdAt: '2024-01-19'
    },
    {
      id: '3',
      title: 'Mobile App Push Notifications',
      description: 'Tích hợp Firebase push notifications cho mobile application',
      assignee: { id: '6', name: 'Nguyễn Thị F', avatar: '' },
      storyPoints: 5,
      priority: 'low',
      labels: ['Mobile', 'Feature'],
      type: 'story',
      status: 'backlog',
      createdAt: '2024-01-20'
    },
    
    // Todo
    {
      id: '4',
      title: 'Fix bug login authentication',
      description: 'Khắc phục lỗi không thể đăng nhập với một số tài khoản đặc biệt có ký tự đặc biệt',
      assignee: { id: '2', name: 'Trần Thị B', avatar: '' },
      storyPoints: 3,
      priority: 'critical',
      labels: ['Bug', 'Backend'],
      type: 'bug',
      status: 'todo',
      createdAt: '2024-01-17',
      dueDate: '2024-01-20'
    },
    {
      id: '5',
      title: 'Database Migration Optimization',
      description: 'Tối ưu hóa quá trình migration database để giảm downtime',
      assignee: { id: '7', name: 'Võ Văn G', avatar: '' },
      storyPoints: 8,
      priority: 'high',
      labels: ['Database', 'Performance'],
      type: 'task',
      status: 'todo',
      createdAt: '2024-01-18',
      dueDate: '2024-01-25'
    },
    {
      id: '6',
      title: 'Email Template Redesign',
      description: 'Thiết kế lại email templates cho notifications và marketing campaigns',
      assignee: { id: '1', name: 'Nguyễn Văn A', avatar: '' },
      storyPoints: 5,
      priority: 'medium',
      labels: ['UI/UX', 'Email'],
      type: 'story',
      status: 'todo',
      createdAt: '2024-01-19',
      dueDate: '2024-01-26'
    },
    
    // In Progress
    {
      id: '7',
      title: 'Thiết kế UI cho user profile page',
      description: 'Tạo mockup và implement giao diện user profile với các tính năng edit thông tin cá nhân',
      assignee: { id: '1', name: 'Nguyễn Văn A', avatar: '' },
      storyPoints: 5,
      priority: 'high',
      labels: ['UI/UX', 'Frontend'],
      type: 'story',
      status: 'in-progress',
      createdAt: '2024-01-16',
      dueDate: '2024-01-25'
    },
    {
      id: '8',
      title: 'Payment Gateway Integration',
      description: 'Tích hợp VNPay và MoMo payment gateway cho e-commerce module',
      assignee: { id: '3', name: 'Lê Văn C', avatar: '' },
      storyPoints: 13,
      priority: 'critical',
      labels: ['Payment', 'Backend'],
      type: 'story',
      status: 'in-progress',
      createdAt: '2024-01-15',
      dueDate: '2024-01-28'
    },
    {
      id: '9',
      title: 'Search Performance Optimization',
      description: 'Cải thiện hiệu suất search engine với Elasticsearch implementation',
      assignee: { id: '7', name: 'Võ Văn G', avatar: '' },
      storyPoints: 8,
      priority: 'medium',
      labels: ['Search', 'Performance'],
      type: 'task',
      status: 'in-progress',
      createdAt: '2024-01-17',
      dueDate: '2024-01-30'
    },
    
    // Review
    {
      id: '10',
      title: 'Implement real-time notifications',
      description: 'Tích hợp WebSocket để hiển thị thông báo real-time cho người dùng trong toàn hệ thống',
      assignee: { id: '3', name: 'Lê Văn C', avatar: '' },
      storyPoints: 8,
      priority: 'medium',
      labels: ['Feature', 'Backend', 'WebSocket'],
      type: 'story',
      status: 'review',
      createdAt: '2024-01-15',
      dueDate: '2024-01-28'
    },
    {
      id: '11',
      title: 'Multi-language Support',
      description: 'Implement internationalization (i18n) cho frontend với support 10+ ngôn ngữ',
      assignee: { id: '1', name: 'Nguyễn Văn A', avatar: '' },
      storyPoints: 13,
      priority: 'high',
      labels: ['Frontend', 'i18n'],
      type: 'story',
      status: 'review',
      createdAt: '2024-01-14',
      dueDate: '2024-01-27'
    },
    
    // Testing
    {
      id: '12',
      title: 'QA Testing User Stories',
      description: 'Thực hiện testing toàn diện cho các user stories đã hoàn thành trong sprint hiện tại',
      assignee: { id: '5', name: 'Hoàng Văn E', avatar: '' },
      storyPoints: 3,
      priority: 'high',
      labels: ['QA', 'Testing'],
      type: 'task',
      status: 'testing',
      createdAt: '2024-01-20',
      dueDate: '2024-01-26'
    },
    {
      id: '13',
      title: 'Security Audit Implementation',
      description: 'Thực hiện security audit và penetration testing cho toàn hệ thống',
      assignee: { id: '8', name: 'Đặng Thị H', avatar: '' },
      storyPoints: 8,
      priority: 'critical',
      labels: ['Security', 'Audit'],
      type: 'task',
      status: 'testing',
      createdAt: '2024-01-18',
      dueDate: '2024-01-29'
    },
    
    // Done
    {
      id: '14',
      title: 'Dashboard analytics improvement',
      description: 'Cải thiện hiệu suất và thêm các chart mới cho dashboard analytics với real-time data',
      assignee: { id: '1', name: 'Nguyễn Văn A', avatar: '' },
      storyPoints: 5,
      priority: 'medium',
      labels: ['Analytics', 'Frontend'],
      type: 'story',
      status: 'done',
      createdAt: '2024-01-14',
      dueDate: '2024-01-22'
    },
    {
      id: '15',
      title: 'User Authentication Refactor',
      description: 'Refactor user authentication system với JWT và refresh token implementation',
      assignee: { id: '2', name: 'Trần Thị B', avatar: '' },
      storyPoints: 8,
      priority: 'high',
      labels: ['Auth', 'Backend'],
      type: 'story',
      status: 'done',
      createdAt: '2024-01-13',
      dueDate: '2024-01-21'
    },
    {
      id: '16',
      title: 'Cache Layer Implementation',
      description: 'Implement Redis cache layer để cải thiện performance cho database queries',
      assignee: { id: '7', name: 'Võ Văn G', avatar: '' },
      storyPoints: 5,
      priority: 'medium',
      labels: ['Performance', 'Cache'],
      type: 'task',
      status: 'done',
      createdAt: '2024-01-12',
      dueDate: '2024-01-19'
    },
    
    // Deployed
    {
      id: '17',
      title: 'Deploy to Production',
      description: 'Deploy các features đã được testing và approved lên production environment',
      assignee: { id: '4', name: 'Phạm Thị D', avatar: '' },
      storyPoints: 2,
      priority: 'medium',
      labels: ['DevOps', 'Deployment'],
      type: 'task',
      status: 'deployed',
      createdAt: '2024-01-12',
      dueDate: '2024-01-15'
    },
    {
      id: '18',
      title: 'Server Monitoring Setup',
      description: 'Setup monitoring và alerting system với Grafana và Prometheus',
      assignee: { id: '4', name: 'Phạm Thị D', avatar: '' },
      storyPoints: 8,
      priority: 'high',
      labels: ['DevOps', 'Monitoring'],
      type: 'task',
      status: 'deployed',
      createdAt: '2024-01-10',
      dueDate: '2024-01-17'
    }
  ]);

  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleDrop = (taskId: string, newStatus: string) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId ? { ...task, status: newStatus as any } : task
    ));
  };

  const handleEditTask = (task: Task) => {
    setSelectedTask(task);
    setIsDialogOpen(true);
  };

  const handleSaveTask = (updatedTask: Task) => {
    setTasks(prev => prev.map(task => 
      task.id === updatedTask.id ? updatedTask : task
    ));
  };

  const getTasksByStatus = (status: string) => {
    return tasks.filter(task => task.status === status);
  };

  const sprintProgress = (currentSprint.completedPoints / currentSprint.capacity) * 100;

  const columns = [
    { title: 'Backlog', status: 'backlog' },
    { title: 'To Do', status: 'todo' },
    { title: 'In Progress', status: 'in-progress' },
    { title: 'Review', status: 'review' },
    { title: 'Testing', status: 'testing' },
    { title: 'Done', status: 'done' },
    { title: 'Deployed', status: 'deployed' }
  ];

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="w-full px-4 lg:px-6 py-4 lg:py-6 space-y-4 lg:space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 gap-2">
          <div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-semibold text-foreground tracking-tight">Scrum Management</h1>
            <p className="text-base lg:text-lg text-muted-foreground font-medium mt-1 lg:mt-2">Quản lý sprint, backlog và theo dõi tiến độ phát triển theo phương pháp Scrum</p>
          </div>
          <div className="flex items-center space-x-3">
            <Badge variant="outline" className="text-chart-2 border-current bg-chart-2/10 backdrop-blur-sm px-3 lg:px-4 py-1.5 lg:py-2 rounded-full font-semibold text-sm">
              <CheckCircle className="w-3 lg:w-4 h-3 lg:h-4 mr-1 lg:mr-2" />
              All Systems Operational
            </Badge>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  placeholder="Tìm kiếm tasks..."
                  className="pl-10 pr-4 w-48 sm:w-56 lg:w-64 rounded-xl border-border/50 bg-input/50"
                />
              </div>
              <Button variant="outline" size="sm" className="rounded-xl border-border/50 hover:bg-accent/50 hidden sm:flex">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
              <Button size="sm" className="rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground">
                <Plus className="w-4 h-4 mr-1 sm:mr-2" />
                <span className="hidden sm:inline">New Task</span>
                <span className="sm:hidden">New</span>
              </Button>
            </div>
          </div>
        </div>

        {/* Main Content - Scrollable */}
        <div className="flex-1 overflow-hidden">
          <Tabs defaultValue="board" className="h-full flex flex-col">
            <div className="flex-shrink-0 px-4 sm:px-6 pb-0">
              <TabsList className="grid w-full grid-cols-4 bg-muted/30 rounded-xl p-1 h-10 sm:h-12">
                <TabsTrigger 
                  value="board" 
                  className="rounded-lg data-[state=active]:bg-card data-[state=active]:shadow-sm font-medium px-2 sm:px-4 text-xs sm:text-sm"
                >
                  Board
                </TabsTrigger>
                <TabsTrigger 
                  value="backlog" 
                  className="rounded-lg data-[state=active]:bg-card data-[state=active]:shadow-sm font-medium px-2 sm:px-4 text-xs sm:text-sm"
                >
                  Backlog
                </TabsTrigger>
                <TabsTrigger 
                  value="reports" 
                  className="rounded-lg data-[state=active]:bg-card data-[state=active]:shadow-sm font-medium px-2 sm:px-4 text-xs sm:text-sm"
                >
                  Reports
                </TabsTrigger>
                <TabsTrigger 
                  value="team" 
                  className="rounded-lg data-[state=active]:bg-card data-[state=active]:shadow-sm font-medium px-2 sm:px-4 text-xs sm:text-sm"
                >
                  Team
                </TabsTrigger>
              </TabsList>
            </div>

            {/* Board Tab - Horizontal Scroll Layout */}
            <TabsContent value="board" className="flex-1 overflow-hidden">
              <div className="h-full flex flex-col space-y-4 sm:space-y-6 p-4 sm:p-6 pt-2 sm:pt-4">
                {/* Sprint Info Card */}
                <Card className="bg-card/80 backdrop-blur-xl border-0 rounded-2xl shadow-lg flex-shrink-0">
                  <CardHeader className="pb-4">
                    <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                      <div>
                        <CardTitle className="text-foreground">{currentSprint.name}</CardTitle>
                        <p className="text-muted-foreground mt-1">{currentSprint.goal}</p>
                      </div>
                      
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          {currentSprint.status === 'active' ? (
                            <div className="flex items-center gap-2 px-3 py-1 bg-green-500/10 text-green-600 rounded-full border border-green-500/20">
                              <Play className="w-3 h-3" />
                              <span className="text-sm font-medium">Active</span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2 px-3 py-1 bg-yellow-500/10 text-yellow-600 rounded-full border border-yellow-500/20">
                              <Pause className="w-3 h-3" />
                              <span className="text-sm font-medium">Planning</span>
                            </div>
                          )}
                        </div>
                        
                        <div className="text-right">
                          <div className="text-sm text-muted-foreground">
                            {new Date(currentSprint.startDate).toLocaleDateString('vi-VN')} - {new Date(currentSprint.endDate).toLocaleDateString('vi-VN')}
                          </div>
                          <div className="text-sm font-medium text-foreground">
                            {currentSprint.completedPoints}/{currentSprint.capacity} SP
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="pt-0">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Sprint Progress</span>
                        <span className="font-medium text-foreground">{Math.round(sprintProgress)}%</span>
                      </div>
                      <Progress value={sprintProgress} className="h-2 bg-muted/30 rounded-full" />
                    </div>
                  </CardContent>
                </Card>

                {/* Kanban Board Container - Horizontal Scroll */}
                <div className="flex-1 min-h-0">
                  <div className="h-full overflow-x-auto kanban-scroll-container">
                    {/* Scroll hints */}
                    {!hasScrolled && (
                      <>
                        <div className="lg:hidden flex items-center justify-center mb-4 text-xs text-muted-foreground bg-muted/20 rounded-lg py-2 px-4">
                          💡 Vuốt ngang để xem thêm cột
                        </div>
                        <div className="hidden lg:flex items-center justify-center mb-4 text-xs text-muted-foreground/70 bg-background/80 backdrop-blur-sm rounded-full px-3 py-1 border border-border/30">
                          ← → Scroll to see more
                        </div>
                      </>
                    )}
                    
                    <div 
                      className="flex gap-4 sm:gap-5 lg:gap-6 h-full pb-6"
                      style={{ 
                        minWidth: 'calc(280px * 7 + 24px * 6)',
                        width: 'max-content'
                      }}
                      onScroll={() => {
                        if (!hasScrolled) {
                          setHasScrolled(true);
                        }
                      }}
                    >
                      {columns.map((column) => (
                        <Column
                          key={column.status}
                          title={column.title}
                          status={column.status}
                          tasks={getTasksByStatus(column.status)}
                          onDrop={handleDrop}
                          onEdit={handleEditTask}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Other Tabs - Normal Vertical Scroll */}
            <TabsContent value="backlog" className="flex-1 overflow-y-auto p-6 pt-4">
              <div className="w-full px-4 lg:px-6 py-4 lg:py-6 space-y-4 lg:space-y-6">
                <Card className="bg-card/80 backdrop-blur-xl border-0 rounded-2xl shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-foreground">Product Backlog</CardTitle>
                    <p className="text-muted-foreground">
                      Danh sách tất cả user stories và tasks chưa được assign vào sprint
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {tasks.filter(task => task.status === 'backlog').map((task) => (
                        <div key={task.id} className="flex items-center justify-between p-4 bg-muted/20 rounded-xl border border-border/30">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-gradient-to-br from-primary/10 to-primary/5 rounded-lg flex items-center justify-center">
                              {task.type === 'story' && <Circle className="w-4 h-4 text-primary" />}
                              {task.type === 'bug' && <AlertCircle className="w-4 h-4 text-red-500" />}
                              {task.type === 'task' && <CheckCircle className="w-4 h-4 text-green-500" />}
                            </div>
                            <div>
                              <h4 className="font-medium text-foreground">{task.title}</h4>
                              <p className="text-sm text-muted-foreground">{task.description}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <Badge variant="secondary" className="bg-primary/10 text-primary">
                              {task.storyPoints} SP
                            </Badge>
                            <Button variant="ghost" size="sm" onClick={() => handleEditTask(task)}>
                              <Edit className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="reports" className="flex-1 overflow-y-auto p-6 pt-4">
              <div className="w-full px-4 lg:px-6 py-4 lg:py-6 space-y-4 lg:space-y-6">
                <Card className="bg-card/80 backdrop-blur-xl border-0 rounded-2xl shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-foreground">Sprint Reports</CardTitle>
                    <p className="text-muted-foreground">
                      Báo cáo và thống kê về tiến độ sprint
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="text-center p-6 bg-muted/20 rounded-xl">
                        <div className="text-2xl font-semibold text-foreground">{currentSprint.completedPoints}</div>
                        <div className="text-sm text-muted-foreground">Completed Story Points</div>
                      </div>
                      <div className="text-center p-6 bg-muted/20 rounded-xl">
                        <div className="text-2xl font-semibold text-foreground">{currentSprint.capacity}</div>
                        <div className="text-sm text-muted-foreground">Sprint Capacity</div>
                      </div>
                      <div className="text-center p-6 bg-muted/20 rounded-xl">
                        <div className="text-2xl font-semibold text-foreground">{Math.round(sprintProgress)}%</div>
                        <div className="text-sm text-muted-foreground">Progress</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="team" className="flex-1 overflow-y-auto p-6 pt-4">
              <div className="w-full px-4 lg:px-6 py-4 lg:py-6 space-y-4 lg:space-y-6">
                <Card className="bg-card/80 backdrop-blur-xl border-0 rounded-2xl shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-foreground">Team Members</CardTitle>
                    <p className="text-muted-foreground">
                      Thành viên team và workload của từng người
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {['Nguyễn Văn A', 'Trần Thị B', 'Lê Văn C', 'Phạm Thị D', 'Hoàng Văn E'].map((member, index) => (
                        <div key={index} className="flex items-center justify-between p-4 bg-muted/20 rounded-xl border border-border/30">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-gradient-to-br from-primary/10 to-primary/5 rounded-full flex items-center justify-center">
                              <User className="w-5 h-5 text-primary" />
                            </div>
                            <div>
                              <h4 className="font-medium text-foreground">{member}</h4>
                              <p className="text-sm text-muted-foreground">Developer</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-medium text-foreground">
                              {tasks.filter(task => task.assignee.name === member).length} tasks
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {tasks.filter(task => task.assignee.name === member).reduce((sum, task) => sum + task.storyPoints, 0)} SP
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <TaskDialog
          task={selectedTask}
          isOpen={isDialogOpen}
          onClose={() => {
            setIsDialogOpen(false);
            setSelectedTask(null);
          }}
          onSave={handleSaveTask}
        />
      
    </DndProvider>
  );
};