import { cn } from './ui/utils';

interface ResponsiveIconContainerProps {
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  className?: string;
  variant?: 'default' | 'card' | 'badge' | 'button';
}

export function ResponsiveIconContainer({ 
  children, 
  size = 'md', 
  className = '',
  variant = 'default'
}: ResponsiveIconContainerProps) {
  const sizeClasses = {
    sm: 'w-4 h-4 min-w-4 min-h-4',
    md: 'w-5 h-5 min-w-5 min-h-5', 
    lg: 'w-6 h-6 min-w-6 min-h-6',
    xl: 'w-8 h-8 min-w-8 min-h-8',
    '2xl': 'w-10 h-10 min-w-10 min-h-10'
  };

  const variantClasses = {
    default: '',
    card: 'rounded-xl bg-gradient-to-br from-primary/10 to-primary/5',
    badge: 'rounded-lg bg-primary/10',
    button: 'rounded-lg hover:bg-muted/50 transition-colors duration-200'
  };

  return (
    <div className={cn(
      'flex items-center justify-center flex-shrink-0 aspect-square',
      sizeClasses[size],
      variantClasses[variant],
      className
    )}>
      {children}
    </div>
  );
}

// Also export individual icon wrappers for common use cases
export function StatIcon({ icon: Icon, color, size = 'md' }: { 
  icon: any; 
  color?: string; 
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
}) {
  return (
    <ResponsiveIconContainer size={size} variant="card">
      <Icon className={cn('flex-shrink-0', 
        size === 'sm' ? 'w-3 h-3' :
        size === 'md' ? 'w-4 h-4' :
        size === 'lg' ? 'w-5 h-5' :
        size === 'xl' ? 'w-6 h-6' :
        'w-7 h-7',
        color || 'text-primary'
      )} />
    </ResponsiveIconContainer>
  );
}

export function BadgeIcon({ icon: Icon, size = 'sm' }: { 
  icon: any; 
  size?: 'sm' | 'md' | 'lg';
}) {
  return (
    <ResponsiveIconContainer size={size} variant="badge">
      <Icon className={cn('flex-shrink-0 text-primary',
        size === 'sm' ? 'w-3 h-3' :
        size === 'md' ? 'w-4 h-4' :
        'w-5 h-5'
      )} />
    </ResponsiveIconContainer>
  );
}

export function ButtonIcon({ icon: Icon, size = 'md' }: { 
  icon: any; 
  size?: 'sm' | 'md' | 'lg';
}) {
  return (
    <ResponsiveIconContainer size={size} variant="button">
      <Icon className={cn('flex-shrink-0',
        size === 'sm' ? 'w-4 h-4' :
        size === 'md' ? 'w-5 h-5' :
        'w-6 h-6'
      )} />
    </ResponsiveIconContainer>
  );
}