import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { useDesignSystem, type DesignSystem, type ColorMode } from './DesignSystemProvider';
import { useLanguage } from './LanguageProvider';
import { 
  Palette, 
  Smartphone, 
  Monitor, 
  Sun, 
  Moon, 
  Settings, 
  Check,
  Sparkles,
  Layers,
  Zap,
  Target,
  Grid,
  X
} from 'lucide-react';

interface DesignSystemSelectorProps {
  isOpen: boolean;
  onClose: () => void;
}

const designSystems = [
  {
    id: 'apple' as DesignSystem,
    name: 'Apple Design',
    description: 'iOS-inspired with San Francisco typography and smooth interactions',
    icon: Smartphone,
    features: ['Glass Morphism', 'SF Typography', 'Smooth Animations', 'iOS Colors'],
    preview: {
      primary: '#007AFF',
      secondary: '#F2F2F7',
      accent: '#34C759',
      background: '#F8F9FA'
    }
  },
  {
    id: 'material' as DesignSystem,
    name: 'Material Design',
    description: 'Google\'s Material Design with elevation and bold colors',
    icon: Layers,
    features: ['Material You', 'Elevation', 'Bold Typography', 'Dynamic Colors'],
    preview: {
      primary: '#6750A4',
      secondary: '#625B71',
      accent: '#7D5260',
      background: '#FEF7FF'
    }
  },
  {
    id: 'fluent' as DesignSystem,
    name: 'Fluent Design',
    description: 'Microsoft\'s design system with depth and motion',
    icon: Grid,
    features: ['Acrylic Effects', 'Reveal Highlights', 'Smooth Motion', 'Windows 11'],
    preview: {
      primary: '#0078D4',
      secondary: '#F3F2F1',
      accent: '#107C10',
      background: '#FAFAFA'
    }
  },
  {
    id: 'ant' as DesignSystem,
    name: 'Ant Design',
    description: 'Enterprise-class UI with consistent design language',
    icon: Target,
    features: ['Enterprise Ready', 'Data Display', 'Form Controls', 'Consistent'],
    preview: {
      primary: '#1890FF',
      secondary: '#F5F5F5',
      accent: '#52C41A',
      background: '#FFFFFF'
    }
  },
  {
    id: 'chakra' as DesignSystem,
    name: 'Chakra UI',
    description: 'Modular and accessible component library',
    icon: Zap,
    features: ['Accessibility', 'Theme Tokens', 'Composable', 'TypeScript'],
    preview: {
      primary: '#3182CE',
      secondary: '#EDF2F7',
      accent: '#38B2AC',
      background: '#FFFFFF'
    }
  },
  {
    id: 'custom' as DesignSystem,
    name: 'Custom Theme',
    description: 'Create your own unique design system',
    icon: Sparkles,
    features: ['Fully Custom', 'Brand Colors', 'Unique Style', 'Personalized'],
    preview: {
      primary: '#8B5CF6',
      secondary: '#F3F4F6',
      accent: '#F59E0B',
      background: '#F9FAFB'
    }
  }
];

const colorModes = [
  { id: 'light' as ColorMode, name: 'Light', icon: Sun },
  { id: 'dark' as ColorMode, name: 'Dark', icon: Moon },
  { id: 'system' as ColorMode, name: 'System', icon: Monitor },
];

export function DesignSystemSelector({ isOpen, onClose }: DesignSystemSelectorProps) {
  const { designSystem, colorMode, setDesignSystem, setColorMode } = useDesignSystem();
  const { t } = useLanguage();
  const [hoveredSystem, setHoveredSystem] = useState<DesignSystem | null>(null);

  const handleSystemChange = (system: DesignSystem) => {
    setDesignSystem(system);
  };

  const handleModeChange = (mode: ColorMode) => {
    setColorMode(mode);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[200]"
          />
          
          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-xs sm:max-w-lg md:max-w-2xl lg:max-w-4xl max-h-[90vh] overflow-y-auto z-[201] p-3 sm:p-4 lg:p-6"
          >
            <Card className="border-0 shadow-2xl bg-card/95 backdrop-blur-xl rounded-2xl lg:rounded-3xl">
              <CardHeader className="pb-4 lg:pb-6">
                <div className="flex items-start sm:items-center justify-between flex-col sm:flex-row gap-3 sm:gap-0">
                  <div className="flex items-center space-x-2 sm:space-x-3">
                    <div className="p-1.5 sm:p-2 bg-primary/10 rounded-lg sm:rounded-xl">
                      <Palette className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg sm:text-xl lg:text-2xl">{t('design.title')}</CardTitle>
                      <CardDescription className="text-sm sm:text-base hidden sm:block">{t('design.description')}</CardDescription>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onClose}
                    className="rounded-xl p-2 hover:bg-muted/50 self-end sm:self-auto"
                  >
                    <X className="w-4 h-4 sm:w-5 sm:h-5" />
                  </Button>
                </div>
              </CardHeader>

              <CardContent className="space-y-6 lg:space-y-8">
                {/* Color Mode Selection */}
                <div className="space-y-3 lg:space-y-4">
                  <h3 className="font-semibold text-base sm:text-lg">{t('design.colorMode')}</h3>
                  <div className="grid grid-cols-3 gap-2 sm:gap-3">
                    {colorModes.map((mode) => {
                      const Icon = mode.icon;
                      const isActive = colorMode === mode.id;
                      
                      return (
                        <motion.button
                          key={mode.id}
                          onClick={() => handleModeChange(mode.id)}
                          className={`relative p-3 sm:p-4 rounded-xl sm:rounded-2xl border-2 transition-all duration-200 ${
                            isActive 
                              ? 'border-primary bg-primary/5' 
                              : 'border-border hover:border-primary/50 hover:bg-muted/30'
                          }`}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <div className="flex flex-col items-center space-y-1.5 sm:space-y-2">
                            <Icon className={`w-5 h-5 sm:w-6 sm:h-6 ${isActive ? 'text-primary' : 'text-muted-foreground'}`} />
                            <span className={`font-medium text-xs sm:text-sm ${isActive ? 'text-primary' : 'text-foreground'}`}>
                              {t(`design.${mode.id}`)}
                            </span>
                          </div>
                          {isActive && (
                            <motion.div
                              layoutId="activeModeIndicator"
                              className="absolute top-1.5 right-1.5 sm:top-2 sm:right-2 p-0.5 sm:p-1 bg-primary rounded-full"
                              initial={false}
                              transition={{ type: "spring", damping: 20, stiffness: 300 }}
                            >
                              <Check className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-primary-foreground" />
                            </motion.div>
                          )}
                        </motion.button>
                      );
                    })}
                  </div>
                </div>

                {/* Design System Selection */}
                <div className="space-y-3 lg:space-y-4">
                  <h3 className="font-semibold text-base sm:text-lg">{t('design.designSystem')}</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                    {designSystems.map((system) => {
                      const Icon = system.icon;
                      const isActive = designSystem === system.id;
                      const isHovered = hoveredSystem === system.id;
                      
                      return (
                        <motion.div
                          key={system.id}
                          className={`relative p-4 sm:p-5 lg:p-6 rounded-xl sm:rounded-2xl border-2 cursor-pointer transition-all duration-200 ${
                            isActive 
                              ? 'border-primary bg-primary/5' 
                              : 'border-border hover:border-primary/50 hover:bg-muted/30'
                          }`}
                          onClick={() => handleSystemChange(system.id)}
                          onHoverStart={() => setHoveredSystem(system.id)}
                          onHoverEnd={() => setHoveredSystem(null)}
                          whileHover={{ scale: 1.01, y: -2 }}
                          whileTap={{ scale: 0.99 }}
                        >
                          {/* Header */}
                          <div className="flex items-start justify-between mb-3 sm:mb-4">
                            <div className="flex items-start sm:items-center space-x-2 sm:space-x-3 flex-1">
                              <div className={`p-1.5 sm:p-2 rounded-lg sm:rounded-xl flex-shrink-0 ${isActive ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
                                <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
                              </div>
                              <div className="min-w-0 flex-1">
                                <h4 className="font-semibold text-sm sm:text-base truncate">{system.name}</h4>
                                <p className="text-xs sm:text-sm text-muted-foreground line-clamp-2 sm:line-clamp-1">{system.description}</p>
                              </div>
                            </div>
                            {isActive && (
                              <motion.div
                                layoutId="activeSystemIndicator"
                                className="p-0.5 sm:p-1 bg-primary rounded-full flex-shrink-0"
                                initial={false}
                                transition={{ type: "spring", damping: 20, stiffness: 300 }}
                              >
                                <Check className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-primary-foreground" />
                              </motion.div>
                            )}
                          </div>

                          {/* Color Preview */}
                          <div className="flex space-x-1.5 sm:space-x-2 mb-3 sm:mb-4">
                            <div 
                              className="w-5 h-5 sm:w-6 sm:h-6 rounded-md sm:rounded-lg shadow-sm border border-border/50 flex-shrink-0"
                              style={{ backgroundColor: system.preview.primary }}
                            />
                            <div 
                              className="w-5 h-5 sm:w-6 sm:h-6 rounded-md sm:rounded-lg shadow-sm border border-border/50 flex-shrink-0"
                              style={{ backgroundColor: system.preview.secondary }}
                            />
                            <div 
                              className="w-5 h-5 sm:w-6 sm:h-6 rounded-md sm:rounded-lg shadow-sm border border-border/50 flex-shrink-0"
                              style={{ backgroundColor: system.preview.accent }}
                            />
                            <div 
                              className="w-5 h-5 sm:w-6 sm:h-6 rounded-md sm:rounded-lg shadow-sm border border-border/50 flex-shrink-0"
                              style={{ backgroundColor: system.preview.background }}
                            />
                          </div>

                          {/* Features */}
                          <div className="flex flex-wrap gap-1.5 sm:gap-2">
                            {system.features.map((feature, index) => (
                              <Badge 
                                key={index} 
                                variant="secondary" 
                                className="text-xs rounded-full px-2 py-0.5 sm:px-2 sm:py-1"
                              >
                                {feature}
                              </Badge>
                            ))}
                          </div>

                          {/* Hover Animation */}
                          <AnimatePresence>
                            {isHovered && !isActive && (
                              <motion.div
                                initial={{ opacity: 0, scale: 0.8 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.8 }}
                                className="absolute inset-0 bg-primary/5 rounded-2xl pointer-events-none"
                              />
                            )}
                          </AnimatePresence>
                        </motion.div>
                      );
                    })}
                  </div>
                </div>

                {/* Apply Button */}
                <motion.div 
                  className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-3 pt-4 border-t border-border/30"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <Button
                    variant="outline"
                    onClick={onClose}
                    className="rounded-xl px-4 sm:px-6 w-full sm:w-auto"
                  >
                    {t('design.cancel')}
                  </Button>
                  <Button
                    onClick={onClose}
                    className="rounded-xl px-4 sm:px-6 shadow-lg w-full sm:w-auto"
                  >
                    <Settings className="w-4 h-4 mr-2" />
                    {t('design.apply')}
                  </Button>
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}