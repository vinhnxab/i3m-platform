import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { 
  Workflow, 
  Play, 
  Pause, 
  Square,
  GitBranch,
  Clock,
  CheckCircle,
  AlertTriangle,
  Users,
  Calendar,
  Filter,
  Plus,
  Edit,
  Eye,
  MoreHorizontal,
  Zap,
  RefreshCw,
  Settings,
  ArrowRight,
  Timer
} from 'lucide-react';

export function WorkflowManagement() {
  const [activeTab, setActiveTab] = useState('workflows');

  const workflowStats = [
    { title: 'Active Workflows', value: '47', change: '+6', icon: Workflow, color: 'text-blue-500' },
    { title: 'Executions Today', value: '1,234', change: '+18%', icon: Play, color: 'text-green-500' },
    { title: 'Success Rate', value: '96.8%', change: '+2.1%', icon: CheckCircle, color: 'text-purple-500' },
    { title: 'Avg Execution Time', value: '2.4s', change: '-0.3s', icon: Timer, color: 'text-orange-500' },
  ];

  const workflows = [
    {
      id: 1,
      name: 'Customer Onboarding Automation',
      description: 'Automated workflow for new customer setup and welcome sequence',
      status: 'active',
      trigger: 'Customer Registration',
      lastRun: '2024-01-15 14:30',
      executions: 156,
      successRate: 98.7,
      avgTime: '45s',
      category: 'Customer Management',
      steps: 8
    },
    {
      id: 2,
      name: 'Order Processing Pipeline',
      description: 'End-to-end order processing from payment to fulfillment',
      status: 'active',
      trigger: 'Order Placed',
      lastRun: '2024-01-15 14:45',
      executions: 423,
      successRate: 99.2,
      avgTime: '12s',
      category: 'E-commerce',
      steps: 12
    },
    {
      id: 3,
      name: 'Support Ticket Routing',
      description: 'Intelligent routing of support tickets to appropriate agents',
      status: 'active',
      trigger: 'Ticket Created',
      lastRun: '2024-01-15 14:20',
      executions: 89,
      successRate: 94.4,
      avgTime: '3s',
      category: 'Customer Support',
      steps: 6
    },
    {
      id: 4,
      name: 'Inventory Restock Alert',
      description: 'Automated alerts and reorder process for low stock items',
      status: 'paused',
      trigger: 'Stock Level Low',
      lastRun: '2024-01-14 09:15',
      executions: 23,
      successRate: 91.3,
      avgTime: '8s',
      category: 'Inventory',
      steps: 5
    },
    {
      id: 5,
      name: 'Monthly Report Generation',
      description: 'Automated generation and distribution of monthly business reports',
      status: 'scheduled',
      trigger: 'Monthly Schedule',
      lastRun: '2024-01-01 00:00',
      executions: 12,
      successRate: 100,
      avgTime: '2m 30s',
      category: 'Analytics',
      steps: 15
    },
    {
      id: 6,
      name: 'Failed Payment Recovery',
      description: 'Automated retry and notification system for failed payments',
      status: 'active',
      trigger: 'Payment Failed',
      lastRun: '2024-01-15 13:45',
      executions: 34,
      successRate: 76.5,
      avgTime: '25s',
      category: 'Payments',
      steps: 9
    }
  ];

  const executions = [
    {
      id: 1,
      workflow: 'Customer Onboarding Automation',
      status: 'completed',
      startTime: '2024-01-15 14:30:15',
      endTime: '2024-01-15 14:30:58',
      duration: '43s',
      trigger: 'john.doe@example.com registered',
      steps: 8,
      completedSteps: 8
    },
    {
      id: 2,
      workflow: 'Order Processing Pipeline',
      status: 'running',
      startTime: '2024-01-15 14:45:22',
      endTime: null,
      duration: '8s',
      trigger: 'Order #ORD-12345 placed',
      steps: 12,
      completedSteps: 7
    },
    {
      id: 3,
      workflow: 'Support Ticket Routing',
      status: 'completed',
      startTime: '2024-01-15 14:20:11',
      endTime: '2024-01-15 14:20:14',
      duration: '3s',
      trigger: 'Ticket #TKT-789 created',
      steps: 6,
      completedSteps: 6
    },
    {
      id: 4,
      workflow: 'Order Processing Pipeline',
      status: 'failed',
      startTime: '2024-01-15 14:12:45',
      endTime: '2024-01-15 14:12:50',
      duration: '5s',
      trigger: 'Order #ORD-12344 placed',
      steps: 12,
      completedSteps: 4,
      error: 'Payment validation failed'
    }
  ];

  const automationRules = [
    {
      id: 1,
      name: 'High-Value Customer Alert',
      condition: 'Customer lifetime value > $10,000',
      action: 'Assign to VIP support team',
      status: 'active',
      triggered: 23
    },
    {
      id: 2,
      name: 'Urgent Ticket Escalation',
      condition: 'Ticket priority = Critical AND unassigned > 5 minutes',
      action: 'Send alert to supervisors',
      status: 'active',
      triggered: 7
    },
    {
      id: 3,
      name: 'Inventory Alert',
      condition: 'Stock level < 10 AND product category = Electronics',
      action: 'Create purchase order',
      status: 'active',
      triggered: 15
    },
    {
      id: 4,
      name: 'Abandoned Cart Recovery',
      condition: 'Cart value > $100 AND inactive > 1 hour',
      action: 'Send email reminder',
      status: 'paused',
      triggered: 156
    }
  ];

  const templates = [
    { name: 'Customer Onboarding', category: 'Customer Management', steps: 8, description: 'Standard customer welcome workflow' },
    { name: 'Order Fulfillment', category: 'E-commerce', steps: 10, description: 'Complete order processing pipeline' },
    { name: 'Support Escalation', category: 'Customer Support', steps: 6, description: 'Automated ticket escalation process' },
    { name: 'Content Approval', category: 'CMS', steps: 5, description: 'Content review and approval workflow' },
    { name: 'Invoice Processing', category: 'Finance', steps: 7, description: 'Automated invoice generation and sending' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Workflow Management</h1>
          <p className="text-muted-foreground">Automate business processes and workflows</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Create Workflow
          </Button>
        </div>
      </div>

      {/* Workflow Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {workflowStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <Icon className={`w-4 h-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground">
                  <span className={stat.change.startsWith('+') ? 'text-green-600' : 'text-red-600'}>
                    {stat.change}
                  </span> from yesterday
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Workflow Modules */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="workflows">Workflows</TabsTrigger>
          <TabsTrigger value="executions">Executions</TabsTrigger>
          <TabsTrigger value="automation">Automation Rules</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
        </TabsList>

        {/* Workflows Tab */}
        <TabsContent value="workflows" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Active Workflows</CardTitle>
              <CardDescription>Manage and monitor your automated workflows</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {workflows.map((workflow) => (
                  <div key={workflow.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Workflow className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <h4 className="font-medium">{workflow.name}</h4>
                          <Badge className={workflow.category}>{workflow.category}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{workflow.description}</p>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span>Trigger: {workflow.trigger}</span>
                          <span>{workflow.steps} steps</span>
                          <span>{workflow.executions} executions</span>
                          <span>Success: {workflow.successRate}%</span>
                        </div>
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                          <span>Last run: {workflow.lastRun}</span>
                          <span>Avg time: {workflow.avgTime}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Badge variant={
                        workflow.status === 'active' ? 'default' :
                        workflow.status === 'paused' ? 'secondary' :
                        workflow.status === 'scheduled' ? 'outline' : 'destructive'
                      }>
                        {workflow.status === 'active' && <CheckCircle className="w-3 h-3 mr-1" />}
                        {workflow.status === 'paused' && <Pause className="w-3 h-3 mr-1" />}
                        {workflow.status === 'scheduled' && <Clock className="w-3 h-3 mr-1" />}
                        {workflow.status}
                      </Badge>
                      <div className="flex space-x-1">
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          {workflow.status === 'active' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                        </Button>
                        <Button variant="outline" size="sm">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Workflow Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { category: 'Customer Management', count: 12, active: 8 },
                    { category: 'E-commerce', count: 15, active: 12 },
                    { category: 'Customer Support', count: 8, active: 6 },
                    { category: 'Inventory', count: 6, active: 4 },
                    { category: 'Analytics', count: 4, active: 3 },
                    { category: 'Finance', count: 2, active: 2 },
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm">{item.category}</span>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline">{item.active}/{item.count}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Overall Success Rate</span>
                    <Badge variant="default">96.8%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Average Execution Time</span>
                    <span className="font-medium">2.4s</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Daily Executions</span>
                    <span className="font-medium">1,234</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Failed Executions</span>
                    <Badge variant="destructive">42</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Resource Usage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">CPU Usage</span>
                    <span className="font-medium">34%</span>
                  </div>
                  <Progress value={34} className="h-2" />
                  <div className="flex justify-between">
                    <span className="text-sm">Memory Usage</span>
                    <span className="font-medium">56%</span>
                  </div>
                  <Progress value={56} className="h-2" />
                  <div className="flex justify-between">
                    <span className="text-sm">Queue Length</span>
                    <Badge variant="outline">12 pending</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Executions Tab */}
        <TabsContent value="executions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Executions</CardTitle>
              <CardDescription>Monitor workflow execution status and performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {executions.map((execution) => (
                  <div key={execution.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <GitBranch className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium">{execution.workflow}</h4>
                        <p className="text-sm text-muted-foreground">{execution.trigger}</p>
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                          <span>Started: {execution.startTime}</span>
                          {execution.endTime && <span>Ended: {execution.endTime}</span>}
                          <span>Duration: {execution.duration}</span>
                        </div>
                        {execution.error && (
                          <div className="flex items-center space-x-1 text-xs text-red-600 mt-1">
                            <AlertTriangle className="w-3 h-3" />
                            <span>{execution.error}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm">Steps: {execution.completedSteps}/{execution.steps}</span>
                          {execution.status === 'running' && (
                            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
                          )}
                        </div>
                        <Progress 
                          value={(execution.completedSteps / execution.steps) * 100} 
                          className="h-2 w-20 mt-1" 
                        />
                      </div>
                      <Badge variant={
                        execution.status === 'completed' ? 'default' :
                        execution.status === 'running' ? 'secondary' :
                        execution.status === 'failed' ? 'destructive' : 'outline'
                      }>
                        {execution.status === 'completed' && <CheckCircle className="w-3 h-3 mr-1" />}
                        {execution.status === 'running' && <Clock className="w-3 h-3 mr-1" />}
                        {execution.status === 'failed' && <AlertTriangle className="w-3 h-3 mr-1" />}
                        {execution.status}
                      </Badge>
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Automation Rules Tab */}
        <TabsContent value="automation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Automation Rules</CardTitle>
              <CardDescription>Define conditions and actions for automated processes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {automationRules.map((rule) => (
                  <div key={rule.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Zap className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium">{rule.name}</h4>
                        <div className="flex items-center space-x-2 text-sm text-muted-foreground mt-1">
                          <span>IF</span>
                          <Badge variant="outline">{rule.condition}</Badge>
                          <ArrowRight className="w-3 h-3" />
                          <span>THEN</span>
                          <Badge variant="outline">{rule.action}</Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          Triggered {rule.triggered} times this week
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Badge variant={rule.status === 'active' ? 'default' : 'secondary'}>
                        {rule.status}
                      </Badge>
                      <div className="flex space-x-1">
                        <Button variant="outline" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          {rule.status === 'active' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Templates Tab */}
        <TabsContent value="templates" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Workflow Templates</CardTitle>
              <CardDescription>Pre-built workflow templates for common business processes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {templates.map((template, index) => (
                  <Card key={index}>
                    <CardContent className="pt-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium">{template.name}</h4>
                        <Badge variant="outline">{template.steps} steps</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-4">{template.description}</p>
                      <div className="flex items-center justify-between">
                        <Badge className={template.category}>{template.category}</Badge>
                        <Button size="sm">
                          <Plus className="w-3 h-3 mr-1" />
                          Use Template
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}