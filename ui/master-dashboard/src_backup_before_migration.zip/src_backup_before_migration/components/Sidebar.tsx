import { 
  LayoutDashboard, 
  Users, 
  FileText, 
  ShoppingCart, 
  MessageSquare, 
  Store, 
  Package,
  BarChart3, 
  Building2, 
  Settings,
  ChevronLeft,
  ChevronRight,
  Globe,
  Zap,
  Brain,
  Workflow,
  Shield,
  Activity,
  Database,
  X,
  Menu,
  Calendar
} from 'lucide-react';
import { motion } from 'motion/react';
import { InteractiveElement } from './PageTransition';
import { Button } from './ui/button';
import { cn } from './ui/utils';
import { Badge } from './ui/badge';
import { ThemeToggle } from './ThemeToggle';
import { I3MLogo } from './I3MLogo';
import { useEffect } from 'react';

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: any) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  isMobile: boolean;
  mobileOpen: boolean;
  onMobileToggle: () => void;
}

export function Sidebar({ 
  activeSection, 
  onSectionChange, 
  collapsed, 
  onToggleCollapse, 
  isMobile, 
  mobileOpen, 
  onMobileToggle 
}: SidebarProps) {
  
  // Close mobile sidebar when section changes
  const handleSectionChange = (section: string) => {
    onSectionChange(section);
    if (isMobile && mobileOpen) {
      onMobileToggle();
    }
  };

  // Close mobile sidebar on escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isMobile && mobileOpen) {
        onMobileToggle();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isMobile, mobileOpen, onMobileToggle]);

  const menuItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard, badge: null },
    { id: 'erp', label: 'ERP System', icon: Building2, badge: 'New' },
    { id: 'cms', label: 'CMS Management', icon: FileText, badge: null },
    { id: 'ecommerce', label: 'E-commerce', icon: ShoppingCart, badge: '24' },
    { id: 'support', label: 'Customer Support', icon: MessageSquare, badge: '5' },
    { id: 'templates', label: 'Template Marketplace', icon: Store, badge: null },
    { id: 'services', label: 'Service Marketplace', icon: Package, badge: 'New' },
    { id: 'analytics', label: 'Analytics', icon: BarChart3, badge: null },
    { id: 'customers', label: 'Customers', icon: Users, badge: null },
    { id: 'scrum', label: 'Scrum & Agile', icon: Calendar, badge: 'Sprint' },
    { id: 'aiml', label: 'AI/ML Dashboard', icon: Brain, badge: 'AI' },
    { id: 'workflow', label: 'Workflow', icon: Workflow, badge: 'Auto' },
    { id: 'security', label: 'Security Center', icon: Shield, badge: '3' },
    { id: 'performance', label: 'Performance', icon: Activity, badge: null },
    { id: 'backup', label: 'Backup & Recovery', icon: Database, badge: null },
    { id: 'api', label: 'API Management', icon: Globe, badge: '2.4M' },
    { id: 'settings', label: 'Settings', icon: Settings, badge: null },
  ];

  // Mobile overlay
  if (isMobile) {
    return (
      <>
        {/* Mobile Backdrop */}
        {mobileOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
            onClick={onMobileToggle}
          />
        )}
        
        {/* Mobile Sidebar */}
        <motion.div 
          initial={{ x: -320 }}
          animate={{ x: mobileOpen ? 0 : -320 }}
          transition={{ 
            duration: 0.3,
            ease: [0.23, 1, 0.32, 1]
          }}
          className="fixed inset-y-0 left-0 z-50 w-80 bg-sidebar/95 backdrop-blur-xl border-r border-sidebar-border/30 flex flex-col lg:hidden"
        >
          {/* Mobile Header */}
          <div className="flex items-center justify-between p-6 border-b border-sidebar-border/20 flex-shrink-0">
            <div className="flex items-center space-x-3">
              <motion.div 
                className="flex items-center justify-center"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <I3MLogo size="md" animated={false} theme="auto" />
              </motion.div>
              <div>
                <h1 className="text-xl font-semibold text-sidebar-foreground tracking-tight">I3M Platform</h1>
                <p className="text-sm text-sidebar-foreground/50 font-medium">Admin Dashboard</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <ThemeToggle />
              <Button
                variant="ghost"
                size="sm"
                onClick={onMobileToggle}
                className="text-sidebar-foreground/50 hover:text-sidebar-foreground hover:bg-sidebar-accent/50 rounded-xl p-2 transition-all duration-200"
              >
                <X className="w-5 h-5 flex-shrink-0" />
              </Button>
            </div>
          </div>

          {/* Mobile Navigation */}
          <nav className="p-4 flex-1 overflow-y-auto">
            <motion.div
              initial="hidden"
              animate="show"
              variants={{
                hidden: {},
                show: {
                  transition: {
                    staggerChildren: 0.02
                  }
                }
              }}
            >
              {menuItems.map((item, index) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;
                return (
                  <motion.div
                    key={item.id}
                    variants={{
                      hidden: { opacity: 0, x: -24, scale: 0.96 },
                      show: { 
                        opacity: 1, 
                        x: 0,
                        scale: 1,
                        transition: {
                          type: "spring",
                          damping: 20,
                          stiffness: 180,
                          mass: 0.6,
                          duration: 0.4
                        }
                      }
                    }}
                  >
                    <InteractiveElement 
                      onClick={() => handleSectionChange(item.id)}
                      className="block mb-2"
                    >
                      <Button
                        variant="ghost"
                        className={cn(
                          "w-full justify-start h-12 font-medium transition-all duration-300 rounded-xl border-0",
                          isActive 
                            ? "bg-primary/12 text-primary hover:bg-primary/18 shadow-lg backdrop-blur-sm border border-primary/25" 
                            : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground hover:shadow-md"
                        )}
                      >
                        <motion.div 
                          className="flex items-center w-full"
                          animate={isActive ? { x: 2 } : { x: 0 }}
                          transition={{
                            type: "spring",
                            damping: 25,
                            stiffness: 300,
                            mass: 0.5
                          }}
                        >
                          <div className="flex items-center justify-center w-5 h-5 min-w-[1.25rem] min-h-[1.25rem] mr-4">
                            <Icon className={cn("w-5 h-5 flex-shrink-0", isActive && "text-primary")} />
                          </div>
                          <span className="flex-1 text-left font-medium">{item.label}</span>
                          {item.badge && (
                            <motion.div
                              initial={{ scale: 0.8, opacity: 0 }}
                              animate={{ scale: 1, opacity: 1 }}
                              transition={{ delay: 0.1 }}
                            >
                              <Badge 
                                variant={item.badge === 'New' ? "default" : "secondary"} 
                                className={cn(
                                  "ml-2 h-6 px-2 text-xs font-semibold rounded-full shadow-sm",
                                  item.badge === 'New' ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                                )}
                              >
                                {item.badge}
                              </Badge>
                            </motion.div>
                          )}
                        </motion.div>
                      </Button>
                    </InteractiveElement>
                  </motion.div>
                );
              })}
            </motion.div>
          </nav>

          {/* Mobile Footer */}
          <div className="p-6 border-t border-sidebar-border/20 flex-shrink-0 bg-gradient-to-r from-sidebar to-sidebar/50">
            <div className="flex items-center space-x-3 text-sm text-sidebar-foreground/60 font-medium">
              <div className="flex items-center justify-center w-6 h-6 min-w-[1.5rem] min-h-[1.5rem] aspect-square bg-primary/10 rounded-lg">
                <Globe className="w-4 h-4 flex-shrink-0 text-primary" />
              </div>
              <span>Global Platform</span>
            </div>
            <p className="text-sm text-sidebar-foreground/40 mt-2 font-medium">v2024.1.0</p>
          </div>
        </motion.div>
      </>
    );
  }

  // Desktop Sidebar
  return (
    <motion.div 
      className={cn(
        "h-full bg-sidebar/80 backdrop-blur-xl border-r border-sidebar-border/30 transition-all duration-500 ease-out flex flex-col hidden lg:flex flex-shrink-0",
        collapsed ? "w-16" : "w-72"
      )}
      animate={{ width: collapsed ? 64 : 288 }}
      transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
    >
      {/* Desktop Header */}
      <div className="flex items-center justify-between p-6 border-b border-sidebar-border/20 flex-shrink-0">
        {!collapsed && (
          <motion.div 
            className="flex items-center space-x-3"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            <motion.div 
              className="flex items-center justify-center"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <I3MLogo size="md" animated={false} theme="auto" />
            </motion.div>
            <div>
              <h1 className="text-xl font-semibold text-sidebar-foreground tracking-tight">I3M Platform</h1>
              <p className="text-sm text-sidebar-foreground/50 font-medium">Admin Dashboard</p>
            </div>
          </motion.div>
        )}
        {collapsed && (
          <motion.div 
            className="flex items-center justify-center w-full"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            <I3MLogo size="sm" animated={false} theme="auto" />
          </motion.div>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggleCollapse}
          className="text-sidebar-foreground/50 hover:text-sidebar-foreground hover:bg-sidebar-accent/50 rounded-xl p-2 transition-all duration-200"
        >
          {collapsed ? (
            <ChevronRight className="w-5 h-5 flex-shrink-0" />
          ) : (
            <ChevronLeft className="w-5 h-5 flex-shrink-0" />
          )}
        </Button>
      </div>

      {/* Desktop Navigation */}
      <nav className="p-4 flex-1 overflow-y-auto">
        <motion.div
          initial="hidden"
          animate="show"
          variants={{
            hidden: {},
            show: {
              transition: {
                staggerChildren: 0.02
              }
            }
          }}
        >
          {menuItems.map((item, index) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            return (
              <motion.div
                key={item.id}
                variants={{
                  hidden: { opacity: 0, x: -24, scale: 0.96 },
                  show: { 
                    opacity: 1, 
                    x: 0,
                    scale: 1,
                    transition: {
                      type: "spring",
                      damping: 20,
                      stiffness: 180,
                      mass: 0.6,
                      duration: 0.4
                    }
                  }
                }}
              >
                <InteractiveElement 
                  onClick={() => handleSectionChange(item.id)}
                  className="block mb-2"
                >
                  <Button
                    variant="ghost"
                    className={cn(
                      "w-full h-12 font-medium transition-all duration-300 rounded-xl border-0",
                      collapsed ? "justify-center px-0" : "justify-start",
                      isActive 
                        ? "bg-primary/12 text-primary hover:bg-primary/18 shadow-lg backdrop-blur-sm border border-primary/25" 
                        : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground hover:shadow-md"
                    )}
                  >
                    <motion.div 
                      className={cn("flex items-center", collapsed ? "justify-center" : "w-full")}
                      animate={isActive && !collapsed ? { x: 2 } : { x: 0 }}
                      transition={{
                        type: "spring",
                        damping: 25,
                        stiffness: 300,
                        mass: 0.5
                      }}
                    >
                      <div className={cn(
                        "flex items-center justify-center w-5 h-5 min-w-[1.25rem] min-h-[1.25rem] aspect-square",
                        !collapsed && "mr-4"
                      )}>
                        <Icon className={cn("w-5 h-5 flex-shrink-0", isActive && "text-primary")} />
                      </div>
                      {!collapsed && (
                        <>
                          <span className="flex-1 text-left font-medium">{item.label}</span>
                          {item.badge && (
                            <motion.div
                              initial={{ scale: 0.8, opacity: 0 }}
                              animate={{ scale: 1, opacity: 1 }}
                              transition={{ delay: 0.1 }}
                            >
                              <Badge 
                                variant={item.badge === 'New' ? "default" : "secondary"} 
                                className={cn(
                                  "ml-2 h-6 px-2 text-xs font-semibold rounded-full shadow-sm",
                                  item.badge === 'New' ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                                )}
                              >
                                {item.badge}
                              </Badge>
                            </motion.div>
                          )}
                        </>
                      )}
                    </motion.div>
                  </Button>
                </InteractiveElement>
              </motion.div>
            );
          })}
        </motion.div>
      </nav>

      {/* Desktop Footer */}
      {!collapsed && (
        <motion.div 
          className="p-6 border-t border-sidebar-border/20 flex-shrink-0 bg-gradient-to-r from-sidebar to-sidebar/50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
        >
          <div className="flex items-center space-x-3 text-sm text-sidebar-foreground/60 font-medium">
            <div className="flex items-center justify-center w-6 h-6 min-w-[1.5rem] min-h-[1.5rem] aspect-square bg-primary/10 rounded-lg">
              <Globe className="w-4 h-4 flex-shrink-0 text-primary" />
            </div>
            <span>Global Platform</span>
          </div>
          <p className="text-sm text-sidebar-foreground/40 mt-2 font-medium">v2024.1.0</p>
        </motion.div>
      )}
    </motion.div>
  );
}