import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Building2, 
  Users, 
  Globe, 
  CreditCard,
  Calendar,
  Mail,
  Phone,
  Plus,
  Search,
  Filter,
  Edit,
  Eye,
  MoreHorizontal,
  CheckCircle,
  AlertTriangle,
  Clock,
  Star,
  DollarSign
} from 'lucide-react';

export function CustomerManagement() {
  const [activeTab, setActiveTab] = useState('customers');

  const customerStats = [
    { title: 'Total Customers', value: '2,847', change: '+124', icon: Building2, color: 'text-blue-500' },
    { title: 'Enterprise Clients', value: '147', change: '+12', icon: Users, color: 'text-green-500' },
    { title: 'Active Subscriptions', value: '2,631', change: '+98', icon: CreditCard, color: 'text-purple-500' },
    { title: 'Trial Customers', value: '216', change: '+23', icon: Clock, color: 'text-orange-500' },
  ];

  const customers = [
    {
      id: 1,
      name: 'TechCorp Inc.',
      industry: 'Technology',
      size: 'Enterprise',
      employees: 5000,
      plan: 'Enterprise Pro',
      mrr: '$4,999',
      status: 'active',
      health: 'excellent',
      lastLogin: '2024-01-15',
      joinDate: '2023-06-15',
      contact: 'john.doe@techcorp.com',
      phone: '+1 (555) 123-4567',
      usage: 98
    },
    {
      id: 2,
      name: 'StartupCo',
      industry: 'Fintech',
      size: 'Medium',
      employees: 150,
      plan: 'Professional',
      mrr: '$999',
      status: 'active',
      health: 'good',
      lastLogin: '2024-01-14',
      joinDate: '2023-08-20',
      contact: 'sarah@startupco.com',
      phone: '+1 (555) 987-6543',
      usage: 76
    },
    {
      id: 3,
      name: 'Global Solutions Ltd.',
      industry: 'Consulting',
      size: 'Large',
      employees: 1200,
      plan: 'Enterprise',
      mrr: '$2,999',
      status: 'active',
      health: 'good',
      lastLogin: '2024-01-13',
      joinDate: '2023-03-10',
      contact: 'mike@globalsolutions.com',
      phone: '+44 20 7123 4567',
      usage: 89
    },
    {
      id: 4,
      name: 'Design Studio Pro',
      industry: 'Design',
      size: 'Small',
      employees: 25,
      plan: 'Professional',
      mrr: '$499',
      status: 'trial',
      health: 'at-risk',
      lastLogin: '2024-01-10',
      joinDate: '2024-01-01',
      contact: 'team@designstudio.com',
      phone: '+1 (555) 456-7890',
      usage: 34
    },
  ];

  const tenantData = [
    {
      id: 'tnt_001',
      customer: 'TechCorp Inc.',
      domain: 'techcorp.i3m.com',
      database: 'techcorp_prod',
      storage: '2.4 GB',
      users: 247,
      status: 'active',
      lastBackup: '2024-01-15 02:00',
      ssl: 'valid',
      region: 'us-east-1'
    },
    {
      id: 'tnt_002',
      customer: 'StartupCo',
      domain: 'startup.i3m.com',
      database: 'startupco_prod',
      storage: '890 MB',
      users: 89,
      status: 'active',
      lastBackup: '2024-01-15 02:15',
      ssl: 'valid',
      region: 'us-west-2'
    },
    {
      id: 'tnt_003',
      customer: 'Global Solutions Ltd.',
      domain: 'global.i3m.com',
      database: 'global_prod',
      storage: '1.8 GB',
      users: 156,
      status: 'active',
      lastBackup: '2024-01-15 02:30',
      ssl: 'valid',
      region: 'eu-west-1'
    },
    {
      id: 'tnt_004',
      customer: 'Design Studio Pro',
      domain: 'design.i3m.com',
      database: 'design_trial',
      storage: '234 MB',
      users: 12,
      status: 'trial',
      lastBackup: '2024-01-15 02:45',
      ssl: 'valid',
      region: 'us-east-1'
    },
  ];

  const subscriptions = [
    {
      id: 'sub_001',
      customer: 'TechCorp Inc.',
      plan: 'Enterprise Pro',
      billing: 'annual',
      amount: '$59,988',
      nextBilling: '2024-06-15',
      status: 'active',
      paymentMethod: '**** 4567',
      seats: 500,
      usage: 247
    },
    {
      id: 'sub_002',
      customer: 'StartupCo',
      plan: 'Professional',
      billing: 'monthly',
      amount: '$999',
      nextBilling: '2024-02-20',
      status: 'active',
      paymentMethod: '**** 9876',
      seats: 150,
      usage: 89
    },
    {
      id: 'sub_003',
      customer: 'Global Solutions Ltd.',
      plan: 'Enterprise',
      billing: 'annual',
      amount: '$35,988',
      nextBilling: '2024-03-10',
      status: 'active',
      paymentMethod: '**** 2345',
      seats: 300,
      usage: 156
    },
    {
      id: 'sub_004',
      customer: 'Design Studio Pro',
      plan: 'Professional Trial',
      billing: 'trial',
      amount: '$0',
      nextBilling: '2024-01-31',
      status: 'trial',
      paymentMethod: 'none',
      seats: 50,
      usage: 12
    },
  ];

  const supportTickets = [
    { customer: 'TechCorp Inc.', tickets: 23, avgResponse: '2.1h', satisfaction: 4.8 },
    { customer: 'StartupCo', tickets: 12, avgResponse: '1.8h', satisfaction: 4.9 },
    { customer: 'Global Solutions Ltd.', tickets: 18, avgResponse: '2.4h', satisfaction: 4.7 },
    { customer: 'Design Studio Pro', tickets: 8, avgResponse: '1.5h', satisfaction: 4.6 },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Customer Management</h1>
          <p className="text-muted-foreground">Manage customers, tenants, and subscriptions</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Plus className="w-4 h-4 mr-2" />
            Add Customer
          </Button>
          <Button>
            <Building2 className="w-4 h-4 mr-2" />
            Customer Analytics
          </Button>
        </div>
      </div>

      {/* Customer Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {customerStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <Icon className={`w-4 h-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">+{stat.change}</span> this month
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Customer Management Modules */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="customers">Customers</TabsTrigger>
          <TabsTrigger value="tenants">Tenants</TabsTrigger>
          <TabsTrigger value="subscriptions">Subscriptions</TabsTrigger>
          <TabsTrigger value="support">Support</TabsTrigger>
        </TabsList>

        {/* Customers Tab */}
        <TabsContent value="customers" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Customer Directory</CardTitle>
                  <CardDescription>Manage customer accounts and relationships</CardDescription>
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    <Search className="w-4 h-4 mr-2" />
                    Search
                  </Button>
                  <Button variant="outline" size="sm">
                    <Filter className="w-4 h-4 mr-2" />
                    Filter
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {customers.map((customer) => (
                  <div key={customer.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Building2 className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <h4 className="font-medium">{customer.name}</h4>
                          <Badge variant={
                            customer.health === 'excellent' ? 'default' :
                            customer.health === 'good' ? 'secondary' : 'destructive'
                          }>
                            {customer.health}
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span>{customer.industry}</span>
                          <span>{customer.employees} employees</span>
                          <span>MRR: {customer.mrr}</span>
                          <span>Usage: {customer.usage}%</span>
                        </div>
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                          <span className="flex items-center">
                            <Mail className="w-3 h-3 mr-1" />
                            {customer.contact}
                          </span>
                          <span className="flex items-center">
                            <Phone className="w-3 h-3 mr-1" />
                            {customer.phone}
                          </span>
                          <span className="flex items-center">
                            <Calendar className="w-3 h-3 mr-1" />
                            Joined: {customer.joinDate}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <Badge className={customer.plan}>{customer.plan}</Badge>
                        <p className="text-xs text-muted-foreground mt-1">
                          Last login: {customer.lastLogin}
                        </p>
                      </div>
                      <Badge variant={
                        customer.status === 'active' ? 'default' :
                        customer.status === 'trial' ? 'secondary' : 'outline'
                      }>
                        {customer.status === 'active' && <CheckCircle className="w-3 h-3 mr-1" />}
                        {customer.status === 'trial' && <Clock className="w-3 h-3 mr-1" />}
                        {customer.status}
                      </Badge>
                      <div className="flex space-x-1">
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Customer Insights */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Customer Health</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { status: 'Excellent', count: 1247, color: 'bg-green-500' },
                    { status: 'Good', count: 1235, color: 'bg-blue-500' },
                    { status: 'At Risk', count: 234, color: 'bg-yellow-500' },
                    { status: 'Critical', count: 131, color: 'bg-red-500' },
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className={`w-3 h-3 rounded-full ${item.color}`} />
                        <span className="text-sm">{item.status}</span>
                      </div>
                      <Badge variant="outline">{item.count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Revenue by Segment</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { segment: 'Enterprise', revenue: '$845K', percentage: 68 },
                    { segment: 'Medium', revenue: '$234K', percentage: 19 },
                    { segment: 'Small', revenue: '$123K', percentage: 10 },
                    { segment: 'Trial', revenue: '$0', percentage: 3 },
                  ].map((item, index) => (
                    <div key={index} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>{item.segment}</span>
                        <span className="font-medium">{item.revenue}</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full" 
                          style={{ width: `${item.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Customer Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Average LTV</span>
                    <span className="font-medium">$4,250</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Churn Rate</span>
                    <Badge variant="outline">2.1%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">NPS Score</span>
                    <Badge variant="default">72</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Expansion Revenue</span>
                    <Badge variant="outline" className="text-green-600">+18%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Tenants Tab */}
        <TabsContent value="tenants" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Tenant Management</CardTitle>
              <CardDescription>Single-tenant architecture with isolated databases</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {tenantData.map((tenant) => (
                  <div key={tenant.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Globe className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium">{tenant.customer}</h4>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span>{tenant.domain}</span>
                          <span>DB: {tenant.database}</span>
                          <span>Storage: {tenant.storage}</span>
                          <span>{tenant.users} users</span>
                        </div>
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                          <span>Region: {tenant.region}</span>
                          <span>Backup: {tenant.lastBackup}</span>
                          <Badge variant="outline" className="text-green-600">{tenant.ssl} SSL</Badge>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Badge variant={tenant.status === 'active' ? 'default' : 'secondary'}>
                        {tenant.status}
                      </Badge>
                      <Button variant="outline" size="sm">
                        Manage
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Infrastructure Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Total Tenants</span>
                    <span className="font-medium">2,847</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Active Databases</span>
                    <Badge variant="default">2,631</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Total Storage</span>
                    <span className="font-medium">2.4 TB</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Backup Success</span>
                    <Badge variant="default">99.8%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Regional Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { region: 'US East', count: 1234 },
                    { region: 'US West', count: 567 },
                    { region: 'EU West', count: 789 },
                    { region: 'Asia Pacific', count: 257 },
                  ].map((region, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm">{region.region}</span>
                      <Badge variant="outline">{region.count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Security & Compliance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">SSL Certificates</span>
                    <Badge variant="default">100% Valid</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Data Encryption</span>
                    <Badge variant="default">AES-256</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Backup Encryption</span>
                    <Badge variant="default">Enabled</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Compliance</span>
                    <Badge variant="default">GDPR Ready</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Subscriptions Tab */}
        <TabsContent value="subscriptions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Subscription Management</CardTitle>
              <CardDescription>Monitor billing, usage, and subscription health</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {subscriptions.map((subscription) => (
                  <div key={subscription.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <CreditCard className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <h4 className="font-medium">{subscription.customer}</h4>
                          <Badge className={subscription.plan}>{subscription.plan}</Badge>
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span>Billing: {subscription.billing}</span>
                          <span>Payment: {subscription.paymentMethod}</span>
                          <span>Next: {subscription.nextBilling}</span>
                        </div>
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                          <span>Seats: {subscription.usage}/{subscription.seats}</span>
                          <span>Usage: {Math.round((subscription.usage / subscription.seats) * 100)}%</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className="font-medium">{subscription.amount}</p>
                        <p className="text-xs text-muted-foreground">
                          {subscription.billing === 'annual' ? '/year' : subscription.billing === 'monthly' ? '/month' : 'trial'}
                        </p>
                      </div>
                      <Badge variant={subscription.status === 'active' ? 'default' : 'secondary'}>
                        {subscription.status}
                      </Badge>
                      <Button variant="outline" size="sm">
                        Manage
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Revenue Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Monthly Recurring Revenue</span>
                    <span className="font-medium">$234,567</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Annual Recurring Revenue</span>
                    <span className="font-medium">$2,814,804</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">MRR Growth Rate</span>
                    <Badge variant="outline" className="text-green-600">+18%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Churn Rate</span>
                    <Badge variant="outline">2.1%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Billing Health</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Payment Success Rate</span>
                    <Badge variant="default">98.7%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Failed Payments</span>
                    <Badge variant="outline">34</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Dunning Recovery</span>
                    <Badge variant="default">76%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Overdue Accounts</span>
                    <Badge variant="secondary">12</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Support Tab */}
        <TabsContent value="support" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Customer Support Overview</CardTitle>
              <CardDescription>Support metrics and satisfaction by customer</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {supportTickets.map((customer, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Building2 className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium">{customer.customer}</h4>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span>{customer.tickets} tickets</span>
                          <span>Avg response: {customer.avgResponse}</span>
                          <div className="flex items-center">
                            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400 mr-1" />
                            <span>{customer.satisfaction}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Badge variant={
                        customer.satisfaction >= 4.5 ? 'default' :
                        customer.satisfaction >= 4.0 ? 'secondary' : 'outline'
                      }>
                        {customer.satisfaction >= 4.5 ? 'Excellent' :
                         customer.satisfaction >= 4.0 ? 'Good' : 'Needs Attention'}
                      </Badge>
                      <Button variant="outline" size="sm">
                        View Tickets
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Support Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Avg Response Time</span>
                    <span className="font-medium">2.1 hours</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">First Response SLA</span>
                    <Badge variant="default">94%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Resolution Time</span>
                    <span className="font-medium">18.5 hours</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Customer Satisfaction</span>
                    <div className="flex items-center">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 mr-1" />
                      <span className="font-medium">4.7</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Ticket Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { type: 'Technical', count: 89 },
                    { type: 'Billing', count: 34 },
                    { type: 'Feature Request', count: 23 },
                    { type: 'General', count: 19 },
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm">{item.type}</span>
                      <Badge variant="outline">{item.count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Escalations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Open Escalations</span>
                    <Badge variant="secondary">8</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Critical Issues</span>
                    <Badge variant="destructive">2</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Escalation Rate</span>
                    <Badge variant="outline">3.2%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Avg Resolution</span>
                    <span className="font-medium">4.2 days</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}