import { ThemeProvider } from './components/ThemeProvider';
import { DesignSystemProvider } from './components/DesignSystemProvider';
import { LanguageProvider } from './components/LanguageProvider';
import { AppRouter } from './app/router';
import { ErrorBoundary } from './app/ErrorBoundary';

export default function App() {
  return (
    <ErrorBoundary>
      <LanguageProvider defaultLanguage="en">
        <DesignSystemProvider defaultSystem="apple" defaultMode="system">
          <ThemeProvider defaultTheme="system" storageKey="i3m-theme">
            <div className="h-screen w-full bg-background overflow-hidden">
              <AppRouter />
            </div>
          </ThemeProvider>
        </DesignSystemProvider>
      </LanguageProvider>
    </ErrorBoundary>
  );
}