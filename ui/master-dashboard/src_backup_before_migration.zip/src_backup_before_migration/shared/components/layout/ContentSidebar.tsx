import { motion } from 'motion/react';
import { Button } from '../ui';
import { Settings, PanelRight, X } from 'lucide-react';
import { cn } from '../ui';

interface ContentSidebarProps {
  isOpen: boolean;
  onToggle: () => void;
  isMobile: boolean;
}

export function ContentSidebar({ isOpen, onToggle, isMobile }: ContentSidebarProps) {
  if (isMobile) {
    return null; // Hide on mobile
  }

  return (
    <>
      {/* Content Sidebar */}
      {isOpen && (
        <motion.div 
          initial={{ width: 0, opacity: 0 }}
          animate={{ width: 288, opacity: 1 }}
          exit={{ width: 0, opacity: 0 }}
          transition={{ duration: 0.3, ease: "easeInOut" }}
          className="bg-background/95 backdrop-blur-xl border-l border-border/30 flex-shrink-0 overflow-hidden flex flex-col"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-border/30 flex-shrink-0">
            <div className="flex items-center space-x-3">
              <Settings className="w-5 h-5 text-primary" />
              <h3 className="text-lg font-semibold text-foreground">Settings</h3>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onToggle}
              className="rounded-xl p-1 w-8 h-8 hover:bg-muted/50"
              title="Close Settings Panel"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Content */}
          <div 
            className="flex-1 overflow-y-auto p-4 [&::-webkit-scrollbar]:hidden"
            style={{
              scrollbarWidth: 'none', /* Firefox */
              msOverflowStyle: 'none', /* IE and Edge */
            }}
          >
            <div className="space-y-4">
              {/* Quick Actions Section */}
              <div className="space-y-3">
                <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Quick Actions</h4>
                
                <div className="space-y-2">
                  <Button variant="outline" size="sm" className="w-full justify-start">
                    <PanelRight className="w-4 h-4 mr-2" />
                    New Document
                  </Button>
                  <Button variant="outline" size="sm" className="w-full justify-start">
                    <Settings className="w-4 h-4 mr-2" />
                    Settings
                  </Button>
                  <Button variant="outline" size="sm" className="w-full justify-start">
                    <PanelRight className="w-4 h-4 mr-2" />
                    Export Data
                  </Button>
                </div>
              </div>

              {/* Recent Activity Section */}
              <div className="space-y-3">
                <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Recent Activity</h4>
                
                <div className="space-y-2">
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <div className="text-sm font-medium">Document Updated</div>
                    <div className="text-xs text-muted-foreground">2 minutes ago</div>
                  </div>
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <div className="text-sm font-medium">Settings Changed</div>
                    <div className="text-xs text-muted-foreground">5 minutes ago</div>
                  </div>
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <div className="text-sm font-medium">Export Completed</div>
                    <div className="text-xs text-muted-foreground">10 minutes ago</div>
                  </div>
                </div>
              </div>

              {/* Quick Stats Section */}
              <div className="space-y-3">
                <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Quick Stats</h4>
                
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-3 bg-primary/10 rounded-lg text-center">
                    <div className="text-lg font-bold text-primary">24</div>
                    <div className="text-xs text-muted-foreground">Documents</div>
                  </div>
                  <div className="p-3 bg-green-500/10 rounded-lg text-center">
                    <div className="text-lg font-bold text-green-600">12</div>
                    <div className="text-xs text-muted-foreground">Active</div>
                  </div>
                </div>
              </div>

              {/* Settings Preview Section */}
              <div className="space-y-3">
                <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Preferences</h4>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Auto-save</span>
                    <div className="w-8 h-4 bg-primary rounded-full relative">
                      <div className="w-3 h-3 bg-white rounded-full absolute right-0.5 top-0.5"></div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Notifications</span>
                    <div className="w-8 h-4 bg-muted rounded-full relative">
                      <div className="w-3 h-3 bg-white rounded-full absolute left-0.5 top-0.5"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-border/30 flex-shrink-0 bg-gradient-to-r from-background to-background/50">
            <div className="flex items-center space-x-3 text-sm text-muted-foreground font-medium">
              <div className="flex items-center justify-center w-6 h-6 min-w-[1.5rem] min-h-[1.5rem] aspect-square bg-primary/10 rounded-lg">
                <Settings className="w-4 h-4 flex-shrink-0 text-primary" />
              </div>
              <span>Settings Panel</span>
            </div>
            <p className="text-sm text-muted-foreground/60 mt-2 font-medium">v2024.1.0</p>
          </div>
        </motion.div>
      )}
    </>
  );
}
