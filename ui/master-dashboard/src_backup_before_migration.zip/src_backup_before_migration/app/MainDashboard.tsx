import { useState } from 'react';
import { Menu, Settings } from 'lucide-react';
import { motion } from 'motion/react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Button } from '@/shared/components/ui';
import { ThemeToggle } from '@/components/ThemeToggle';
import { DesignSystemToggle } from '@/components/DesignSystemToggle';
import { LanguageSelector } from '@/components/LanguageSelector';
import { EmailPopover, MessagePopover, NotificationPopover, UserMenuPopover } from '@/components/HeaderPopovers';
import { useMobile } from '@/shared/hooks';
import { Sidebar, ContentSidebar } from '@/shared/components/layout';
import { I3MLogo } from '@/shared/components/common';
import { routes, getRouteTitle, getRouteDescription, RouteId } from './router';
import { 
  Overview,
  ERPManagement,
  CMSManagement,
  EcommerceManagement,
  Analytics,
  SupportManagement,
  TemplateMarketplace,
  ServiceMarketplace,
  CustomerManagement,
  ScrumManagement,
  AIMLDashboard,
  WorkflowManagement,
  SecurityCenter,
  PerformanceMonitoring,
  BackupManagement,
  APIManagement,
  SettingsPanel
} from '@/pages';

export function MainDashboard() {
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [rightSidebarOpen, setRightSidebarOpen] = useState(true);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const isMobile = useMobile();

  // Get active section from URL with safety check
  const activeSection = routes?.find(route => route.path === location?.pathname)?.id || 'overview';

  const handleSectionChange = (section: RouteId) => {
    if (section === activeSection) return;
    
    setIsTransitioning(true);
    
    // Find the route and navigate to it
    const route = routes?.find(r => r.id === section);
    if (route) {
      navigate(route.path);
    }
    
    // Optimized timing for smooth iPhone-like transitions
    setTimeout(() => {
      // Allow the new content to start rendering before removing overlay
      setTimeout(() => {
        setIsTransitioning(false);
      }, 150);
    }, 80);
  };

  const renderContent = () => {
    switch (activeSection) {
      case 'overview':
        return <Overview />;
      case 'erp':
        return <ERPManagement />;
      case 'cms':
        return <CMSManagement />;
      case 'ecommerce':
        return <EcommerceManagement />;
      case 'analytics':
        return <Analytics />;
      case 'support':
        return <SupportManagement />;
      case 'templates':
        return <TemplateMarketplace />;
      case 'services':
        return <ServiceMarketplace />;
      case 'customers':
        return <CustomerManagement />;
      case 'scrum':
        return <ScrumManagement />;
      case 'aiml':
        return <AIMLDashboard />;
      case 'workflow':
        return <WorkflowManagement />;
      case 'security':
        return <SecurityCenter />;
      case 'performance':
        return <PerformanceMonitoring />;
      case 'backup':
        return <BackupManagement />;
      case 'api':
        return <APIManagement />;
      case 'settings':
        return <SettingsPanel />;
      default:
        return <Overview />;
    }
  };

  return (
    <div className="flex h-full w-full bg-gradient-to-br from-background via-background to-background/95">
      {/* Mobile Header */}
      {isMobile && (
        <div className="fixed top-0 left-0 right-0 z-30 bg-background/95 backdrop-blur-xl border-b border-border/30 p-4 lg:hidden">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setMobileOpen(true)}
                className="rounded-xl p-2 bg-muted/50 hover:bg-muted w-10 h-10 min-w-[2.5rem] min-h-[2.5rem] aspect-square flex items-center justify-center"
              >
                <Menu className="w-5 h-5 flex-shrink-0" />
              </Button>
              <div className="flex items-center space-x-3">
                <I3MLogo size="sm" animated={false} theme="auto" />
                <div>
                  <h1 className="text-lg font-semibold">{getRouteTitle(activeSection)}</h1>
                  <p className="text-sm text-muted-foreground">{getRouteDescription(activeSection)}</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <DesignSystemToggle />
              <ThemeToggle />
              <LanguageSelector />
              <EmailPopover isMobile={true} />
              <MessagePopover isMobile={true} />
              <NotificationPopover isMobile={true} />
              <UserMenuPopover isMobile={true} />
            </div>
          </div>
        </div>
      )}

      <Sidebar 
        activeSection={activeSection} 
        onSectionChange={handleSectionChange}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        isMobile={isMobile}
        mobileOpen={mobileOpen}
        onMobileToggle={() => setMobileOpen(!mobileOpen)}
      />
      
      <main className="flex-1 h-full overflow-hidden relative flex flex-col">
        {/* Desktop Header */}
        {!isMobile && (
          <div className="w-full bg-background/95 backdrop-blur-xl border-b border-border/30 px-4 lg:px-3 py-4 flex-shrink-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <I3MLogo size="md" animated={false} theme="auto" />
                <div>
                  <h1 className="text-xl font-semibold text-foreground">{getRouteTitle(activeSection)}</h1>
                  <div className="text-sm text-muted-foreground">{getRouteDescription(activeSection)}</div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setRightSidebarOpen(!rightSidebarOpen)}
                  className="rounded-xl p-2 bg-muted/50 hover:bg-muted w-10 h-10 min-w-[2.5rem] min-h-[2.5rem] aspect-square flex items-center justify-center hidden lg:flex"
                >
                  <Settings className="w-5 h-5 flex-shrink-0" />
                </Button>
                <DesignSystemToggle />
                <ThemeToggle />
                <EmailPopover />
                <MessagePopover />
                <NotificationPopover />
                <UserMenuPopover />
              </div>
            </div>
          </div>
        )}
        
        {/* Main Content Layout with Right Sidebar */}
        <div className={`flex-1 flex overflow-hidden bg-gradient-to-br from-background/50 via-background to-muted/20 ${
          isMobile ? 'pt-20' : ''
        }`}>
          {/* Content Area */}
          <div 
            className="flex-1 overflow-y-auto relative [&::-webkit-scrollbar]:hidden"
            style={{
              scrollbarWidth: 'none', /* Firefox */
              msOverflowStyle: 'none', /* IE and Edge */
            }}
          >
            {/* Enhanced loading overlay with iPhone-style blur */}
            {isTransitioning && (
              <motion.div
                initial={{ opacity: 0, scale: 1.02 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{
                  type: "spring",
                  damping: 25,
                  stiffness: 300,
                  mass: 0.6,
                  duration: 0.3
                }}
                className="absolute inset-0 bg-background/80 backdrop-blur-xl z-10 flex items-center justify-center"
                style={{ willChange: "transform, opacity" }}
              >
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="flex items-center space-x-3"
                >
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ 
                      duration: 1.2, 
                      repeat: Infinity, 
                      ease: [0.4, 0, 0.6, 1]
                    }}
                    className="w-7 h-7 border-2 border-primary/20 border-t-primary rounded-full"
                    style={{ willChange: "transform" }}
                  />
                  <motion.span
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1, duration: 0.3 }}
                    className="text-sm text-muted-foreground font-medium"
                  >
                    Loading...
                  </motion.span>
                </motion.div>
              </motion.div>
            )}
            
            {renderContent()}
          </div>
          
          {/* ContentSidebar */}
          <ContentSidebar 
            isOpen={rightSidebarOpen}
            onToggle={() => setRightSidebarOpen(!rightSidebarOpen)}
            isMobile={isMobile}
          />
          
        </div>
        
        {/* Subtle overlay for depth */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background/5 pointer-events-none" />
      </main>
    </div>
  );
}
