import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { DashboardWrapper } from '../DashboardWrapper';
import { routes } from './routes';

// Create router configuration
export const router = createBrowserRouter([
  {
    path: '/',
    element: <DashboardWrapper />,
  },
  ...routes.map(route => ({
    path: route.path,
    element: <DashboardWrapper />,
  }))
]);

// Router Provider Component
export function AppRouter() {
  return <RouterProvider router={router} />;
}
