import { RouteConfig } from './types';

export const routes: RouteConfig[] = [
  {
    id: 'overview',
    title: 'Dashboard Overview',
    description: 'System overview and key metrics',
    icon: 'LayoutDashboard',
    path: '/overview'
  },
  {
    id: 'erp',
    title: 'ERP Management',
    description: 'Manage enterprise resources and operations',
    icon: 'Building2',
    badge: 'New',
    path: '/erp'
  },
  {
    id: 'cms',
    title: 'CMS Management',
    description: 'Content management and publishing',
    icon: 'FileText',
    path: '/cms'
  },
  {
    id: 'ecommerce',
    title: 'E-commerce',
    description: 'Online store and product management',
    icon: 'ShoppingCart',
    badge: '24',
    path: '/ecommerce'
  },
  {
    id: 'support',
    title: 'Support Center',
    description: 'Customer support and ticketing',
    icon: 'MessageSquare',
    badge: '5',
    path: '/support'
  },
  {
    id: 'templates',
    title: 'Template Marketplace',
    description: 'Browse and install templates',
    icon: 'Store',
    path: '/templates'
  },
  {
    id: 'services',
    title: 'Service Marketplace',
    description: 'Discover and integrate services',
    icon: 'Package',
    badge: 'New',
    path: '/services'
  },
  {
    id: 'analytics',
    title: 'Analytics',
    description: 'Data insights and reporting',
    icon: 'BarChart3',
    path: '/analytics'
  },
  {
    id: 'customers',
    title: 'Customer Management',
    description: 'Customer relationship management',
    icon: 'Users',
    path: '/customers'
  },
  {
    id: 'scrum',
    title: 'Scrum & Agile',
    description: 'Agile project management',
    icon: 'Calendar',
    badge: 'Sprint',
    path: '/scrum'
  },
  {
    id: 'aiml',
    title: 'AI/ML Dashboard',
    description: 'Artificial intelligence and machine learning',
    icon: 'Brain',
    badge: 'AI',
    path: '/aiml'
  },
  {
    id: 'workflow',
    title: 'Workflow Management',
    description: 'Process automation and workflows',
    icon: 'Workflow',
    badge: 'Auto',
    path: '/workflow'
  },
  {
    id: 'security',
    title: 'Security Center',
    description: 'Security settings and monitoring',
    icon: 'Shield',
    badge: '3',
    path: '/security'
  },
  {
    id: 'performance',
    title: 'Performance Monitor',
    description: 'System performance analytics',
    icon: 'Activity',
    path: '/performance'
  },
  {
    id: 'backup',
    title: 'Backup Management',
    description: 'Data backup and recovery',
    icon: 'Database',
    path: '/backup'
  },
  {
    id: 'api',
    title: 'API Management',
    description: 'API configuration and monitoring',
    icon: 'Globe',
    badge: '2.4M',
    path: '/api'
  },
  {
    id: 'settings',
    title: 'Settings',
    description: 'System configuration and preferences',
    icon: 'Settings',
    path: '/settings'
  }
];

export const getRouteById = (id: string): RouteConfig | undefined => {
  return routes.find(route => route.id === id);
};

export const getRouteTitle = (id: string): string => {
  const route = getRouteById(id);
  return route?.title || 'Dashboard';
};

export const getRouteDescription = (id: string): string => {
  const route = getRouteById(id);
  return route?.description || 'Dashboard';
};
