import React, { createContext, useContext, useEffect, useState } from 'react';

export type Language = 
  | 'en' | 'vi' | 'ja' | 'ko' | 'zh' | 'fr' | 'de' | 'es'
  | 'ru' | 'pt' | 'it' | 'nl' | 'sv' | 'no' | 'da' | 'fi'
  | 'pl' | 'tr' | 'ar' | 'hi' | 'th' | 'id' | 'ms' | 'tl';

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

// Simplified translations for core functionality
const translations: Record<Language, Record<string, string>> = {
  en: {
    'nav.overview': 'Overview',
    'nav.erp': 'ERP Management',
    'nav.cms': 'CMS Management',
    'nav.ecommerce': 'E-commerce',
    'nav.support': 'Customer Support',
    'nav.templates': 'Templates',
    'nav.analytics': 'Analytics',
    'nav.settings': 'Settings',
    'common.loading': 'Loading...',
    'common.save': 'Save',
    'common.edit': 'Edit',
    'common.delete': 'Delete',
    'dashboard.welcome': 'Welcome to I3M Platform',
    'dashboard.subtitle': 'Comprehensive SaaS management system',
  },
  vi: {
    'nav.overview': 'Tổng quan',
    'nav.erp': 'Quản lý ERP',
    'nav.cms': 'Quản lý CMS',
    'nav.ecommerce': 'Thương mại điện tử',
    'nav.support': 'Hỗ trợ khách hàng',
    'nav.templates': 'Mẫu thiết kế',
    'nav.analytics': 'Phân tích',
    'nav.settings': 'Cài đặt',
    'common.loading': 'Đang tải...',
    'common.save': 'Lưu',
    'common.edit': 'Chỉnh sửa',
    'common.delete': 'Xóa',
    'dashboard.welcome': 'Chào mừng đến với I3M Platform',
    'dashboard.subtitle': 'Hệ thống quản lý SaaS toàn diện',
  },
  // Add more languages as needed...
  ja: { 'nav.overview': '概要', 'nav.erp': 'ERP管理', 'nav.cms': 'CMS管理', 'nav.ecommerce': 'Eコマース', 'nav.support': 'カスタマーサポート', 'nav.templates': 'テンプレート', 'nav.analytics': '分析', 'nav.settings': '設定', 'common.loading': '読み込み中...', 'common.save': '保存', 'common.edit': '編集', 'common.delete': '削除', 'dashboard.welcome': 'I3Mプラットフォームへようこそ', 'dashboard.subtitle': '包括的なSaaS管理システム' },
  ko: { 'nav.overview': '개요', 'nav.erp': 'ERP 관리', 'nav.cms': 'CMS 관리', 'nav.ecommerce': '이커머스', 'nav.support': '고객 지원', 'nav.templates': '템플릿', 'nav.analytics': '분석', 'nav.settings': '설정', 'common.loading': '로딩 중...', 'common.save': '저장', 'common.edit': '편집', 'common.delete': '삭제', 'dashboard.welcome': 'I3M 플랫폼에 오신 것을 환영합니다', 'dashboard.subtitle': '포괄적인 SaaS 관리 시스템' },
  zh: { 'nav.overview': '概览', 'nav.erp': 'ERP管理', 'nav.cms': 'CMS管理', 'nav.ecommerce': '电子商务', 'nav.support': '客户支持', 'nav.templates': '模板', 'nav.analytics': '分析', 'nav.settings': '设置', 'common.loading': '加载中...', 'common.save': '保存', 'common.edit': '编辑', 'common.delete': '删除', 'dashboard.welcome': '欢迎使用I3M平台', 'dashboard.subtitle': '综合SaaS管理系统' },
  fr: { 'nav.overview': 'Aperçu', 'nav.erp': 'Gestion ERP', 'nav.cms': 'Gestion CMS', 'nav.ecommerce': 'E-commerce', 'nav.support': 'Support client', 'nav.templates': 'Modèles', 'nav.analytics': 'Analytiques', 'nav.settings': 'Paramètres', 'common.loading': 'Chargement...', 'common.save': 'Enregistrer', 'common.edit': 'Modifier', 'common.delete': 'Supprimer', 'dashboard.welcome': 'Bienvenue sur la plateforme I3M', 'dashboard.subtitle': 'Système de gestion SaaS complet' },
  de: { 'nav.overview': 'Übersicht', 'nav.erp': 'ERP-Verwaltung', 'nav.cms': 'CMS-Verwaltung', 'nav.ecommerce': 'E-Commerce', 'nav.support': 'Kundensupport', 'nav.templates': 'Vorlagen', 'nav.analytics': 'Analytik', 'nav.settings': 'Einstellungen', 'common.loading': 'Wird geladen...', 'common.save': 'Speichern', 'common.edit': 'Bearbeiten', 'common.delete': 'Löschen', 'dashboard.welcome': 'Willkommen bei der I3M-Plattform', 'dashboard.subtitle': 'Umfassendes SaaS-Verwaltungssystem' },
  es: { 'nav.overview': 'Resumen', 'nav.erp': 'Gestión ERP', 'nav.cms': 'Gestión CMS', 'nav.ecommerce': 'Comercio electrónico', 'nav.support': 'Soporte al cliente', 'nav.templates': 'Plantillas', 'nav.analytics': 'Analíticas', 'nav.settings': 'Configuración', 'common.loading': 'Cargando...', 'common.save': 'Guardar', 'common.edit': 'Editar', 'common.delete': 'Eliminar', 'dashboard.welcome': 'Bienvenido a la plataforma I3M', 'dashboard.subtitle': 'Sistema integral de gestión SaaS' },
  ru: { 'nav.overview': 'Обзор', 'nav.erp': 'Управление ERP', 'nav.cms': 'Управление CMS', 'nav.ecommerce': 'Электронная коммерция', 'nav.support': 'Поддержка клиентов', 'nav.templates': 'Шаблоны', 'nav.analytics': 'Аналитика', 'nav.settings': 'Настройки', 'common.loading': 'Загрузка...', 'common.save': 'Сохранить', 'common.edit': 'Редактировать', 'common.delete': 'Удалить', 'dashboard.welcome': 'Добро пожаловать в платформу I3M', 'dashboard.subtitle': 'Комплексная система управления SaaS' },
  pt: { 'nav.overview': 'Visão geral', 'nav.erp': 'Gestão ERP', 'nav.cms': 'Gestão CMS', 'nav.ecommerce': 'Comércio eletrônico', 'nav.support': 'Suporte ao cliente', 'nav.templates': 'Modelos', 'nav.analytics': 'Análises', 'nav.settings': 'Configurações', 'common.loading': 'Carregando...', 'common.save': 'Salvar', 'common.edit': 'Editar', 'common.delete': 'Excluir', 'dashboard.welcome': 'Bem-vindo à plataforma I3M', 'dashboard.subtitle': 'Sistema abrangente de gestão SaaS' },
  it: { 'nav.overview': 'Panoramica', 'nav.erp': 'Gestione ERP', 'nav.cms': 'Gestione CMS', 'nav.ecommerce': 'E-commerce', 'nav.support': 'Supporto clienti', 'nav.templates': 'Modelli', 'nav.analytics': 'Analisi', 'nav.settings': 'Impostazioni', 'common.loading': 'Caricamento...', 'common.save': 'Salva', 'common.edit': 'Modifica', 'common.delete': 'Elimina', 'dashboard.welcome': 'Benvenuto nella piattaforma I3M', 'dashboard.subtitle': 'Sistema completo di gestione SaaS' },
  nl: { 'nav.overview': 'Overzicht', 'nav.erp': 'ERP-beheer', 'nav.cms': 'CMS-beheer', 'nav.ecommerce': 'E-commerce', 'nav.support': 'Klantenondersteuning', 'nav.templates': 'Sjablonen', 'nav.analytics': 'Analyses', 'nav.settings': 'Instellingen', 'common.loading': 'Laden...', 'common.save': 'Opslaan', 'common.edit': 'Bewerken', 'common.delete': 'Verwijderen', 'dashboard.welcome': 'Welkom bij het I3M-platform', 'dashboard.subtitle': 'Uitgebreid SaaS-beheersysteem' },
  sv: { 'nav.overview': 'Översikt', 'nav.erp': 'ERP-hantering', 'nav.cms': 'CMS-hantering', 'nav.ecommerce': 'E-handel', 'nav.support': 'Kundsupport', 'nav.templates': 'Mallar', 'nav.analytics': 'Analys', 'nav.settings': 'Inställningar', 'common.loading': 'Laddar...', 'common.save': 'Spara', 'common.edit': 'Redigera', 'common.delete': 'Ta bort', 'dashboard.welcome': 'Välkommen till I3M-plattformen', 'dashboard.subtitle': 'Omfattande SaaS-hanteringssystem' },
  no: { 'nav.overview': 'Oversikt', 'nav.erp': 'ERP-styring', 'nav.cms': 'CMS-styring', 'nav.ecommerce': 'E-handel', 'nav.support': 'Kundestøtte', 'nav.templates': 'Maler', 'nav.analytics': 'Analyse', 'nav.settings': 'Innstillinger', 'common.loading': 'Laster...', 'common.save': 'Lagre', 'common.edit': 'Rediger', 'common.delete': 'Slett', 'dashboard.welcome': 'Velkommen til I3M-plattformen', 'dashboard.subtitle': 'Omfattende SaaS-styringssystem' },
  da: { 'nav.overview': 'Overblik', 'nav.erp': 'ERP-styring', 'nav.cms': 'CMS-styring', 'nav.ecommerce': 'E-handel', 'nav.support': 'Kundesupport', 'nav.templates': 'Skabeloner', 'nav.analytics': 'Analyse', 'nav.settings': 'Indstillinger', 'common.loading': 'Indlæser...', 'common.save': 'Gem', 'common.edit': 'Rediger', 'common.delete': 'Slet', 'dashboard.welcome': 'Velkommen til I3M-platformen', 'dashboard.subtitle': 'Omfattende SaaS-styringssystem' },
  fi: { 'nav.overview': 'Yleiskatsaus', 'nav.erp': 'ERP-hallinta', 'nav.cms': 'CMS-hallinta', 'nav.ecommerce': 'Sähkökauppa', 'nav.support': 'Asiakastuki', 'nav.templates': 'Mallit', 'nav.analytics': 'Analytiikka', 'nav.settings': 'Asetukset', 'common.loading': 'Ladataan...', 'common.save': 'Tallenna', 'common.edit': 'Muokkaa', 'common.delete': 'Poista', 'dashboard.welcome': 'Tervetuloa I3M-alustalle', 'dashboard.subtitle': 'Kattava SaaS-hallintajärjestelmä' },
  pl: { 'nav.overview': 'Przegląd', 'nav.erp': 'Zarządzanie ERP', 'nav.cms': 'Zarządzanie CMS', 'nav.ecommerce': 'E-commerce', 'nav.support': 'Wsparcie klientów', 'nav.templates': 'Szablony', 'nav.analytics': 'Analityka', 'nav.settings': 'Ustawienia', 'common.loading': 'Ładowanie...', 'common.save': 'Zapisz', 'common.edit': 'Edytuj', 'common.delete': 'Usuń', 'dashboard.welcome': 'Witamy na platformie I3M', 'dashboard.subtitle': 'Kompleksowy system zarządzania SaaS' },
  tr: { 'nav.overview': 'Genel Bakış', 'nav.erp': 'ERP Yönetimi', 'nav.cms': 'CMS Yönetimi', 'nav.ecommerce': 'E-ticaret', 'nav.support': 'Müşteri Desteği', 'nav.templates': 'Şablonlar', 'nav.analytics': 'Analitik', 'nav.settings': 'Ayarlar', 'common.loading': 'Yükleniyor...', 'common.save': 'Kaydet', 'common.edit': 'Düzenle', 'common.delete': 'Sil', 'dashboard.welcome': 'I3M Platformuna Hoş Geldiniz', 'dashboard.subtitle': 'Kapsamlı SaaS yönetim sistemi' },
  ar: { 'nav.overview': 'نظرة عامة', 'nav.erp': 'إدارة تخطيط موارد المؤسسة', 'nav.cms': 'إدارة نظام إدارة المحتوى', 'nav.ecommerce': 'التجارة الإلكترونية', 'nav.support': 'دعم العملاء', 'nav.templates': 'القوالب', 'nav.analytics': 'التحليلات', 'nav.settings': 'الإعدادات', 'common.loading': 'جاري التحميل...', 'common.save': 'حفظ', 'common.edit': 'تحرير', 'common.delete': 'حذف', 'dashboard.welcome': 'مرحباً بك في منصة I3M', 'dashboard.subtitle': 'نظام إدارة SaaS شامل' },
  hi: { 'nav.overview': 'अवलोकन', 'nav.erp': 'ERP प्रबंधन', 'nav.cms': 'CMS प्रबंधन', 'nav.ecommerce': 'ई-कॉमर्स', 'nav.support': 'ग्राहक सहायता', 'nav.templates': 'टेम्प्लेट', 'nav.analytics': 'विश्लेषण', 'nav.settings': 'सेटिंग्स', 'common.loading': 'लोड हो रहा है...', 'common.save': 'सेव', 'common.edit': 'संपादित करें', 'common.delete': 'हटाएं', 'dashboard.welcome': 'I3M प्लेटफॉर्म में आपका स्वागत है', 'dashboard.subtitle': 'व्यापक SaaS प्रबंधन प्रणाली' },
  th: { 'nav.overview': 'ภาพรวม', 'nav.erp': 'การจัดการ ERP', 'nav.cms': 'การจัดการ CMS', 'nav.ecommerce': 'อีคอมเมิร์ส', 'nav.support': 'การสนับสนุนลูกค้า', 'nav.templates': 'เทมเพลต', 'nav.analytics': 'การวิเคราะห์', 'nav.settings': 'การตั้งค่า', 'common.loading': 'กำลังโหลด...', 'common.save': 'บันทึก', 'common.edit': 'แก้ไข', 'common.delete': 'ลบ', 'dashboard.welcome': 'ยินดีต้อนรับสู่แพลตฟอร์ม I3M', 'dashboard.subtitle': 'ระบบจัดการ SaaS ที่ครอบคลุม' },
  id: { 'nav.overview': 'Ringkasan', 'nav.erp': 'Manajemen ERP', 'nav.cms': 'Manajemen CMS', 'nav.ecommerce': 'E-commerce', 'nav.support': 'Dukungan Pelanggan', 'nav.templates': 'Template', 'nav.analytics': 'Analitik', 'nav.settings': 'Pengaturan', 'common.loading': 'Memuat...', 'common.save': 'Simpan', 'common.edit': 'Edit', 'common.delete': 'Hapus', 'dashboard.welcome': 'Selamat datang di platform I3M', 'dashboard.subtitle': 'Sistem manajemen SaaS yang komprehensif' },
  ms: { 'nav.overview': 'Gambaran Keseluruhan', 'nav.erp': 'Pengurusan ERP', 'nav.cms': 'Pengurusan CMS', 'nav.ecommerce': 'E-dagang', 'nav.support': 'Sokongan Pelanggan', 'nav.templates': 'Templat', 'nav.analytics': 'Analitik', 'nav.settings': 'Tetapan', 'common.loading': 'Memuatkan...', 'common.save': 'Simpan', 'common.edit': 'Edit', 'common.delete': 'Padam', 'dashboard.welcome': 'Selamat datang ke platform I3M', 'dashboard.subtitle': 'Sistem pengurusan SaaS yang komprehensif' },
  tl: { 'nav.overview': 'Pangkalahatang-tanaw', 'nav.erp': 'Pamamahala ng ERP', 'nav.cms': 'Pamamahala ng CMS', 'nav.ecommerce': 'E-commerce', 'nav.support': 'Suporta sa Customer', 'nav.templates': 'Mga Template', 'nav.analytics': 'Analytics', 'nav.settings': 'Mga Setting', 'common.loading': 'Naglo-load...', 'common.save': 'I-save', 'common.edit': 'I-edit', 'common.delete': 'Tanggalin', 'dashboard.welcome': 'Maligayang pagdating sa I3M platform', 'dashboard.subtitle': 'Komprehensibong SaaS management system' }
};

interface LanguageProviderProps {
  children: React.ReactNode;
  defaultLanguage?: Language;
  storageKey?: string;
}

export function LanguageProvider({
  children,
  defaultLanguage = 'en',
  storageKey = 'i3m-language',
}: LanguageProviderProps) {
  const [language, setLanguageState] = useState<Language>(defaultLanguage);

  useEffect(() => {
    // Load saved language
    try {
      const savedLanguage = localStorage.getItem(storageKey) as Language;
      if (savedLanguage && Object.keys(translations).includes(savedLanguage)) {
        setLanguageState(savedLanguage);
      } else {
        // Detect browser language
        const browserLanguage = navigator.language.slice(0, 2) as Language;
        if (Object.keys(translations).includes(browserLanguage)) {
          setLanguageState(browserLanguage);
        }
      }
    } catch (error) {
      console.error('Error loading language preference:', error);
    }
  }, [storageKey]);

  const setLanguage = (lang: Language) => {
    try {
      localStorage.setItem(storageKey, lang);
      setLanguageState(lang);
    } catch (error) {
      console.error('Error saving language preference:', error);
    }
  };

  const t = (key: string): string => {
    return translations[language]?.[key] || translations['en'][key] || key;
  };

  const value = {
    language,
    setLanguage,
    t,
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}
