import { ThemeProvider, DesignSystemProvider, LanguageProvider } from '@/app/providers';
import { MainDashboard } from '@/app/MainDashboard';

export default function App() {
  return (
    <LanguageProvider defaultLanguage="en">
      <DesignSystemProvider defaultSystem="apple" defaultMode="system">
        <ThemeProvider defaultTheme="system" storageKey="i3m-theme">
          <div className="h-screen w-full bg-background overflow-hidden">
            <MainDashboard />
          </div>
        </ThemeProvider>
      </DesignSystemProvider>
    </LanguageProvider>
  );
}
