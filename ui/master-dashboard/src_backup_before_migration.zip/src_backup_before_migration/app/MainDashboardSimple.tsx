import { useState } from 'react';
import { Location, NavigateFunction } from 'react-router-dom';
import { routes, RouteId } from './router';

interface MainDashboardSimpleProps {
  location: Location;
  navigate: NavigateFunction;
}

export function MainDashboardSimple({ location, navigate }: MainDashboardSimpleProps) {
  const [activeSection, setActiveSection] = useState<RouteId>('overview');

  // Get active section from URL
  const currentSection = routes?.find(route => route.path === location.pathname)?.id || 'overview';

  const handleSectionChange = (section: RouteId) => {
    if (section === activeSection) return;
    
    setActiveSection(section);
    
    // Find the route and navigate to it
    const route = routes?.find(r => r.id === section);
    if (route) {
      navigate(route.path);
    }
  };

  return (
    <div className="h-screen w-full bg-background flex">
      {/* Simple Sidebar */}
      <div className="w-64 bg-muted/50 p-4">
        <h2 className="text-lg font-semibold mb-4">Navigation</h2>
        <div className="space-y-2">
          {routes?.map((route) => (
            <button
              key={route.id}
              onClick={() => handleSectionChange(route.id)}
              className={`w-full text-left p-2 rounded ${
                currentSection === route.id ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
              }`}
            >
              {route.title}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8">
        <h1 className="text-2xl font-bold mb-4">
          {routes?.find(r => r.id === currentSection)?.title || 'Dashboard'}
        </h1>
        <p className="text-muted-foreground">
          Current path: {location.pathname}
        </p>
        <p className="text-muted-foreground">
          Active section: {currentSection}
        </p>
      </div>
    </div>
  );
}
