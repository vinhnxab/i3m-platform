import { MainDashboard } from './MainDashboard';

export function DashboardWrapper() {
  return <MainDashboard />;
}
