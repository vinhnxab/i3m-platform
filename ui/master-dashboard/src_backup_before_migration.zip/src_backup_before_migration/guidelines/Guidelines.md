# I3M Platform Design Guidelines

## Apple Design System
The I3M Platform follows Apple's design principles with iOS-inspired colors, San Francisco typography, and smooth interactions.

## General Guidelines

* Use Apple's color palette (#007aff primary, #34c759 success, #ff3b30 error)
* All cards should use `border-0 shadow-lg bg-white/80 backdrop-blur-xl rounded-2xl`
* Buttons should be rounded-xl with proper padding and font-weight-600
* Use smooth transitions with `duration-200` to `duration-500`
* Implement hover effects with subtle scale transforms `hover:scale-[1.02]`
* Use backdrop-blur effects for glass morphism appearance

## Responsive Design

* Mobile-first approach with lg:, md:, sm: breakpoints
* Mobile sidebar should be an overlay with backdrop blur
* Desktop sidebar can collapse to icons-only
* Grid layouts should stack on mobile: `grid-cols-1 sm:grid-cols-2 lg:grid-cols-4`
* Use responsive padding: `px-4 lg:px-8`
* Header text should scale: `text-2xl sm:text-3xl lg:text-4xl`

## Theme System

* Support light, dark, and system modes
* Use CSS custom properties for theme colors
* Dark mode uses true black (#000000) for OLED optimization
* Light mode uses subtle backgrounds (#f8f9fa)
* Theme toggle should be accessible in header/sidebar

## Layout Structure - UPDATED ✅

### Modern Scrollable Layout Pattern
**All main content components must follow this structure:**

```tsx
<div className="h-full flex flex-col overflow-hidden">
  {/* Fixed Header */}
  <div className="flex-shrink-0 p-6 border-b border-border/30 bg-background/50 backdrop-blur-sm">
    {/* Header content */}
  </div>

  {/* Scrollable Main Content */}
  <div className="flex-1 overflow-hidden">
    <Tabs className="h-full flex flex-col">
      {/* Fixed Tabs Navigation */}
      <div className="flex-shrink-0 p-6 pb-0">
        <TabsList className="grid w-full grid-cols-X">
          {/* Tab triggers */}
        </TabsList>
      </div>

      {/* Scrollable Tab Content */}
      <TabsContent className="flex-1 overflow-y-auto p-6 pt-4">
        <div className="space-y-6">
          {/* Content with proper spacing */}
        </div>
      </TabsContent>
    </Tabs>
  </div>
</div>
```

### Key Layout Principles:
* **Fixed Headers**: Use `flex-shrink-0` with border and backdrop blur
* **Scrollable Content**: Main content uses `flex-1 overflow-y-auto` 
* **No Double Spacing**: Remove duplicate `space-y-6` classes
* **Consistent Structure**: Header → Tabs → Content with proper flex layout
* **Content should be scrollable within viewport height**

## Components

* Cards: Use shadow-lg, rounded-2xl, backdrop-blur-xl
* Badges: rounded-full with px-3 py-1 and font-semibold
* Buttons: rounded-xl with proper semantic variants
* Navigation: Subtle backgrounds with hover states
* Progress bars: Rounded with proper color coding
* **Tabs: Always use Shadcn Tabs component with standard pattern (see Tabs-Standards.md)**

## Tab Standards (Critical)

* **Always use**: `<Tabs>`, `<TabsList>`, `<TabsTrigger>`, `<TabsContent>` from Shadcn
* **Container**: `className="space-y-6"`
* **TabsList**: `className="grid w-full grid-cols-X"` (where X = number of tabs)
* **TabsContent**: `className="space-y-6"`
* **Never use**: Custom tab button components or complex animations
* **Reference**: CMS Management component for perfect implementation

## Accessibility

* Proper focus states with ring colors
* Keyboard navigation support
* Screen reader friendly labels
* High contrast ratios in both themes
* Escape key closes mobile overlays