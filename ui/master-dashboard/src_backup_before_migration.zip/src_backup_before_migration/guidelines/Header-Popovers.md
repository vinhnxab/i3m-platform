# Header Popovers Documentation

## Overview
The I3M Platform header includes 4 interactive popover components for Email, Messages, Notifications, and User Menu. Each popover provides rich, contextual information and actions.

## Components

### 1. EmailPopover
**Purpose**: Display email notifications and quick actions
**Features**:
- Email list with sender, subject, preview
- Priority indicators (high, normal, low)
- Type categorization (payment, customer, report, system, product)
- Unread count badge
- Quick actions: Reply, Archive
- "View All Emails" button

### 2. MessagePopover
**Purpose**: Display chat/messaging notifications
**Features**:
- Direct messages and group conversations
- Online status indicators
- Group member counts
- Unread message badges
- Quick actions: Reply, Mark as Read
- "Open Chat App" button

### 3. NotificationPopover
**Purpose**: Display system notifications and alerts
**Features**:
- System status alerts (warning, success, info, error)
- Actionable notifications
- Color-coded icons by type
- Quick action buttons
- Dismiss functionality
- "View All Notifications" button

### 4. UserMenuPopover
**Purpose**: User account and profile management
**Features**:
- User profile information
- Quick access menu items
- Keyboard shortcuts display
- Sign out option

## Design Principles

### Visual Design
- **Glass morphism**: `bg-card/95 backdrop-blur-xl`
- **Border radius**: `rounded-2xl` for modern Apple-style design
- **Shadow**: `shadow-xl` for depth
- **No borders**: `border-0` for clean look
- **Animations**: Smooth fade-in and zoom-in effects

### Responsive Design
- **Mobile optimization**: Smaller badge sizes and icons
- **Desktop enhancement**: Larger touch targets and more detail
- **Adaptive width**: Different widths for different content types

### Color Coding
- **Email badge**: Primary blue (`bg-primary`)
- **Message badge**: Green (`bg-chart-2`)
- **Notification badge**: Red (`bg-chart-4`)
- **User menu**: No badge (profile avatar only)

## Usage Examples

### Basic Implementation
```tsx
import { EmailPopover, MessagePopover, NotificationPopover, UserMenuPopover } from './HeaderPopovers';

// Desktop header
<EmailPopover />
<MessagePopover />
<NotificationPopover />
<UserMenuPopover />

// Mobile header
<EmailPopover isMobile={true} />
<MessagePopover isMobile={true} />
<NotificationPopover isMobile={true} />
<UserMenuPopover isMobile={true} />
```

### Notification Badge Component
```tsx
import { NotificationBadge } from './NotificationBadge';

<NotificationBadge 
  count={unreadCount} 
  isMobile={isMobile} 
  color="primary" // primary | green | red | orange
/>
```

## Content Structure

### Email Notifications
```typescript
interface EmailNotification {
  id: number;
  subject: string;
  from: string;
  time: string;
  preview: string;
  unread: boolean;
  priority: 'high' | 'normal' | 'low';
  type: 'payment' | 'customer' | 'report' | 'system' | 'product';
}
```

### Message Notifications
```typescript
interface MessageNotification {
  id: number;
  name: string;
  message: string;
  time: string;
  avatar: string;
  online: boolean;
  unread: boolean;
  type: 'direct' | 'group';
  members?: number;
}
```

### System Notifications
```typescript
interface SystemNotification {
  id: number;
  title: string;
  description: string;
  time: string;
  type: 'warning' | 'success' | 'info' | 'error';
  action: string;
  icon: React.ComponentType;
  unread: boolean;
}
```

## Interaction Patterns

### Hover States
- Button background changes to `hover:bg-muted`
- Popover items highlight with `hover:bg-muted/50`

### Loading States
- Skeleton loaders for dynamic content
- Shimmer effects for better perceived performance

### Empty States
- "No new messages" with appropriate icons
- Call-to-action buttons when applicable

### Keyboard Navigation
- Tab navigation through popover items
- Escape to close popovers
- Enter to activate items

## Accessibility Features

### ARIA Labels
- Proper labeling for screen readers
- Role attributes for interactive elements
- Live regions for dynamic updates

### Focus Management
- Focus trap within popovers
- Logical tab order
- Visible focus indicators

### Color Contrast
- High contrast ratios for all text
- Icon visibility in all themes
- Badge readability

## Performance Considerations

### Lazy Loading
- Notifications loaded on demand
- Image optimization for avatars
- Virtual scrolling for large lists

### Caching
- Local storage for read/unread states
- Optimistic updates for quick interactions
- Background sync for new notifications

## Integration with Backend

### Real-time Updates
- WebSocket connections for live notifications
- Push notification support
- Offline queue management

### API Endpoints
```typescript
GET /api/notifications/emails
GET /api/notifications/messages  
GET /api/notifications/system
POST /api/notifications/mark-read
DELETE /api/notifications/{id}
```

## Customization Options

### Theme Support
- Works with all 6 design systems
- Automatic dark/light mode adaptation
- Custom color schemes per organization

### Configuration
```typescript
interface PopoverConfig {
  maxItems: number;
  autoRefresh: boolean;
  soundEnabled: boolean;
  groupSimilar: boolean;
}
```

## Best Practices

### Content Guidelines
- Keep notification text concise but informative
- Use action-oriented language
- Provide clear next steps
- Group related notifications

### Timing
- Batch notifications to avoid spam
- Respect user's notification preferences
- Use appropriate urgency levels

### Performance
- Limit visible items (virtual scrolling)
- Debounce rapid updates
- Optimize re-renders with React.memo

---

*Last Updated: January 2024*
*Author: I3M Platform Design Team*