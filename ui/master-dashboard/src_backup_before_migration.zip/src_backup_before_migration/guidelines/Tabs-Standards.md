# I3M Platform Tabs Standards

## Overview
This document defines the standardized tabs component usage across the I3M Platform to ensure consistent user experience and design patterns.

## Standard Pattern (CMS Style)

### Basic Structure
```tsx
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

<Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
  <TabsList className="grid w-full grid-cols-4">
    <TabsTrigger value="tab1">Tab 1</TabsTrigger>
    <TabsTrigger value="tab2">Tab 2</TabsTrigger>
    <TabsTrigger value="tab3">Tab 3</TabsTrigger>
    <TabsTrigger value="tab4">Tab 4</TabsTrigger>
  </TabsList>

  <TabsContent value="tab1" className="space-y-6">
    {/* Tab 1 Content */}
  </TabsContent>
  
  <TabsContent value="tab2" className="space-y-6">
    {/* Tab 2 Content */}
  </TabsContent>
</Tabs>
```

## Standard Classes

### Container
- `className="space-y-6"` - Consistent spacing between tabs list and content

### TabsList
- `className="grid w-full grid-cols-X"` where X is the number of tabs
- Use exact count: `grid-cols-2`, `grid-cols-3`, `grid-cols-4`, etc.

### TabsContent
- **CRITICAL**: Do NOT add `className="space-y-6"` to TabsContent if Tabs container already has it
- Only add spacing if TabsContent contains multiple direct children sections

## Spacing Rules (CRITICAL)

### ❌ WRONG - Stacked spacing causes excessive whitespace:
```tsx
<Tabs className="space-y-6">
  <TabsContent value="tab1" className="space-y-6">  {/* DUPLICATE SPACING */}
    <SomeContainer className="space-y-6">          {/* TRIPLE SPACING */}
      <div className="space-y-6">                  {/* QUADRUPLE SPACING */}
```

### ✅ CORRECT - Single spacing level:
```tsx
<Tabs className="space-y-6">
  <TabsContent value="tab1">                      {/* NO EXTRA SPACING */}
    <SomeContainer className="space-y-6">         {/* SINGLE SPACING */}
      <div>                                       {/* NO SPACING */}
```

## Grid Columns Reference

| Tab Count | Class |
|-----------|-------|
| 2 tabs | `grid-cols-2` |
| 3 tabs | `grid-cols-3` |
| 4 tabs | `grid-cols-4` |
| 5 tabs | `grid-cols-5` |
| 6 tabs | `grid-cols-6` |

## Examples from Components

### ✅ CMS Management (Standard)
```tsx
<Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
  <TabsList className="grid w-full grid-cols-4">
    <TabsTrigger value="content">Content</TabsTrigger>
    <TabsTrigger value="media">Media Library</TabsTrigger>
    <TabsTrigger value="categories">Categories</TabsTrigger>
    <TabsTrigger value="themes">Themes</TabsTrigger>
  </TabsList>

  <TabsContent value="content" className="space-y-6">
    {/* Content */}
  </TabsContent>
</Tabs>
```

### ✅ ERP Management (Updated to Standard)
```tsx
<Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
  <TabsList className="grid w-full grid-cols-4">
    <TabsTrigger value="hr">Human Resources</TabsTrigger>
    <TabsTrigger value="finance">Financial</TabsTrigger>
    <TabsTrigger value="inventory">Inventory</TabsTrigger>
    <TabsTrigger value="projects">Projects</TabsTrigger>
  </TabsList>
</Tabs>
```

### ❌ Custom Tab Buttons (Avoid)
```tsx
// Don't use custom tab button components
<TabButton id="hr" isActive={activeTab === 'hr'} onClick={() => setActiveTab('hr')}>
  Human Resources
</TabButton>
```

## Helper Component

For complex use cases, you can use the `StandardTabs` component:

```tsx
import { StandardTabs } from './StandardTabs';

const tabs = [
  { value: 'tab1', label: 'Tab 1', content: <Tab1Content /> },
  { value: 'tab2', label: 'Tab 2', content: <Tab2Content /> },
];

<StandardTabs tabs={tabs} defaultValue="tab1" />
```

## Benefits

1. **Consistency**: All tabs look and behave the same across modules
2. **Accessibility**: Shadcn tabs component has built-in accessibility features
3. **Responsive**: Automatic responsive behavior
4. **Theme Support**: Works with all 6 design systems
5. **Maintainability**: Easier to update styling globally

## Migration Guide

### From Custom Tab Buttons
1. Remove custom `TabButton` components
2. Replace with Shadcn `Tabs`, `TabsList`, `TabsTrigger`
3. Wrap content in `TabsContent` components
4. Use standard classes: `space-y-6`, `grid w-full grid-cols-X`

### State Management
```tsx
// Before
const [activeTab, setActiveTab] = useState<TabId>('hr');
const handleTabChange = (newTab: TabId) => { /* complex logic */ };

// After  
const [activeTab, setActiveTab] = useState('hr');
// onValueChange handles it automatically
```

## Design System Integration

The standard tabs automatically work with all design systems:
- **Apple**: Clean, minimal with proper spacing
- **Material**: Material Design 3 styling
- **Fluent**: Microsoft Fluent design
- **Ant**: Ant Design styling
- **Chakra**: Chakra UI styling  
- **Custom**: Custom design tokens

## Best Practices

1. **Always use `space-y-6`** for consistent spacing
2. **Use exact grid column count** - don't use responsive variants
3. **Keep tab labels short and descriptive**
4. **Group related content logically**
5. **Use consistent naming conventions** for tab values
6. **Add loading states** for dynamic content

## Implementation Status

| Component | Status | Notes |
|-----------|--------|-------|
| ✅ CMSManagement | Standard | Reference implementation |
| ✅ ERPManagement | Updated | Migrated from custom tabs |
| ✅ EcommerceManagement | Standard | Already using standard |
| ✅ SupportManagement | Standard | Already using standard |
| ✅ Analytics | Standard | Already using standard |
| ✅ CustomerManagement | Standard | Already using standard |
| ✅ SettingsPanel | Standard | Already using standard |

## Future Enhancements

1. **Animation Support**: Add smooth transitions between tabs
2. **Icon Support**: Support for icons in tab labels
3. **Badge Support**: Support for badges/notifications in tabs
4. **Overflow Handling**: Support for many tabs with horizontal scroll

---

*Last Updated: January 2024*
*Author: I3M Platform Design Team*