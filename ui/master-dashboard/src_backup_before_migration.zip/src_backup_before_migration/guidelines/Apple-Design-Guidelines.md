# Apple Design Guidelines for I3M Platform

## Design Philosophy
The I3M Platform follows Apple's design principles emphasizing clarity, deference, and depth to create an intuitive and visually stunning admin dashboard experience.

## Color Palette

### Primary Colors
- **Primary Blue**: `#007aff` (iOS Blue)
- **Success Green**: `#34c759` (iOS Green)
- **Warning Orange**: `#ff9500` (iOS Orange)
- **Error Red**: `#ff3b30` (iOS Red)
- **Purple**: `#af52de` (iOS Purple)

### Neutral Colors
- **Background Light**: `#f8f9fa` (Light Gray 1)
- **Background Dark**: `#000000` (True Black)
- **Card Background**: `#ffffff` (Pure White)
- **Text Primary**: `#1d1d1f` (Apple Text)
- **Text Secondary**: `#8e8e93` (Apple Secondary)
- **Border**: `#d1d1d6` (Apple Border)

## Typography
- **Font Family**: San Francisco Pro (System fonts)
- **Font Weights**: 
  - Normal: 400
  - Medium: 600 (Apple uses 600 instead of 500)
- **Font Smoothing**: Antialiased with webkit optimizations

## Border Radius
- **Small**: `0.75rem` (12px)
- **Medium**: `1rem` (16px) 
- **Large**: `1.5rem` (24px)
- **Cards**: `1.25rem` (20px)
- **Buttons**: `0.75rem` (12px)

## Shadows & Depth
- **Card Shadow**: Subtle with blur and transparency
- **Hover Effects**: Gentle scale transforms (1.02)
- **Backdrop Blur**: 12px for glassy effects

## Components

### Cards
- Background: `bg-white/80 backdrop-blur-xl`
- Border: None (`border-0`)
- Shadow: `shadow-lg`
- Radius: `rounded-2xl`
- Hover: `hover:shadow-xl hover:scale-[1.02]`

### Buttons
- Primary: Blue gradient with white text
- Secondary: Outline with subtle background
- Radius: `rounded-xl`
- Height: Minimum 12 (48px)
- Font Weight: 600 (Semibold)

### Badges
- Radius: `rounded-full`
- Padding: `px-3 py-1`
- Font Weight: 600 (Semibold)

### Sidebar
- Background: `bg-sidebar/80 backdrop-blur-xl`
- Width: 288px (18rem) when expanded
- Border: Subtle with transparency
- Navigation items: Rounded rectangles with subtle backgrounds

## Spacing
- Container Padding: `p-8`
- Card Padding: `p-6`
- Grid Gaps: `gap-6` to `gap-8`
- Element Spacing: `space-y-3` to `space-y-4`

## Animations
- Duration: `duration-200` to `duration-500`
- Easing: `ease-out` for natural movement
- Hover States: Scale and shadow transforms
- Transitions: All properties for smooth interactions

## Dark Mode
- Maintains Apple's dark mode color scheme
- True black backgrounds for OLED optimization
- Proper contrast ratios for accessibility
- Consistent with iOS/macOS dark themes

## Accessibility
- High contrast ratios
- Proper focus states
- Semantic HTML structure
- Screen reader friendly