// ERP feature barrel export
export { ERPManagement } from './components';
export { useERP } from './hooks/useERP';
export type { ERPData, ERPState } from './types';
