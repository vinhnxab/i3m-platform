// ERP components barrel export
export { ERPManagement } from './ERPManagement';
