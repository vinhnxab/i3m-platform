import { useState, useEffect } from 'react';
import { ERPState, ERPData, Project, Invoice } from '@/features/erp/types';

const mockData: ERPData = {
  totalRevenue: 1250000,
  activeProjects: 12,
  pendingInvoices: 8,
  completedTasks: 156,
};

const mockProjects: Project[] = [
  {
    id: '1',
    name: 'E-commerce Platform',
    status: 'active',
    progress: 75,
    budget: 50000,
    team: ['John Doe', 'Jane Smith', 'Mike Johnson'],
    deadline: '2024-02-15'
  },
  {
    id: '2',
    name: 'Mobile App Development',
    status: 'active',
    progress: 45,
    budget: 35000,
    team: ['Sarah Wilson', 'Tom Brown'],
    deadline: '2024-03-01'
  },
  {
    id: '3',
    name: 'Data Migration',
    status: 'completed',
    progress: 100,
    budget: 25000,
    team: ['Alex Chen', 'Lisa Davis'],
    deadline: '2024-01-30'
  }
];

const mockInvoices: Invoice[] = [
  {
    id: 'INV-001',
    client: 'TechCorp Inc.',
    amount: 15000,
    status: 'pending',
    dueDate: '2024-02-10',
    description: 'Q1 Development Services'
  },
  {
    id: 'INV-002',
    client: 'StartupXYZ',
    amount: 8500,
    status: 'paid',
    dueDate: '2024-01-25',
    description: 'Mobile App Consultation'
  },
  {
    id: 'INV-003',
    client: 'Enterprise Solutions',
    amount: 25000,
    status: 'overdue',
    dueDate: '2024-01-15',
    description: 'System Integration'
  }
];

export function useERP() {
  const [state, setState] = useState<ERPState>({
    data: mockData,
    projects: mockProjects,
    invoices: mockInvoices,
    isLoading: true,
    error: null,
  });

  useEffect(() => {
    const loadERPData = async () => {
      try {
        setState(prev => ({ ...prev, isLoading: true, error: null }));
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        setState(prev => ({
          ...prev,
          data: mockData,
          projects: mockProjects,
          invoices: mockInvoices,
          isLoading: false,
        }));
      } catch (error) {
        setState(prev => ({
          ...prev,
          isLoading: false,
          error: error instanceof Error ? error.message : 'Failed to load ERP data',
        }));
      }
    };

    loadERPData();
  }, []);

  const refreshData = async () => {
    console.log('Refreshing ERP data...');
  };

  return {
    ...state,
    refreshData,
  };
}
