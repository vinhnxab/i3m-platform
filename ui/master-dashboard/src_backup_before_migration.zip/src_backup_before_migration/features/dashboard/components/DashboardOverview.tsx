import { Card, CardContent, CardDescription, CardHeader, CardTitle, Badge } from '@/shared/components/ui';
import { I3MLogo, LoadingLogo } from '@/shared/components/common';
import { 
  TrendingUp, 
  Users, 
  ShoppingCart, 
  MessageSquare, 
  DollarSign,
  Zap,
  CheckCircle,
  Palette,
  Play
} from 'lucide-react';
import { useDashboard } from '../hooks/useDashboard';

export function DashboardOverview() {
  const { stats, systemStatus, recentActivity, isLoading, error } = useDashboard();

  if (isLoading) {
    return (
      <div className="w-full px-4 lg:px-6 py-4 lg:py-6 flex items-center justify-center min-h-[400px]">
        <LoadingLogo size="lg" showText={true} />
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full px-4 lg:px-6 py-4 lg:py-6 flex items-center justify-center min-h-[400px]">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="text-destructive">Error Loading Dashboard</CardTitle>
            <CardDescription>{error}</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const statsData = [
    { 
      title: 'Total Customers', 
      value: stats.totalCustomers.toLocaleString(), 
      change: '+12%', 
      icon: Users, 
      color: 'text-primary' 
    },
    { 
      title: 'Monthly Revenue', 
      value: `$${(stats.monthlyRevenue / 1000).toFixed(0)}K`, 
      change: '+23%', 
      icon: DollarSign, 
      color: 'text-chart-2' 
    },
    { 
      title: 'Active Orders', 
      value: stats.activeOrders.toLocaleString(), 
      change: '+8%', 
      icon: ShoppingCart, 
      color: 'text-chart-3' 
    },
    { 
      title: 'Support Tickets', 
      value: stats.supportTickets.toString(), 
      change: '-15%', 
      icon: MessageSquare, 
      color: 'text-chart-4' 
    },
  ];

  return (
    <div className="w-full px-4 lg:px-6 py-4 lg:py-6 space-y-4 lg:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 gap-2">
        <div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-semibold text-foreground tracking-tight">I3M Platform Overview</h1>
          <p className="text-base lg:text-lg text-muted-foreground font-medium mt-1 lg:mt-2">Comprehensive enterprise management dashboard</p>
        </div>
        <div className="flex items-center space-x-3">
          <Badge variant="outline" className="text-chart-2 border-current bg-chart-2/10 backdrop-blur-sm px-3 lg:px-4 py-1.5 lg:py-2 rounded-full font-semibold text-sm">
            <CheckCircle className="w-3 lg:w-4 h-3 lg:h-4 mr-1 lg:mr-2" />
            All Systems Operational
          </Badge>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
        {statsData.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title} className="relative overflow-hidden group hover:shadow-lg transition-all duration-300 hover:scale-[1.02]">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <Icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  <span className={`inline-flex items-center ${stat.change.startsWith('+') ? 'text-chart-2' : 'text-chart-4'}`}>
                    <TrendingUp className="w-3 h-3 mr-1" />
                    {stat.change}
                  </span>
                  <span className="ml-2">from last month</span>
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* System Status & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
        {/* System Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Zap className="w-5 h-5 text-chart-2" />
              <span>System Status</span>
            </CardTitle>
            <CardDescription>Real-time system health monitoring</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {systemStatus.map((status, index) => (
              <div key={status.service} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                <div className="flex items-center space-x-3">
                  <div className={`w-2 h-2 rounded-full ${
                    status.status === 'operational' ? 'bg-chart-2' : 
                    status.status === 'maintenance' ? 'bg-chart-3' : 'bg-chart-4'
                  }`} />
                  <div>
                    <p className="font-medium text-sm">{status.service}</p>
                    <p className="text-xs text-muted-foreground capitalize">{status.status}</p>
                  </div>
                </div>
                <Badge variant="outline" className="text-xs">
                  {status.uptime}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Play className="w-5 h-5 text-chart-3" />
              <span>Recent Activity</span>
            </CardTitle>
            <CardDescription>Latest system events and updates</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 rounded-lg bg-muted/30">
                <div className={`w-2 h-2 rounded-full mt-2 ${
                  activity.type === 'customer' ? 'bg-chart-2' : 
                  activity.type === 'order' ? 'bg-chart-3' : 
                  activity.type === 'support' ? 'bg-chart-4' : 'bg-primary'
                }`} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">{activity.action}</p>
                  <p className="text-xs text-muted-foreground">{activity.customer}</p>
                  <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Palette className="w-5 h-5 text-primary" />
            <span>Quick Actions</span>
          </CardTitle>
          <CardDescription>Frequently used platform features</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
            {[
              { name: 'New Customer', icon: Users, color: 'bg-chart-2' },
              { name: 'Create Order', icon: ShoppingCart, color: 'bg-chart-3' },
              { name: 'Support Ticket', icon: MessageSquare, color: 'bg-chart-4' },
              { name: 'Analytics', icon: TrendingUp, color: 'bg-primary' },
              { name: 'Settings', icon: Palette, color: 'bg-muted' },
              { name: 'Reports', icon: CheckCircle, color: 'bg-chart-1' }
            ].map((action, index) => {
              const Icon = action.icon;
              return (
                <div key={action.name} className="flex flex-col items-center p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer group">
                  <div className={`w-10 h-10 rounded-lg ${action.color} flex items-center justify-center mb-2 group-hover:scale-110 transition-transform`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-xs font-medium text-center">{action.name}</span>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
